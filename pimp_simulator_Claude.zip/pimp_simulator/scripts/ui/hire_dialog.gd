class_name HireDialog
extends PanelContainer
## Diyalog + pazarlık ekranı: komisyon, vardiya ve ek haklar üzerinden gönüllü sözleşme.

signal closed

var business: Node
var cand: Dictionary = {}
var counter_val := -1.0
var finished := false
var profile_box: VBoxContainer
var speech: Label
var title: Label
var slider: HSlider
var slider_val: Label
var shift_opt: OptionButton
var perk_checks: Dictionary = {}
var lbl_demand: Label
var lbl_prob: Label
var prob_bar: ProgressBar
var lbl_worker: Label
var lbl_business: Label
var lbl_info: Label
var btn_offer: Button
var btn_counter: Button
var controls: Array = []


func setup(b: Node) -> void:
	business = b
	custom_minimum_size = Vector2(980, 0)
	var outer := UIKit.vbox(8)
	add_child(outer)
	var head := UIKit.hbox(8)
	outer.add_child(head)
	title = UIKit.lbl("Görüşme", 20, UIKit.ACCENT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	head.add_child(UIKit.btn("Kapat (Esc)", _close))
	var cols := UIKit.hbox(18)
	cols.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(cols)
	profile_box = UIKit.vbox(5)
	profile_box.custom_minimum_size.x = 380
	cols.add_child(profile_box)
	var right := UIKit.vbox(7)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_child(right)
	var bubble := UIKit.card()
	right.add_child(bubble)
	speech = UIKit.wrap("", 16, Color(1, 0.95, 0.8))
	speech.custom_minimum_size.y = 44
	bubble.add_child(speech)
	right.add_child(UIKit.lbl("Teklifin", 16, UIKit.ACCENT))
	var srow := UIKit.hbox(8)
	right.add_child(srow)
	srow.add_child(UIKit.lbl("İşletme komisyonu", 14))
	slider = HSlider.new()
	slider.min_value = Config.MIN_COMMISSION * 100.0
	slider.max_value = Config.MAX_COMMISSION * 100.0
	slider.step = 1.0
	slider.value = 35.0
	slider.custom_minimum_size.x = 260
	slider.value_changed.connect(func(_v): _update_eval())
	srow.add_child(slider)
	slider_val = UIKit.lbl("%35", 15)
	srow.add_child(slider_val)
	controls.append(slider)
	var shrow := UIKit.hbox(8)
	right.add_child(shrow)
	shrow.add_child(UIKit.lbl("Çalışma saatleri", 14))
	shift_opt = OptionButton.new()
	for s in Config.SHIFT_ORDER:
		shift_opt.add_item(Config.shift_name(s))
	shift_opt.item_selected.connect(func(_i): _update_eval())
	shrow.add_child(shift_opt)
	controls.append(shift_opt)
	right.add_child(UIKit.lbl("Çalışma koşulları ve ek haklar", 14, UIKit.MUTED))
	for k in Config.PERK_ORDER:
		var p: Dictionary = Config.PERKS[k]
		var cost := ""
		if float(p["daily"]) > 0.0:
			cost = "  (−%d$/gün)" % int(p["daily"])
		elif float(p["weekly"]) > 0.0:
			cost = "  (−%d$/hafta)" % int(p["weekly"])
		var cb := CheckBox.new()
		cb.text = "%s%s" % [p["name"], cost]
		cb.toggled.connect(func(_on): _update_eval())
		right.add_child(cb)
		perk_checks[k] = cb
		controls.append(cb)
	right.add_child(UIKit.sep())
	lbl_demand = UIKit.lbl("", 15, UIKit.WARN)
	right.add_child(lbl_demand)
	var prow := UIKit.hbox(8)
	right.add_child(prow)
	lbl_prob = UIKit.lbl("", 15)
	prow.add_child(lbl_prob)
	prob_bar = UIKit.bar(0.0, UIKit.GOOD, 220)
	prow.add_child(prob_bar)
	lbl_worker = UIKit.lbl("", 14)
	right.add_child(lbl_worker)
	lbl_business = UIKit.lbl("", 14)
	right.add_child(lbl_business)
	lbl_info = UIKit.wrap("", 13)
	right.add_child(lbl_info)
	var brow := UIKit.hbox(8)
	right.add_child(brow)
	btn_offer = UIKit.btn("Teklif et", _on_offer)
	brow.add_child(btn_offer)
	btn_counter = UIKit.btn("Karşı teklifi kabul et", _on_counter)
	btn_counter.visible = false
	brow.add_child(btn_counter)
	brow.add_child(UIKit.btn("Vazgeç", _close))
	right.add_child(UIKit.wrap("Sözleşme gönüllüdür: çalışan memnun kalmazsa istediği zaman ayrılabilir. Müşteri başına ödemeyi çalışanla işletme belirlenen oranda paylaşır.", 12))
	visible = false


func open(c: Dictionary) -> void:
	cand = c
	counter_val = -1.0
	finished = false
	for ctl in controls:
		ctl.set("disabled", false)
	btn_offer.disabled = false
	btn_counter.visible = false
	var shift_idx := Config.SHIFT_ORDER.find(String(c.pref_shift))
	shift_opt.select(maxi(0, shift_idx))
	slider.value = 35.0
	for k in perk_checks:
		perk_checks[k].button_pressed = false
	title.text = "Görüşme: %s" % c.name
	var lines: Dictionary = Config.LINES.get(String(c.personality), Config.LINES["Sakin"])
	speech.text = "%s: “%s”" % [c.name, lines["hi"]]
	_fill_profile()
	_update_eval()
	visible = true


func _fill_profile() -> void:
	UIKit.clear(profile_box)
	var c := cand
	profile_box.add_child(UIKit.lbl("%s  ·  %d yaş" % [c.name, int(c.age)], 18))
	profile_box.add_child(UIKit.lbl("Kişilik: %s" % c.personality, 14, UIKit.MUTED))
	profile_box.add_child(UIKit.lbl("Görünüm: %s" % Generator.appearance_text(c.look), 14, UIKit.MUTED))
	profile_box.add_child(UIKit.lbl("Çalışma tercihi: %s" % Config.shift_name(String(c.pref_shift)), 14, UIKit.MUTED))
	profile_box.add_child(UIKit.lbl("Günlük çalışma kapasitesi: %d görüşme" % Economy.daily_capacity(c), 14, UIKit.MUTED))
	profile_box.add_child(UIKit.sep())
	for k in Config.SKILL_ORDER:
		profile_box.add_child(UIKit.stat_row(String(Config.SKILLS[k]), float(c[k]), Color(0.45, 0.65, 0.95), 120))
	profile_box.add_child(UIKit.stat_row("Beklenti seviyesi", float(c.expectation), UIKit.WARN, 120))
	profile_box.add_child(UIKit.stat_row("Güven", float(c.trust), UIKit.GOOD, 120))
	profile_box.add_child(UIKit.lbl("Standart görüşme fiyatı: %s" % UIKit.fmt_money(Economy.session_price(c, "standard")), 14))
	profile_box.add_child(UIKit.lbl("Kapasite: %d / %d çalışan" % [GameState.workers.size(), GameState.max_workers()], 14, UIKit.MUTED))


func _perks() -> Array:
	var out: Array = []
	for k in Config.PERK_ORDER:
		if perk_checks[k].button_pressed:
			out.append(k)
	return out


func _shift() -> String:
	return String(Config.SHIFT_ORDER[maxi(0, shift_opt.selected)])


func _commission() -> float:
	return slider.value / 100.0


func _update_eval() -> void:
	if cand.is_empty():
		return
	var ev := Economy.negotiate_eval(cand, _commission(), _shift(), _perks())
	slider_val.text = "%%%d" % int(slider.value)
	lbl_demand.text = "Çalışanın talebi: işletme payı en fazla %%%d (çalışana %%%d)" % [int(roundf(float(ev.counter) * 100.0)), int(roundf((1.0 - float(ev.counter)) * 100.0))]
	lbl_prob.text = "Anlaşma olasılığı: %%%d" % int(roundf(float(ev.prob) * 100.0))
	prob_bar.value = float(ev.prob) * 100.0
	lbl_worker.text = "Çalışanın beklenen kazancı: %s / görüşme  (≈ %s / gün)" % [UIKit.fmt_money(float(ev.worker_per_session)), UIKit.fmt_money(float(ev.worker_daily))]
	lbl_business.text = "İşletmenin beklenen kazancı: %s / görüşme  (≈ %s / gün)" % [UIKit.fmt_money(float(ev.business_per_session)), UIKit.fmt_money(float(ev.business_daily))]
	lbl_info.text = "Örnek: 100$'lık görüşmede %%%d komisyonla çalışan %d$, işletme %d$ alır.   Kalan pazarlık hakkı: %d" % [int(slider.value), int(roundf(100.0 - slider.value)), int(slider.value), maxi(0, int(cand.patience))]


func _say(t: String) -> void:
	speech.text = "%s: “%s”" % [cand.name, t]


func _lock() -> void:
	finished = true
	btn_offer.disabled = true
	btn_counter.visible = false
	for ctl in controls:
		ctl.set("disabled", true)


func _on_offer() -> void:
	if finished or cand.is_empty():
		return
	var lines: Dictionary = Config.LINES.get(String(cand.personality), Config.LINES["Sakin"])
	if GameState.workers.size() >= GameState.max_workers():
		_say("Burada yer kalmamış gibi... Önce işletmeni genişlet.")
		GameState.notify("Çalışan kapasitesi dolu. Oda veya dinlenme alanı geliştir.", "warn")
		return
	var ev := Economy.negotiate_eval(cand, _commission(), _shift(), _perks())
	if randf() < float(ev.prob):
		var err: String = business.hire(cand, _commission(), _shift(), _perks())
		if err != "":
			_say(err)
			return
		_say(String(lines["yes"]))
		_lock()
		get_tree().create_timer(1.2).timeout.connect(_close)
		return
	cand.patience = int(cand.patience) - 1
	counter_val = float(ev.counter)
	Sfx.play("error")
	if int(cand.patience) <= 0:
		cand.refuse_until = GameState.day + 2
		_say("%s Pazarlıktan yoruldum, vazgeçiyorum." % lines["no"])
		_lock()
	else:
		_say("%s %%%d işletme payına razıyım." % [lines["no"], int(roundf(counter_val * 100.0))])
		btn_counter.text = "Karşı teklifi kabul et (%%%d)" % int(roundf(counter_val * 100.0))
		btn_counter.visible = true
	_update_eval()


func _on_counter() -> void:
	if counter_val < 0.0:
		return
	slider.value = counter_val * 100.0
	_update_eval()
	_on_offer()


func _close() -> void:
	if not visible:
		return
	visible = false
	closed.emit()
