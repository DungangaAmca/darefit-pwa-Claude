class_name GameUI
extends CanvasLayer
## HUD, alt menü çubuğu, menü penceresi, bildirimler, başlangıç/gün sonu/oyun sonu ekranları.

const MENUS := [["workers", "Çalışanlar"], ["customers", "Müşteriler"], ["business", "İşletme"], ["finance", "Finans"],
	["upgrades", "Geliştirmeler"], ["quests", "Görevler"], ["map", "Harita"], ["inventory", "Envanter"], ["settings", "Ayarlar"]]

var main: Node
var business: Node
var root: Control
var money_lbl: Label
var time_lbl: Label
var rep_bar: ProgressBar
var rep_lbl: Label
var staff_lbl: Label
var wait_lbl: Label
var speed_btns: Array = []
var menu_center: CenterContainer
var menu_title: Label
var menu_body: VBoxContainer
var panels: Dictionary = {}
var menu_btns: Dictionary = {}
var current_menu := ""
var toast_box: VBoxContainer
var prompt_lbl: Label
var hire: HireDialog
var hire_center: CenterContainer
var hire_close_cb: Callable = Callable()
var start_overlay: Control
var popup_center: CenterContainer
var popup_box: VBoxContainer
var popup_open := false
var prev_speed := 1
var refresh_cd := 0.0
var dirty := false
var map_timer := 0.0


func setup(p_main: Node, p_business: Node) -> void:
	main = p_main
	business = p_business
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = UIKit.make_theme()
	add_child(root)
	_build_top_bar()
	_build_bottom_bar()
	_build_menu_window()
	_build_toasts_and_prompt()
	_build_hire()
	_build_popup()
	_build_start_overlay()
	GameState.money_changed.connect(_update_hud)
	GameState.time_changed.connect(_update_hud)
	GameState.reputation_changed.connect(_update_hud)
	GameState.speed_changed.connect(_update_hud)
	GameState.data_changed.connect(func(): dirty = true)
	GameState.data_changed.connect(_update_hud)
	GameState.notified.connect(toast)
	GameState.day_ended.connect(_show_day_report)
	GameState.game_over.connect(_show_game_over)
	_update_hud()


# ---------------- HUD ----------------
func _build_top_bar() -> void:
	var bar := PanelContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	root.add_child(bar)
	var h := UIKit.hbox(22)
	bar.add_child(h)
	money_lbl = UIKit.lbl("$0", 20, UIKit.GOOD)
	money_lbl.custom_minimum_size.x = 120
	h.add_child(money_lbl)
	time_lbl = UIKit.lbl("", 16)
	time_lbl.custom_minimum_size.x = 190
	h.add_child(time_lbl)
	var sp := UIKit.hbox(4)
	h.add_child(sp)
	for i in Config.SPEED_STEPS.size():
		var b := UIKit.btn(String(Config.SPEED_LABELS[i]), func(): GameState.set_speed(i))
		sp.add_child(b)
		speed_btns.append(b)
	var rep_box := UIKit.hbox(6)
	h.add_child(rep_box)
	rep_box.add_child(UIKit.lbl("İtibar", 14, UIKit.MUTED))
	rep_bar = UIKit.bar(0.0, UIKit.ACCENT, 110)
	rep_box.add_child(rep_bar)
	rep_lbl = UIKit.lbl("0", 14)
	rep_box.add_child(rep_lbl)
	staff_lbl = UIKit.lbl("", 15)
	h.add_child(staff_lbl)
	wait_lbl = UIKit.lbl("", 15)
	h.add_child(wait_lbl)


func _build_bottom_bar() -> void:
	var bar := PanelContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bar.grow_vertical = Control.GROW_DIRECTION_BEGIN
	root.add_child(bar)
	var h := UIKit.hbox(6)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	bar.add_child(h)
	var n := 1
	for m in MENUS:
		var id: String = m[0]
		var b := UIKit.btn("%d·%s" % [n, m[1]], func(): toggle_menu(id))
		h.add_child(b)
		menu_btns[id] = b
		n += 1


func _update_hud() -> void:
	if money_lbl == null:
		return
	money_lbl.text = UIKit.fmt_money(GameState.money)
	money_lbl.add_theme_color_override("font_color", UIKit.GOOD if GameState.debt <= 0.0 else UIKit.BAD)
	time_lbl.text = "Gün %d · %s · %s" % [GameState.day, GameState.clock_text(), Config.period_name(GameState.hour())]
	rep_bar.value = GameState.reputation
	rep_lbl.text = "%d" % int(GameState.reputation)
	staff_lbl.text = "Çalışan %d/%d" % [GameState.workers.size(), GameState.max_workers()]
	wait_lbl.text = "Bekleyen müşteri %d" % int(business.waiting_customer_count())
	for i in speed_btns.size():
		speed_btns[i].disabled = i == GameState.speed_index
	if not GameState.business_open:
		time_lbl.text += " · KAPALI"


# ---------------- Menü penceresi ----------------
func _make_panel(id: String) -> PanelBase:
	match id:
		"workers":
			return PanelWorkers.new()
		"customers":
			return PanelCustomers.new()
		"business":
			return PanelBusiness.new()
		"finance":
			return PanelFinance.new()
		"upgrades":
			return PanelUpgrades.new()
		"quests":
			return PanelQuests.new()
		"map":
			return PanelMap.new()
		"inventory":
			return PanelInventory.new()
	return PanelSettings.new()


func _build_menu_window() -> void:
	menu_center = CenterContainer.new()
	menu_center.set_anchors_preset(Control.PRESET_FULL_RECT)
	menu_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_center.visible = false
	root.add_child(menu_center)
	var win := PanelContainer.new()
	win.custom_minimum_size = Vector2(960, 540)
	menu_center.add_child(win)
	var v := UIKit.vbox(8)
	win.add_child(v)
	var head := UIKit.hbox(8)
	v.add_child(head)
	menu_title = UIKit.lbl("", 20, UIKit.ACCENT)
	menu_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(menu_title)
	head.add_child(UIKit.btn("Kapat (Esc)", close_menu))
	menu_body = UIKit.vbox(0)
	menu_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(menu_body)
	for m in MENUS:
		var p := _make_panel(m[0])
		p.setup(business)
		p.visible = false
		if m[0] == "settings":
			(p as PanelSettings).ui = self
		if m[0] == "map":
			(p as PanelMap).data_fn = Callable(main, "get_map_data")
		menu_body.add_child(p)
		panels[m[0]] = p


func open_menu(id: String) -> void:
	if popup_open or start_overlay.visible or hire.visible:
		return
	current_menu = id
	for k in panels:
		panels[k].visible = k == id
	for m in MENUS:
		if m[0] == id:
			menu_title.text = String(m[1])
	menu_center.visible = true
	panels[id].refresh()
	dirty = false
	for k in menu_btns:
		menu_btns[k].disabled = k == id
	Sfx.play("click")


func close_menu() -> void:
	current_menu = ""
	menu_center.visible = false
	for k in menu_btns:
		menu_btns[k].disabled = false


func toggle_menu(id: String) -> void:
	if current_menu == id:
		close_menu()
	else:
		open_menu(id)


# ---------------- Bildirim & ipucu ----------------
func _build_toasts_and_prompt() -> void:
	toast_box = UIKit.vbox(6)
	toast_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	toast_box.offset_top = 64
	toast_box.offset_left = -400
	toast_box.offset_right = -12
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(toast_box)
	prompt_lbl = UIKit.lbl("", 20, Color(1, 0.95, 0.7))
	prompt_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	prompt_lbl.add_theme_constant_override("outline_size", 8)
	prompt_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	prompt_lbl.grow_horizontal = Control.GROW_DIRECTION_BOTH
	prompt_lbl.grow_vertical = Control.GROW_DIRECTION_BEGIN
	prompt_lbl.offset_top = -110
	prompt_lbl.offset_bottom = -80
	prompt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(prompt_lbl)


func set_prompt(t: String) -> void:
	if prompt_lbl.text != t:
		prompt_lbl.text = t


func toast(msg: String, kind: String = "info") -> void:
	var col := {"info": Color(0.85, 0.9, 1.0), "good": UIKit.GOOD, "warn": UIKit.WARN, "bad": UIKit.BAD}.get(kind, Color.WHITE)
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := UIKit.wrap(msg, 14, col)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(l)
	toast_box.add_child(p)
	while toast_box.get_child_count() > 6:
		var old := toast_box.get_child(0)
		toast_box.remove_child(old)
		old.queue_free()
	var tw := p.create_tween()
	tw.tween_interval(5.5)
	tw.tween_property(p, "modulate:a", 0.0, 0.6)
	tw.tween_callback(p.queue_free)
	if kind == "warn" or kind == "bad":
		Sfx.play("error")
	else:
		Sfx.play("notify")


# ---------------- Çalışan görüşmesi ----------------
func _build_hire() -> void:
	hire_center = CenterContainer.new()
	hire_center.set_anchors_preset(Control.PRESET_FULL_RECT)
	hire_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hire_center.visible = false
	root.add_child(hire_center)
	hire = HireDialog.new()
	hire.setup(business)
	hire_center.add_child(hire)
	hire.closed.connect(func():
		hire_center.visible = false
		if hire_close_cb.is_valid():
			hire_close_cb.call()
		hire_close_cb = Callable())
	hire.visibility_changed.connect(func(): hire_center.visible = hire.visible)


func open_hire(cand: Dictionary, on_close: Callable) -> void:
	close_menu()
	hire_close_cb = on_close
	hire.open(cand)


# ---------------- Açılır pencereler ----------------
func _build_popup() -> void:
	popup_center = CenterContainer.new()
	popup_center.set_anchors_preset(Control.PRESET_FULL_RECT)
	popup_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	popup_center.visible = false
	root.add_child(popup_center)
	var p := PanelContainer.new()
	p.custom_minimum_size = Vector2(520, 0)
	popup_center.add_child(p)
	popup_box = UIKit.vbox(8)
	p.add_child(popup_box)


func _show_day_report(r: Dictionary) -> void:
	if GameState.is_game_over:
		return
	UIKit.clear(popup_box)
	popup_box.add_child(UIKit.lbl("Gün %d sona erdi" % int(r["day"]), 20, UIKit.ACCENT))
	for line in [
		["Görüşme sayısı", "%d" % int(r["sessions"])],
		["Komisyon geliri", UIKit.fmt_money(float(r["commission"]))],
		["Çalışanlara ödenen pay", UIKit.fmt_money(float(r["worker_pay"]))],
		["Kira + bakım", UIKit.fmt_money(float(r["rent"]) + float(r["maintenance"]))],
		["Yiyecek-içecek", UIKit.fmt_money(float(r["food"]))],
		["Yan haklar / eğitim / geliştirme", UIKit.fmt_money(float(r["perks"]) + float(r["training"]) + float(r["upgrade"]))],
		["Net sonuç", UIKit.fmt_money(float(r["net"]))],
		["Nakit", UIKit.fmt_money(float(r["cash"]))],
		["İtibar", "%.1f" % float(r["reputation"])],
	]:
		var row := UIKit.hbox(8)
		var l := UIKit.lbl(String(line[0]), 15, UIKit.MUTED)
		l.custom_minimum_size.x = 300
		row.add_child(l)
		row.add_child(UIKit.lbl(String(line[1]), 15))
		popup_box.add_child(row)
	if int(r["lost"]) > 0:
		popup_box.add_child(UIKit.lbl("Kaybedilen müşteri: %d" % int(r["lost"]), 14, UIKit.WARN))
	if float(r["debt"]) > 0.0:
		popup_box.add_child(UIKit.lbl("Ödenmemiş borç: %s" % UIKit.fmt_money(float(r["debt"])), 14, UIKit.BAD))
	if not (r["quits"] as Array).is_empty():
		popup_box.add_child(UIKit.wrap("Mutsuz çalışanlar ayrılmayı düşünüyor: %s" % ", ".join(r["quits"]), 14, UIKit.BAD))
	popup_box.add_child(UIKit.btn("Devam", _close_popup))
	prev_speed = GameState.speed_index if GameState.speed_index > 0 else 1
	GameState.set_speed(0)
	popup_open = true
	close_menu()
	popup_center.visible = true


func _close_popup() -> void:
	popup_open = false
	popup_center.visible = false
	if not GameState.is_game_over:
		GameState.set_speed(prev_speed)


func _show_game_over(reason: String) -> void:
	UIKit.clear(popup_box)
	popup_box.add_child(UIKit.lbl("OYUN BİTTİ", 22, UIKit.BAD))
	popup_box.add_child(UIKit.wrap(reason, 15, Color.WHITE))
	popup_box.add_child(UIKit.lbl("Gün %d · Kazanılan itibar: %d" % [GameState.day, int(GameState.reputation)], 14, UIKit.MUTED))
	var row := UIKit.hbox(8)
	popup_box.add_child(row)
	row.add_child(UIKit.btn("Son kayıttan yükle", func():
		popup_center.visible = false
		popup_open = false
		main.load_game(), not SaveSystem.has_save()))
	row.add_child(UIKit.btn("Yeni oyun", func():
		popup_center.visible = false
		popup_open = false
		main.new_game()))
	popup_open = true
	close_menu()
	popup_center.visible = true


# ---------------- Başlangıç ekranı ----------------
func _build_start_overlay() -> void:
	start_overlay = ColorRect.new()
	(start_overlay as ColorRect).color = Color(0.04, 0.03, 0.08, 0.96)
	start_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	start_overlay.visible = false
	root.add_child(start_overlay)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	start_overlay.add_child(cc)
	var v := UIKit.vbox(12)
	cc.add_child(v)
	var t := UIKit.lbl("PIMP SIMULATOR", 56, UIKit.ACCENT)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var sub := UIKit.lbl("Küçük bir mekândan büyük bir işletmeye — gönüllü sözleşmeler, adil pazarlık, iyi yönetim.", 16, UIKit.MUTED)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(sub)
	v.add_child(Control.new())
	var b_cont := UIKit.btn("Devam et", func(): main.load_game())
	b_cont.name = "Continue"
	v.add_child(b_cont)
	v.add_child(UIKit.btn("Yeni oyun", func(): main.new_game()))
	v.add_child(UIKit.btn("Çıkış", func(): main.get_tree().quit()))
	var ver := UIKit.lbl("Sürüm %s  ·  Yetişkin karakterler, grafik olmayan içerik" % Config.VERSION, 12, UIKit.MUTED)
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(ver)


func show_start_menu(has_save: bool) -> void:
	(start_overlay.find_child("Continue", true, false) as Button).disabled = not has_save
	start_overlay.visible = true


func hide_start_menu() -> void:
	start_overlay.visible = false
	popup_center.visible = false
	popup_open = false
	close_menu()


# ---------------- Durum / girdi ----------------
func blocking() -> bool:
	return start_overlay.visible or popup_open or hire.visible


func blocking_movement() -> bool:
	return blocking()


func refresh_name_labels() -> void:
	var lists: Array = [business.worker_actors.values(), business.customer_actors.values(), main.npcs.cand_actors.values()]
	for l in lists:
		for a in l:
			if is_instance_valid(a):
				a.set_label(a.name_label.text)


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if start_overlay.visible:
		return
	var k: int = event.physical_keycode
	if k == KEY_ESCAPE:
		if hire.visible:
			hire._close()
		elif current_menu != "":
			close_menu()
		else:
			return
		get_viewport().set_input_as_handled()
		return
	if blocking():
		return
	if k >= KEY_1 and k <= KEY_9:
		toggle_menu(String(MENUS[k - KEY_1][0]))
	elif k == KEY_SPACE:
		GameState.set_speed(1 if GameState.speed_index == 0 else 0)
	elif k == KEY_F5:
		main.save_now()
	elif k == KEY_F9:
		if SaveSystem.has_save():
			main.load_game()
	else:
		return
	get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	if current_menu == "":
		return
	if current_menu == "map":
		map_timer -= delta
		if map_timer <= 0.0:
			map_timer = 0.25
			panels["map"].refresh()
		return
	if dirty:
		refresh_cd -= delta
		if refresh_cd <= 0.0 and not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			refresh_cd = 0.8
			dirty = false
			panels[current_menu].refresh()
