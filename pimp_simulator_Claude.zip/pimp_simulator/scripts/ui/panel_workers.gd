class_name PanelWorkers
extends PanelBase

var sel: int = -1
var confirm_release: int = -1


func build(c: VBoxContainer) -> void:
	var ws: Array = GameState.workers
	c.add_child(UIKit.lbl("Çalışanlar  (%d / %d kapasite)" % [ws.size(), GameState.max_workers()], 18, UIKit.ACCENT))
	if ws.is_empty():
		c.add_child(UIKit.wrap("Henüz çalışanın yok. Şehirde dolaş, potansiyel çalışanlara yaklaşıp E tuşuyla konuş ve gönüllü bir sözleşme için pazarlık yap."))
		return
	if GameState.get_worker(sel).is_empty():
		sel = int(ws[0].id)
	var row := UIKit.hbox(14)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.add_child(row)
	var left := UIKit.vbox(6)
	left.custom_minimum_size.x = 280
	row.add_child(left)
	for w in ws:
		var id := int(w.id)
		var b := UIKit.btn("%s — %s" % [w.name, business.worker_status(id)], func():
			sel = id
			confirm_release = -1
			refresh())
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.disabled = id == sel
		b.clip_text = true
		left.add_child(b)
	var right := UIKit.vbox(6)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(right)
	_detail(right, GameState.get_worker(sel))


func _detail(r: VBoxContainer, w: Dictionary) -> void:
	var id := int(w.id)
	r.add_child(UIKit.lbl("%s  ·  %d yaş  ·  %s" % [w.name, int(w.age), w.personality], 17))
	r.add_child(UIKit.lbl("Durum: %s" % business.worker_status(id), 14, UIKit.GOOD))
	r.add_child(UIKit.stat_row("Enerji", float(w.energy), UIKit.GOOD))
	r.add_child(UIKit.stat_row("Açlık", float(w.hunger), UIKit.BAD))
	r.add_child(UIKit.stat_row("Susuzluk", float(w.thirst), UIKit.BAD))
	r.add_child(UIKit.stat_row("Memnuniyet", float(w.satisfaction), UIKit.ACCENT))
	r.add_child(UIKit.sep())
	for k in Config.SKILL_ORDER:
		r.add_child(UIKit.stat_row(String(Config.SKILLS[k]), float(w[k]), Color(0.45, 0.65, 0.95)))
	r.add_child(UIKit.sep())
	var share := 1.0 - float(w.commission)
	r.add_child(UIKit.lbl("Komisyon: işletme %%%d / çalışan %%%d" % [int(roundf(float(w.commission) * 100.0)), int(roundf(share * 100.0))], 14))
	r.add_child(UIKit.lbl("Vardiya: %s" % Config.shift_name(String(w.shift)), 14, UIKit.MUTED))
	var perk_names: Array = []
	for p in w.perks:
		perk_names.append(String(Config.PERKS[p]["name"]))
	r.add_child(UIKit.lbl("Ek haklar: %s" % (", ".join(perk_names) if not perk_names.is_empty() else "yok"), 14, UIKit.MUTED))
	r.add_child(UIKit.lbl("Bekleme süresi: %d dk  ·  Bugünkü görüşme: %d/%d" % [business.waiting_minutes(id), int(w.sessions_today), Economy.daily_capacity(w)], 14, UIKit.MUTED))
	r.add_child(UIKit.lbl("Toplam kazancı: %s  ·  İşletmeye getirdiği: %s  ·  Görüşme: %d" % [UIKit.fmt_money(float(w.total_earned)), UIKit.fmt_money(float(w.revenue)), int(w.sessions)], 14, UIKit.MUTED))
	r.add_child(UIKit.lbl("Standart görüşme fiyatı: %s" % UIKit.fmt_money(Economy.session_price(w, "standard")), 14, UIKit.MUTED))
	if bool(w.get("wants_raise", false)):
		r.add_child(UIKit.lbl("Zam talep ediyor (yetenekleri arttı).", 14, UIKit.WARN))
	r.add_child(UIKit.sep())
	var items := UIKit.hbox(6)
	r.add_child(items)
	for it in Config.ITEM_ORDER:
		var stock := int(GameState.inventory.get(it, 0))
		var b := UIKit.btn("%s (%d)" % [Config.ITEMS[it]["name"], stock], func():
			var e: String = business.give_item(id, it)
			if e != "":
				toast(e, "warn")
			refresh(), stock <= 0)
		items.add_child(b)
	var acts := UIKit.hbox(6)
	r.add_child(acts)
	acts.add_child(UIKit.btn("Dinlenmeye gönder", func():
		var e: String = business.send_rest(id)
		if e != "":
			toast(e, "warn")
		refresh()))
	acts.add_child(UIKit.btn("Zam yap (-5% komisyon)", func():
		var e: String = business.give_raise(id)
		if e != "":
			toast(e, "warn")
		refresh()))
	var rel_text := "Sözleşmeyi feshet" if confirm_release != id else "Emin misin? Tekrar tıkla"
	acts.add_child(UIKit.btn(rel_text, func():
		if confirm_release != id:
			confirm_release = id
		else:
			var e: String = business.release_worker(id)
			confirm_release = -1
			if e != "":
				toast(e, "warn")
		refresh()))
