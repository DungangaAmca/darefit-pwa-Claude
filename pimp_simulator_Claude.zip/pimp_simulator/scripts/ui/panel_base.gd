class_name PanelBase
extends VBoxContainer
## Menü panellerinin ortak iskeleti: kaydırılabilir içerik + refresh() ile yeniden çizim.

var business: Node
var scroll: ScrollContainer
var content: VBoxContainer


func setup(b: Node) -> void:
	business = b
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_build_frame()


func _build_frame() -> void:
	scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	content = UIKit.vbox(8)
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(content)


func refresh() -> void:
	var sv := scroll.scroll_vertical if scroll else 0
	UIKit.clear(content)
	build(content)
	if scroll:
		scroll.set_deferred("scroll_vertical", sv)


func build(_c: VBoxContainer) -> void:
	pass


func toast(msg: String, kind: String = "info") -> void:
	GameState.notify(msg, kind)
