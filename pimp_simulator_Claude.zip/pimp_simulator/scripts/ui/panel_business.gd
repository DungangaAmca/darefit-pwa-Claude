class_name PanelBusiness
extends PanelBase


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl(GameState.business_name, 20, UIKit.ACCENT))
	var top := UIKit.hbox(12)
	c.add_child(top)
	top.add_child(UIKit.btn("İşletme: AÇIK (kapat)" if GameState.business_open else "İşletme: KAPALI (aç)", func():
		business.toggle_open()
		refresh()))
	top.add_child(UIKit.lbl("İtibar: %.1f / 100   ·   Oyuncu seviyesi: %d" % [GameState.reputation, GameState.player_level()], 15))
	c.add_child(UIKit.stat_row("İtibar", GameState.reputation, UIKit.ACCENT, 260))
	var st := GameState.daily(GameState.day)
	c.add_child(UIKit.lbl("Bugün: %d görüşme  ·  komisyon %s  ·  kaybedilen müşteri %d" % [int(st.sessions), UIKit.fmt_money(float(st.commission)), int(st.lost)], 14, UIKit.MUTED))
	c.add_child(UIKit.lbl("Kapasite: %d/%d oda  ·  %d/%d çalışan  ·  %d bekleme koltuğu  ·  Depo %d/%d" % [GameState.rooms_unlocked(), Config.MAX_ROOMS, GameState.workers.size(), GameState.max_workers(), GameState.waiting_capacity(), GameState.inventory_total(), GameState.storage_capacity()], 14, UIKit.MUTED))
	c.add_child(UIKit.lbl("Günlük sabit gider: kira %s + bakım %s" % [UIKit.fmt_money(Economy.rent_today()), UIKit.fmt_money(Economy.maintenance_today())], 14, UIKit.MUTED))
	c.add_child(UIKit.sep())
	c.add_child(UIKit.lbl("Odalar", 16, UIKit.ACCENT))
	var names := {"locked": "Kilitli", "free": "Boş", "reserved": "Rezerve", "busy": "Görüşmede", "cleaning": "Temizleniyor"}
	var cols := {"locked": UIKit.MUTED, "free": UIKit.GOOD, "reserved": UIKit.WARN, "busy": UIKit.BAD, "cleaning": UIKit.WARN}
	for i in business.rooms.size():
		var r: Dictionary = business.rooms[i]
		var s := String(r["state"])
		var txt := "Oda %d: %s" % [i + 1, names[s]]
		if s == "busy":
			var w := GameState.get_worker(int(r["worker"]))
			txt += "  ·  %s  ·  kalan %d dk" % [String(w.get("name", "?")), int(ceilf(float(r["timer"])))]
		elif s == "cleaning":
			txt += "  ·  %d dk" % int(ceilf(float(r["timer"])))
		c.add_child(UIKit.lbl(txt, 14, cols[s]))
	c.add_child(UIKit.sep())
	c.add_child(UIKit.lbl("Yönetim notları", 16, UIKit.ACCENT))
	var adv: Array = business.advice()
	if adv.is_empty():
		c.add_child(UIKit.lbl("Her şey yolunda görünüyor.", 14, UIKit.GOOD))
	for a in adv:
		c.add_child(UIKit.wrap("• " + String(a), 14, UIKit.WARN))
