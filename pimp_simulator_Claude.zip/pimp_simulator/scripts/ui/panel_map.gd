class_name PanelMap
extends PanelBase
## Harita: şehir veya (içerideyken) işletme krokisi.

var map_view: Control
var data_fn: Callable


func _build_frame() -> void:
	map_view = Control.new()
	map_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map_view.custom_minimum_size = Vector2(800, 440)
	map_view.draw.connect(_draw_map)
	add_child(map_view)


func refresh() -> void:
	if map_view:
		map_view.queue_redraw()


func _w2m(p: Vector3, sc: float, off: Vector2) -> Vector2:
	return off + Vector2(p.x, p.z) * sc


func _draw_map() -> void:
	var d: Dictionary = data_fn.call()
	var sz := map_view.size
	var font := ThemeDB.fallback_font
	map_view.draw_rect(Rect2(Vector2.ZERO, sz), Color(0.05, 0.07, 0.1))
	if bool(d["interior"]):
		_draw_interior(d, sz, font)
		return
	var sc := minf(sz.x / 124.0, sz.y / 94.0)
	var off := sz * 0.5
	map_view.draw_rect(Rect2(off + Vector2(-60, -45) * sc, Vector2(120, 90) * sc), Color(0.16, 0.22, 0.16))
	map_view.draw_rect(Rect2(off + Vector2(-60, -5) * sc, Vector2(120, 10) * sc), Color(0.25, 0.25, 0.28))
	map_view.draw_rect(Rect2(off + Vector2(-25, -45) * sc, Vector2(10, 90) * sc), Color(0.25, 0.25, 0.28))
	map_view.draw_rect(Rect2(off + Vector2(15, -45) * sc, Vector2(10, 90) * sc), Color(0.25, 0.25, 0.28))
	for b in d["buildings"]:
		var r: Rect2 = b["rect"]
		var col := Color(0.2, 0.5, 0.25) if b.get("park", false) else Color(0.45, 0.4, 0.5)
		if String(b["name"]) == "GECE SALONU":
			col = Color(0.8, 0.25, 0.4)
		map_view.draw_rect(Rect2(off + r.position * sc, r.size * sc), col)
		map_view.draw_string(font, off + (r.position + Vector2(1.5, r.size.y * 0.5)) * sc, String(b["name"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	for p in d["candidates"]:
		map_view.draw_circle(_w2m(p, sc, off), 4.0, Color(1.0, 0.85, 0.2))
	map_view.draw_circle(_w2m(d["player"], sc, off), 6.0, Color(1.0, 0.45, 0.1))
	map_view.draw_string(font, Vector2(10, sz.y - 10), "Turuncu: sen · Sarı: potansiyel çalışanlar · Pembe bina: işletmen", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, UIKit.MUTED)


func _draw_interior(d: Dictionary, sz: Vector2, font: Font) -> void:
	var o: Vector3 = d["origin"]
	var sc := minf(sz.x / 34.0, sz.y / 28.0)
	var off := sz * 0.5
	map_view.draw_rect(Rect2(off + Vector2(-15, -12) * sc, Vector2(30, 24) * sc), Color(0.3, 0.22, 0.16))
	var cols := {"locked": Color(0.25, 0.25, 0.25), "free": Color(0.2, 0.7, 0.3), "reserved": Color(0.9, 0.8, 0.2), "busy": Color(0.85, 0.2, 0.2), "cleaning": Color(0.9, 0.5, 0.1)}
	for i in 6:
		var r: Dictionary = d["rooms"][i]
		var cx := -12.5 + 5.0 * i
		map_view.draw_rect(Rect2(off + Vector2(cx - 2.3, -11.8) * sc, Vector2(4.6, 5.6) * sc), cols[String(r["state"])])
		map_view.draw_string(font, off + Vector2(cx - 1.2, -9.0) * sc, "Oda %d" % (i + 1), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	map_view.draw_string(font, off + Vector2(-14, 8) * sc, "Bekleme", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	map_view.draw_string(font, off + Vector2(-13, -1) * sc, "Personel", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	map_view.draw_string(font, off + Vector2(7, -1) * sc, "Dinlenme", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	map_view.draw_string(font, off + Vector2(5, 10) * sc, "Resepsiyon", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	map_view.draw_string(font, off + Vector2(10, 4) * sc, "Mutfak", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	for p in d["workers"]:
		map_view.draw_circle(off + Vector2(p.x - o.x, p.z - o.z) * sc, 4.0, Color(0.4, 1.0, 0.5))
	for p in d["customers"]:
		map_view.draw_circle(off + Vector2(p.x - o.x, p.z - o.z) * sc, 4.0, Color(0.5, 0.7, 1.0))
	var pp: Vector3 = d["player"]
	map_view.draw_circle(off + Vector2(pp.x - o.x, pp.z - o.z) * sc, 6.0, Color(1.0, 0.45, 0.1))
	map_view.draw_string(font, Vector2(10, sz.y - 10), "Turuncu: sen · Yeşil: çalışanlar · Mavi: müşteriler", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, UIKit.MUTED)
