class_name PanelSettings
extends PanelBase

var ui: Node
var confirm_new := false


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl("Ayarlar", 20, UIKit.ACCENT))
	var vrow := UIKit.hbox(10)
	c.add_child(vrow)
	vrow.add_child(UIKit.lbl("Ses seviyesi", 15))
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.value = float(SaveSystem.settings["volume"])
	sl.custom_minimum_size.x = 220
	sl.value_changed.connect(func(v):
		SaveSystem.settings["volume"] = v
		SaveSystem.apply_settings()
		SaveSystem.save_settings())
	vrow.add_child(sl)
	var amb := CheckButton.new()
	amb.text = "Şehir ortam sesi"
	amb.button_pressed = bool(SaveSystem.settings["ambient"])
	amb.toggled.connect(func(on):
		SaveSystem.settings["ambient"] = on
		Sfx.set_ambient(on)
		SaveSystem.save_settings())
	c.add_child(amb)
	var asv := CheckButton.new()
	asv.text = "Otomatik kayıt (her gün sonunda ve 2 dakikada bir)"
	asv.button_pressed = bool(SaveSystem.settings["autosave"])
	asv.toggled.connect(func(on):
		SaveSystem.settings["autosave"] = on
		SaveSystem.save_settings())
	c.add_child(asv)
	var nm := CheckButton.new()
	nm.text = "Karakter isimlerini göster"
	nm.button_pressed = bool(SaveSystem.settings["names"])
	nm.toggled.connect(func(on):
		SaveSystem.settings["names"] = on
		SaveSystem.apply_settings()
		SaveSystem.save_settings()
		ui.refresh_name_labels())
	c.add_child(nm)
	c.add_child(UIKit.sep())
	var row := UIKit.hbox(8)
	c.add_child(row)
	row.add_child(UIKit.btn("Şimdi kaydet", func(): ui.main.save_now()))
	row.add_child(UIKit.btn("Son kaydı yükle", func(): ui.main.load_game(), not SaveSystem.has_save()))
	row.add_child(UIKit.btn("Yeni oyun" if not confirm_new else "Emin misin? İlerleme silinir — tekrar tıkla", func():
		if confirm_new:
			confirm_new = false
			ui.main.new_game()
		else:
			confirm_new = true
			refresh()))
	row.add_child(UIKit.btn("Oyundan çık", func(): ui.main.get_tree().quit()))
	c.add_child(UIKit.sep())
	c.add_child(UIKit.lbl("Kontroller", 16, UIKit.ACCENT))
	c.add_child(UIKit.wrap("WASD / Ok tuşları: yürü  ·  Shift: koş  ·  E: etkileşim (konuş, kapı, resepsiyon, mutfak)\nQ / R: kamerayı döndür  ·  Fare tekerleği: yakınlaş/uzaklaş\n1–9: menüler  ·  Esc: menüyü kapat  ·  Boşluk: duraklat/devam  ·  F5: hızlı kayıt  ·  F9: hızlı yükle", 14, UIKit.MUTED))
	c.add_child(UIKit.lbl("Sürüm: %s" % Config.VERSION, 12, UIKit.MUTED))
