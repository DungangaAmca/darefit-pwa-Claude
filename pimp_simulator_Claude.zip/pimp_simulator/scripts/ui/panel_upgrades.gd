class_name PanelUpgrades
extends PanelBase

var train_sel: int = -1


func _buy(id: String) -> void:
	var e := Economy.buy_upgrade(id)
	if e != "":
		toast(e, "warn")
		Sfx.play("error")
	refresh()


func _train(wid: int, skill: String) -> void:
	var e: String = business.start_training(wid, skill)
	if e != "":
		toast(e, "warn")
		Sfx.play("error")
	refresh()


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl("Geliştirmeler", 20, UIKit.ACCENT))
	c.add_child(UIKit.lbl("Nakit: %s   ·   İtibar: %.1f" % [UIKit.fmt_money(GameState.money), GameState.reputation], 14, UIKit.MUTED))
	c.add_child(UIKit.lbl("İşletme geliştirmeleri", 16, UIKit.ACCENT))
	for id in Config.UPGRADE_ORDER:
		var u: Dictionary = Config.UPGRADES[id]
		var s := Economy.upgrade_status(id)
		var card := UIKit.card()
		c.add_child(card)
		var row := UIKit.hbox(12)
		card.add_child(row)
		var info := UIKit.vbox(2)
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(info)
		var nm := String(u["name"])
		if id == "rooms":
			nm += " (oda %d → %d)" % [GameState.rooms_unlocked(), GameState.rooms_unlocked() + 1] if int(s.level) < int(s.max) else ""
		info.add_child(UIKit.lbl("%s   [%d/%d]" % [nm, int(s.level), int(s.max)], 15))
		info.add_child(UIKit.wrap(String(u["desc"]), 13))
		var text := "Maksimum"
		if int(s.level) < int(s.max):
			text = "Satın al  %s" % UIKit.fmt_money(float(s.cost))
			if String(s.reason) != "" and not bool(s.can):
				text += "\n(%s)" % s.reason
		var b := UIKit.btn(text, _buy.bind(id), not bool(s.can))
		b.custom_minimum_size.x = 170
		row.add_child(b)
	c.add_child(UIKit.sep())
	c.add_child(UIKit.lbl("Çalışan eğitimi", 16, UIKit.ACCENT))
	if not bool(GameState.unlocks.get("training", false)):
		c.add_child(UIKit.wrap("Eğitim, 'İlk müşteriyi karşıla' görevi tamamlanınca açılır.", 14, UIKit.WARN))
		return
	if GameState.workers.is_empty():
		c.add_child(UIKit.wrap("Eğitim için önce bir çalışan işe al.", 14))
		return
	if GameState.get_worker(train_sel).is_empty():
		train_sel = int(GameState.workers[0].id)
	var opt := OptionButton.new()
	for w in GameState.workers:
		opt.add_item(String(w.name), int(w.id))
	opt.select(maxi(0, opt.get_item_index(train_sel)))
	opt.item_selected.connect(func(i):
		train_sel = opt.get_item_id(i)
		refresh())
	c.add_child(opt)
	var w := GameState.get_worker(train_sel)
	c.add_child(UIKit.lbl("Durum: %s  ·  Eğitim süresi: %d saat, çalışan bu sürede görüşmeye çıkamaz." % [business.worker_status(train_sel), int(Economy.training_minutes() / 60.0)], 13, UIKit.MUTED))
	for k in Config.SKILL_ORDER:
		var row := UIKit.hbox(10)
		c.add_child(row)
		var l := UIKit.lbl(String(Config.SKILLS[k]), 14)
		l.custom_minimum_size.x = 170
		row.add_child(l)
		row.add_child(UIKit.bar(float(w[k]), Color(0.45, 0.65, 0.95), 160))
		row.add_child(UIKit.lbl("%d" % int(float(w[k])), 14))
		var cost := Economy.training_cost(w, k)
		row.add_child(UIKit.btn("Eğit  %s" % UIKit.fmt_money(cost), _train.bind(train_sel, k), GameState.money < cost or float(w[k]) >= 100.0))
