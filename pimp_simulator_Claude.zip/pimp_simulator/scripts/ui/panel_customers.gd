class_name PanelCustomers
extends PanelBase

var choice: Dictionary = {}


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl("Müşteriler", 18, UIKit.ACCENT))
	var top := UIKit.hbox(14)
	c.add_child(top)
	var auto := CheckButton.new()
	auto.text = "Otomatik eşleştirme"
	auto.button_pressed = GameState.auto_match
	auto.toggled.connect(func(on):
		GameState.auto_match = on
		GameState.data_changed.emit())
	top.add_child(auto)
	top.add_child(UIKit.lbl("Hizmet verilen: %d  ·  Kaybedilen: %d  ·  Boş oda: %d" % [int(GameState.stats.get("customers_served", 0)), int(GameState.stats.get("customers_lost", 0)), business.free_rooms_count()], 14, UIKit.MUTED))
	c.add_child(UIKit.wrap("Otomatik kapalıyken müşteriler bekleme alanında oturur; aşağıdan çalışan seçip 'Ata' ile eşleştirirsin. Açıkken de elle atama yapabilirsin."))
	if GameState.customers.is_empty():
		c.add_child(UIKit.lbl("Şu an işletmede müşteri yok.", 15, UIKit.MUTED))
		return
	var avail: Array = business.available_workers()
	for cu in GameState.customers:
		var cid := int(cu.id)
		var card := UIKit.card()
		c.add_child(card)
		var inner := UIKit.vbox(4)
		card.add_child(inner)
		inner.add_child(UIKit.lbl("%s  ·  %d yaş  ·  Bütçe %s  ·  Tercih: %s" % [cu.name, int(cu.age), UIKit.fmt_money(float(cu.budget)), Config.PREF_NAMES.get(String(cu.pref), "-")], 15))
		inner.add_child(UIKit.lbl("Durum: %s  ·  Bekleme: %d / %d dk" % [business.customer_status(cu), int(cu.wait), int(float(cu.wait_tol) * (1.0 + 0.12 * GameState.ulevel("chairs")))], 13, UIKit.MUTED))
		if String(cu.state) in ["choosing", "waiting", "to_seat"]:
			var row := UIKit.hbox(8)
			inner.add_child(row)
			if avail.is_empty():
				row.add_child(UIKit.lbl("Müsait çalışan yok.", 13, UIKit.WARN))
			else:
				var opt := OptionButton.new()
				for w in avail:
					opt.add_item("%s (%s)" % [w.name, UIKit.fmt_money(Economy.session_price(w, "standard"))], int(w.id))
				var pre := int(choice.get(cid, int(avail[0].id)))
				var idx := opt.get_item_index(pre)
				opt.select(idx if idx >= 0 else 0)
				opt.item_selected.connect(func(i): choice[cid] = opt.get_item_id(i))
				row.add_child(opt)
				row.add_child(UIKit.btn("Ata", func():
					var e: String = business.assign_manual(cid, opt.get_item_id(opt.selected))
					if e != "":
						toast(e, "warn")
					refresh()))
