class_name UIKit
extends RefCounted
## Arayüz yardımcıları: tema, etiket/düğme üreticileri, para biçimi.

const PANEL := Color(0.11, 0.13, 0.19, 0.98)
const PANEL2 := Color(0.16, 0.18, 0.26, 1.0)
const ACCENT := Color(0.96, 0.66, 0.22)
const GOOD := Color(0.45, 0.85, 0.5)
const BAD := Color(0.95, 0.42, 0.42)
const WARN := Color(0.98, 0.8, 0.35)
const MUTED := Color(0.66, 0.69, 0.78)


static func fmt_money(v: float) -> String:
	var neg := v < -0.5
	var s := str(int(roundf(absf(v))))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "," + out
	return ("-$" if neg else "$") + out


static func flat(color: Color, radius: int = 8, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(radius)
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 7
	sb.content_margin_bottom = 7
	return sb


static func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 15
	t.set_stylebox("panel", "PanelContainer", flat(PANEL, 10, Color(0.3, 0.33, 0.45), 1))
	t.set_stylebox("normal", "Button", flat(Color(0.2, 0.23, 0.33), 6))
	t.set_stylebox("hover", "Button", flat(Color(0.28, 0.32, 0.46), 6))
	t.set_stylebox("pressed", "Button", flat(ACCENT.darkened(0.35), 6))
	t.set_stylebox("disabled", "Button", flat(Color(0.13, 0.14, 0.19), 6))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for cls2 in ["CheckBox", "CheckButton"]:
		t.set_color("font_pressed_color", cls2, ACCENT)
		t.set_color("font_hover_pressed_color", cls2, ACCENT)
	for cls in ["CheckBox", "CheckButton"]:
		for st in ["normal", "hover", "pressed", "disabled", "hover_pressed", "focus"]:
			var e := StyleBoxEmpty.new()
			e.content_margin_top = 2
			e.content_margin_bottom = 2
			t.set_stylebox(st, cls, e)
	t.set_color("font_disabled_color", "Button", Color(0.45, 0.47, 0.55))
	t.set_stylebox("background", "ProgressBar", flat(Color(0.05, 0.06, 0.09), 4))
	t.set_stylebox("fill", "ProgressBar", flat(ACCENT, 4))
	return t


static func lbl(text: String, size: int = 15, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func wrap(text: String, size: int = 14, color: Color = MUTED, width: int = 0) -> Label:
	var l := lbl(text, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if width > 0:
		l.custom_minimum_size.x = width
	else:
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


static func btn(text: String, cb: Callable, disabled: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.disabled = disabled
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(func():
		Sfx.play("click")
		cb.call())
	return b


static func vbox(sep: int = 6) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v


static func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h


static func bar(value: float, color: Color = ACCENT, w: int = 140) -> ProgressBar:
	var p := ProgressBar.new()
	p.min_value = 0.0
	p.max_value = 100.0
	p.value = clampf(value, 0.0, 100.0)
	p.show_percentage = false
	p.custom_minimum_size = Vector2(w, 14)
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_theme_stylebox_override("fill", flat(color, 4))
	return p


static func stat_row(name: String, value: float, color: Color = ACCENT, w: int = 150) -> HBoxContainer:
	var h := hbox(8)
	var l := lbl(name, 14, MUTED)
	l.custom_minimum_size.x = 150
	h.add_child(l)
	h.add_child(bar(value, color, w))
	h.add_child(lbl("%d" % int(roundf(value)), 14))
	return h


static func card(inner_sep: int = 6) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", flat(PANEL2, 8))
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return p


static func clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


static func sep() -> HSeparator:
	return HSeparator.new()
