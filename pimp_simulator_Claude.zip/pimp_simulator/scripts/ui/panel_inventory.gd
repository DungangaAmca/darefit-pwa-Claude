class_name PanelInventory
extends PanelBase


func _buy(id: String, n: int) -> void:
	var e := Economy.buy_item(id, n)
	if e != "":
		toast(e, "warn")
		Sfx.play("error")
	refresh()


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl("Envanter ve Sipariş", 20, UIKit.ACCENT))
	c.add_child(UIKit.lbl("Depo: %d / %d   ·   Nakit: %s" % [GameState.inventory_total(), GameState.storage_capacity(), UIKit.fmt_money(GameState.money)], 15))
	c.add_child(UIKit.bar(float(GameState.inventory_total()) / float(GameState.storage_capacity()) * 100.0, UIKit.ACCENT, 300))
	c.add_child(UIKit.wrap("Çalışanlar ihtiyaçları artınca mutfağa gider ve buradaki stoktan kullanır. Stok biterse memnuniyetleri düşer. Sipariş anında depoya teslim edilir.", 13))
	for id in Config.ITEM_ORDER:
		var it: Dictionary = Config.ITEMS[id]
		var locked := bool(it.get("needs_kitchen", false)) and GameState.ulevel("kitchen") < 1
		var card := UIKit.card()
		c.add_child(card)
		var row := UIKit.hbox(10)
		card.add_child(row)
		var info := UIKit.vbox(2)
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(info)
		info.add_child(UIKit.lbl("%s   ·   Stok: %d   ·   Birim: %s" % [it["name"], int(GameState.inventory.get(id, 0)), UIKit.fmt_money(float(it["price"]))], 15, UIKit.MUTED if locked else Color.WHITE))
		info.add_child(UIKit.lbl(String(it["desc"]) + ("  [Mutfak gerekli]" if locked else ""), 13, UIKit.MUTED))
		for n in [1, 5, 10]:
			row.add_child(UIKit.btn("+%d" % n, _buy.bind(id, n), locked))
