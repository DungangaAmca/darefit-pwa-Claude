class_name PanelQuests
extends PanelBase


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl("Görevler  (%d / %d tamamlandı)" % [GameState.quests_done.size(), Config.QUESTS.size()], 20, UIKit.ACCENT))
	c.add_child(UIKit.lbl("XP: %d  ·  Oyuncu seviyesi: %d (pazarlıkta çalışanların güvenini artırır)" % [int(GameState.xp), GameState.player_level()], 14, UIKit.MUTED))
	for q in Config.QUESTS:
		var done: bool = GameState.quests_done.has(q["id"])
		var card := UIKit.card()
		c.add_child(card)
		var inner := UIKit.vbox(3)
		card.add_child(inner)
		var title := UIKit.lbl(("[✓] " if done else "[ ] ") + String(q["title"]), 16, UIKit.GOOD if done else Color.WHITE)
		inner.add_child(title)
		inner.add_child(UIKit.wrap(String(q["desc"]), 13))
		var cur := minf(QuestSystem.value_of(String(q["stat"])), float(q["target"]))
		var pct := cur / float(q["target"]) * 100.0
		var row := UIKit.hbox(8)
		inner.add_child(row)
		row.add_child(UIKit.bar(pct, UIKit.GOOD if done else UIKit.ACCENT, 220))
		row.add_child(UIKit.lbl("%d / %d" % [int(cur), int(q["target"])], 13))
		var rew := "Ödül: %d$, %d XP" % [int(q["money"]), int(q["xp"])]
		if String(q["unlock"]) != "":
			rew += ", yeni özellik: %s" % Config.UNLOCK_NAMES.get(String(q["unlock"]), q["unlock"])
		row.add_child(UIKit.lbl(rew, 13, UIKit.MUTED))
