class_name PanelFinance
extends PanelBase


func _row(c: VBoxContainer, name: String, value: float, color: Color = Color.WHITE) -> void:
	var h := UIKit.hbox(8)
	var l := UIKit.lbl(name, 14, UIKit.MUTED)
	l.custom_minimum_size.x = 250
	h.add_child(l)
	h.add_child(UIKit.lbl(UIKit.fmt_money(value), 14, color))
	c.add_child(h)


func _sum(days: Array, key: String) -> float:
	var s := 0.0
	for d in days:
		s += float(GameState.daily(int(d)).get(key, 0.0))
	return s


func _block(c: VBoxContainer, title: String, days: Array) -> void:
	c.add_child(UIKit.lbl(title, 16, UIKit.ACCENT))
	var income := _sum(days, "commission")
	var exp_keys := ["food", "rent", "maintenance", "upgrade", "training", "perks"]
	var expenses := 0.0
	for k in exp_keys:
		expenses += _sum(days, k)
	_row(c, "Komisyon geliri (işletmenin kazancı)", income, UIKit.GOOD)
	_row(c, "Çalışanlara ödenen pay (bilgi)", _sum(days, "worker_pay"))
	_row(c, "Yiyecek-içecek giderleri", _sum(days, "food"), UIKit.BAD)
	_row(c, "Kira", _sum(days, "rent"), UIKit.BAD)
	_row(c, "Bakım giderleri", _sum(days, "maintenance"), UIKit.BAD)
	_row(c, "Geliştirme maliyetleri", _sum(days, "upgrade"), UIKit.BAD)
	_row(c, "Eğitim giderleri", _sum(days, "training"), UIKit.BAD)
	_row(c, "Yan haklar / primler", _sum(days, "perks"), UIKit.BAD)
	_row(c, "Görev ödülleri", _sum(days, "reward"), UIKit.GOOD)
	_row(c, "Net sonuç", income + _sum(days, "reward") - expenses, UIKit.GOOD if income + _sum(days, "reward") - expenses >= 0.0 else UIKit.BAD)
	c.add_child(UIKit.lbl("Görüşme sayısı: %d" % int(_sum(days, "sessions")), 14, UIKit.MUTED))


func build(c: VBoxContainer) -> void:
	c.add_child(UIKit.lbl("Finans", 20, UIKit.ACCENT))
	c.add_child(UIKit.lbl("Nakit: %s%s" % [UIKit.fmt_money(GameState.money), ("   ·   BORÇ: %s" % UIKit.fmt_money(GameState.debt)) if GameState.debt > 0.0 else ""], 17, UIKit.GOOD if GameState.debt <= 0.0 else UIKit.BAD))
	_block(c, "Bugün (gün %d)" % GameState.day, [GameState.day])
	c.add_child(UIKit.sep())
	var week: Array = []
	for i in 7:
		if GameState.day - i >= 1:
			week.append(GameState.day - i)
	_block(c, "Son 7 gün", week)
	c.add_child(UIKit.sep())
	var all_days: Array = []
	for k in GameState.daily_stats.keys():
		all_days.append(int(k))
	var total := _sum(all_days, "commission") + _sum(all_days, "reward")
	for k in ["food", "rent", "maintenance", "upgrade", "training", "perks"]:
		total -= _sum(all_days, k)
	_row(c, "Toplam kâr (başlangıçtan beri)", total, UIKit.GOOD if total >= 0.0 else UIKit.BAD)
	c.add_child(UIKit.sep())
	c.add_child(UIKit.lbl("Son işlemler", 16, UIKit.ACCENT))
	var tx: Array = GameState.transactions
	var n := 0
	for i in range(tx.size() - 1, -1, -1):
		var t: Dictionary = tx[i]
		var amt := float(t["amt"])
		var cash := bool(t.get("cash", true))
		var col := UIKit.MUTED if not cash else (UIKit.GOOD if amt >= 0.0 else UIKit.BAD)
		c.add_child(UIKit.lbl("G%d %02d:%02d   %s%s   %s" % [int(t["day"]), floori(float(t["min"]) / 60.0), int(t["min"]) % 60, "+" if amt >= 0.0 else "", UIKit.fmt_money(amt), String(t["desc"])], 13, col))
		n += 1
		if n >= 40:
			break
	if n == 0:
		c.add_child(UIKit.lbl("Henüz işlem yok.", 14, UIKit.MUTED))
