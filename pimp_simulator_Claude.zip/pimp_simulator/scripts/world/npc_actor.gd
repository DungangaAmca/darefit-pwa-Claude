class_name NpcActor
extends Node3D
## Basit insansı karakter (primitiflerden): yürüme, oturma animasyonu, yol takibi.

signal arrived

static var time_scale: float = 1.0
static var show_names: bool = true

var speed: float = 2.4
var path: Array = []
var moving: bool = false
var sitting: bool = false
var anim_t: float = 0.0
var figure: Dictionary = {}
var name_label: Label3D
var kind: String = "npc"
var ref_id: int = -1


static func build_figure(parent: Node3D, look: Dictionary) -> Dictionary:
	var root := Node3D.new()
	root.scale = Vector3.ONE * float(look.get("height", 1.0))
	parent.add_child(root)
	var skin := Color.html(String(look.get("skin", "#e3b48a")))
	var hair := Color.html(String(look.get("hair", "#33211a")))
	var outfit := Color.html(String(look.get("outfit", "#2980b9")))
	var pants := outfit.darkened(0.45)
	var legs: Array = []
	for sx in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(0.11 * sx, 0.8, 0.0)
		root.add_child(pivot)
		Build.box(pivot, Vector3(0, -0.4, 0), Vector3(0.16, 0.8, 0.18), pants)
		legs.append(pivot)
	var torso := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.24
	cm.height = 0.8
	torso.mesh = cm
	torso.material_override = Build.mat(outfit)
	torso.position = Vector3(0, 1.2, 0)
	root.add_child(torso)
	var arms: Array = []
	for sx in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(0.3 * sx, 1.5, 0.0)
		root.add_child(pivot)
		Build.box(pivot, Vector3(0, -0.28, 0), Vector3(0.12, 0.6, 0.12), outfit.lightened(0.1))
		arms.append(pivot)
	Build.sphere(root, Vector3(0, 1.78, 0), 0.19, skin)
	var hs := Build.sphere(root, Vector3(0, 1.86, -0.01), 0.205, hair)
	hs.scale = Vector3(1.0, 0.8, 1.0)
	match String(look.get("style", "short")):
		"long":
			Build.box(root, Vector3(0, 1.62, -0.14), Vector3(0.34, 0.5, 0.12), hair)
		"bun":
			Build.sphere(root, Vector3(0, 2.06, -0.06), 0.09, hair)
	return {"root": root, "legs": legs, "arms": arms}


func setup(look: Dictionary, label_text: String, kind_name: String, id: int) -> void:
	kind = kind_name
	ref_id = id
	figure = build_figure(self, look)
	name_label = Label3D.new()
	name_label.text = label_text
	name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_label.pixel_size = 0.011
	name_label.font_size = 36
	name_label.outline_size = 10
	name_label.position = Vector3(0, 2.45, 0)
	name_label.visible = show_names and label_text != ""
	add_child(name_label)


func set_label(t: String) -> void:
	if name_label:
		name_label.text = t
		name_label.visible = show_names and t != ""


func walk_to(points: Array) -> void:
	path = points.duplicate()
	sitting = false
	moving = not path.is_empty()
	if not moving:
		_pose(0.0)
		call_deferred("_emit_arrived")


func _emit_arrived() -> void:
	arrived.emit()


func stop() -> void:
	path.clear()
	moving = false
	_pose(0.0)


func teleport(p: Vector3) -> void:
	path.clear()
	moving = false
	global_position = Vector3(p.x, 0.0, p.z)
	_pose(0.0)


func sit(on: bool) -> void:
	sitting = on
	_pose(0.0)


func _process(delta: float) -> void:
	if not moving or path.is_empty() or not is_inside_tree():
		return
	var target: Vector3 = path[0]
	var cur := global_position
	var flat := Vector3(target.x - cur.x, 0.0, target.z - cur.z)
	var dist := flat.length()
	var step := speed * time_scale * delta
	if dist <= step or dist < 0.001:
		global_position = Vector3(target.x, 0.0, target.z)
		path.pop_front()
		if path.is_empty():
			moving = false
			_pose(0.0)
			arrived.emit()
	else:
		var dir := flat / dist
		global_position += dir * step
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), clampf(12.0 * delta, 0.0, 1.0))
		anim_t += delta * time_scale * 8.0
		_pose(sin(anim_t))


func _pose(s: float) -> void:
	if figure.is_empty():
		return
	var legs: Array = figure["legs"]
	var arms: Array = figure["arms"]
	var root: Node3D = figure["root"]
	if sitting:
		for l in legs:
			l.rotation.x = -1.45
		for a in arms:
			a.rotation.x = -0.4
		root.position.y = -0.38
		return
	root.position.y = 0.0
	legs[0].rotation.x = s * 0.7
	legs[1].rotation.x = -s * 0.7
	arms[0].rotation.x = -s * 0.5
	arms[1].rotation.x = s * 0.5
