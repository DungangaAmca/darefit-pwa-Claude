class_name City
extends Node3D
## Küçük, keşfedilebilir şehir: yollar, bloklar, binalar, yürüyüş rotaları.

var buildings: Array = []      # {rect: Rect2, name: String}
var loops: Array = []          # her biri Vector3 dizisi (kaldırım rotaları)
var night_mats: Array = []     # {mat, base}
var occluders: Array = []      # {aabb, mats, alpha}
var door_business := Vector3(0, 0, 8.2)
var door_market := Vector3(-40, 0, 8.2)
var spawn_point := Vector3(0, 0, 3.5)

const TILES := [
	{"c": Vector2(-40, -22.5), "name": "Restoran", "color": Color(0.55, 0.3, 0.25)},
	{"c": Vector2(0, -22.5), "name": "Café", "color": Color(0.78, 0.62, 0.42)},
	{"c": Vector2(40, -22.5), "name": "Neon Kulüp", "color": Color(0.25, 0.15, 0.4)},
	{"c": Vector2(-40, 22.5), "name": "Market", "color": Color(0.3, 0.5, 0.35)},
	{"c": Vector2(0, 22.5), "name": "GECE SALONU", "color": Color(0.5, 0.12, 0.22)},
	{"c": Vector2(40, 22.5), "name": "Park", "color": Color(0.2, 0.5, 0.2)},
]


func build() -> void:
	_ground()
	for t in TILES:
		_tile(t)
	_boundaries()
	_lamps()


func _ground() -> void:
	var g := Build.box(self, Vector3(0, -0.25, 0), Vector3(240, 0.5, 240), Color(0.2, 0.3, 0.2), true)
	g.name = "Ground"
	var road := Color(0.14, 0.14, 0.16)
	Build.box(self, Vector3(0, 0.01, 0), Vector3(120, 0.02, 10), road)
	Build.box(self, Vector3(-20, 0.01, 0), Vector3(10, 0.02, 90), road)
	Build.box(self, Vector3(20, 0.01, 0), Vector3(10, 0.02, 90), road)
	for i in range(-28, 29, 8):
		Build.box(self, Vector3(i, 0.025, 0), Vector3(3, 0.01, 0.25), Color(0.9, 0.9, 0.6))
	for i in range(-40, 41, 8):
		if abs(i) > 6:
			Build.box(self, Vector3(-20, 0.025, i), Vector3(0.25, 0.01, 3), Color(0.9, 0.9, 0.6))
			Build.box(self, Vector3(20, 0.025, i), Vector3(0.25, 0.01, 3), Color(0.9, 0.9, 0.6))


func _tile(t: Dictionary) -> void:
	var c: Vector2 = t["c"]
	var nm: String = t["name"]
	Build.box(self, Vector3(c.x, 0.02, c.y), Vector3(30, 0.04, 35), Color(0.42, 0.42, 0.45))
	# Yürüyüş rotası (8 nokta)
	var x0 := c.x - 13.5
	var x1 := c.x + 13.5
	var z0 := c.y - 16.0
	var z1 := c.y + 16.0
	loops.append([Vector3(x0, 0, z0), Vector3(c.x, 0, z0), Vector3(x1, 0, z0), Vector3(x1, 0, c.y),
		Vector3(x1, 0, z1), Vector3(c.x, 0, z1), Vector3(x0, 0, z1), Vector3(x0, 0, c.y)])
	if nm == "Park":
		_park(c)
		return
	var color: Color = t["color"]
	var south_block := c.y > 0.0
	var h := 5.5 + float(absi(int(c.x)) % 3) * 0.6
	var bw := 22.0
	var bd := 27.0
	var bnode := Node3D.new()
	add_child(bnode)
	Build.box(bnode, Vector3(c.x, h * 0.5, c.y), Vector3(bw, h, bd), color, true)
	Build.box(bnode, Vector3(c.x, h + 0.2, c.y), Vector3(bw + 0.6, 0.4, bd + 0.6), color.darkened(0.35))
	buildings.append({"rect": Rect2(c.x - bw * 0.5, c.y - bd * 0.5, bw, bd), "name": nm})
	var face_z := c.y - bd * 0.5 if south_block else c.y + bd * 0.5
	var out := -1.0 if south_block else 1.0
	var wmat := Build.mat(Color(1.0, 0.85, 0.5))
	wmat.emission_enabled = true
	wmat.emission = Color(1.0, 0.85, 0.5)
	wmat.emission_energy_multiplier = 0.0
	night_mats.append({"mat": wmat, "base": 1.6})
	for row in 2:
		for col in 5:
			var wm := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(1.6, 1.3, 0.1)
			wm.mesh = bm
			wm.material_override = wmat
			wm.position = Vector3(c.x - 8.0 + col * 4.0, 2.4 + row * 1.9, face_z + out * 0.06)
			bnode.add_child(wm)
	Build.box(bnode, Vector3(c.x, 1.6, face_z + out * 0.1), Vector3(2.6, 3.2, 0.2), Color(0.25, 0.15, 0.1))
	Build.box(bnode, Vector3(c.x, 3.4, face_z + out * 0.6), Vector3(4.0, 0.2, 1.4), color.lightened(0.25))
	var is_biz := nm == "GECE SALONU"
	var lab := Build.label(self, nm, Vector3(c.x, 4.6, face_z + out * 0.9), 90, Color(1, 0.8, 0.3) if is_biz else Color.WHITE)
	lab.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	lab.rotation.y = 0.0 if out > 0.0 else PI
	lab.double_sided = true
	if is_biz:
		var neon := Build.mat(Color(1.0, 0.25, 0.5), 2.0)
		var strip := MeshInstance3D.new()
		var sm := BoxMesh.new()
		sm.size = Vector3(10, 0.25, 0.2)
		strip.mesh = sm
		strip.material_override = neon
		strip.position = Vector3(c.x, 4.0, face_z + out * 0.3)
		add_child(strip)
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(c.x, 4.0, face_z + out * 3.0)
		lamp.light_color = Color(1.0, 0.4, 0.6)
		lamp.light_energy = 1.4
		lamp.omni_range = 12.0
		add_child(lamp)
	if nm == "Neon Kulüp":
		var neon2 := Build.mat(Color(0.3, 0.8, 1.0), 2.0)
		var strip2 := MeshInstance3D.new()
		var sm2 := BoxMesh.new()
		sm2.size = Vector3(12, 0.25, 0.2)
		strip2.mesh = sm2
		strip2.material_override = neon2
		strip2.position = Vector3(c.x, 4.0, face_z + out * 0.3)
		add_child(strip2)
		night_mats.append({"mat": neon2, "base": 2.0})
	# kaldırım ağaçları (kapının iki yanında)
	var tz := c.y - 15.0 if south_block else c.y + 15.0
	for tx in [-8.0, 8.0]:
		_tree(Vector3(c.x + tx, 0, tz))
	var mats: Array = []
	for ch in bnode.get_children():
		if ch is MeshInstance3D:
			mats.append((ch as MeshInstance3D).material_override)
	occluders.append({"aabb": AABB(Vector3(c.x - bw * 0.5 - 0.3, 0.0, c.y - bd * 0.5 - 0.3), Vector3(bw + 0.6, h + 0.6, bd + 0.6)), "mats": mats, "alpha": 1.0})


## Kamera ile oyuncu arasına giren binaları saydamlaştırır.
func update_occlusion(cam_pos: Vector3, target: Vector3, delta: float) -> void:
	for o in occluders:
		var aabb: AABB = o["aabb"]
		var want := 0.16 if aabb.intersects_segment(cam_pos, target) else 1.0
		var a := move_toward(float(o["alpha"]), want, delta * 5.0)
		if is_equal_approx(a, float(o["alpha"])):
			continue
		o["alpha"] = a
		for m in o["mats"]:
			var sm := m as StandardMaterial3D
			sm.albedo_color.a = a
			sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA if a < 0.99 else BaseMaterial3D.TRANSPARENCY_DISABLED


func _tree(p: Vector3) -> void:
	Build.cyl(self, p + Vector3(0, 1.0, 0), 0.2, 2.0, Color(0.35, 0.22, 0.12))
	Build.sphere(self, p + Vector3(0, 2.8, 0), 1.3, Color(0.15, 0.45, 0.2))


func _park(c: Vector2) -> void:
	Build.box(self, Vector3(c.x, 0.05, c.y), Vector3(28, 0.04, 33), Color(0.2, 0.5, 0.22))
	buildings.append({"rect": Rect2(c.x - 14.0, c.y - 16.5, 28, 33), "name": "Park", "park": true})
	for i in 9:
		_tree(Vector3(c.x + randf_range(-12, 12), 0, c.y + randf_range(-14, 14)))
	for i in 3:
		Build.box(self, Vector3(c.x - 6.0 + i * 6.0, 0.35, c.y + 10.0), Vector3(2.0, 0.2, 0.6), Color(0.45, 0.3, 0.15))
		Build.box(self, Vector3(c.x - 6.0 + i * 6.0, 0.65, c.y + 10.3), Vector3(2.0, 0.5, 0.1), Color(0.45, 0.3, 0.15))
	Build.cyl(self, Vector3(c.x, 0.25, c.y), 2.6, 0.5, Color(0.6, 0.6, 0.65))
	Build.cyl(self, Vector3(c.x, 0.42, c.y), 2.2, 0.3, Color(0.2, 0.5, 0.8))
	Build.label(self, "Park", Vector3(c.x, 3.0, c.y + 14.0), 80)


func _boundaries() -> void:
	Build.blocker(self, Vector3(-58, 3, 0), Vector3(1, 6, 100))
	Build.blocker(self, Vector3(58, 3, 0), Vector3(1, 6, 100))
	Build.blocker(self, Vector3(0, 3, -43), Vector3(120, 6, 1))
	Build.blocker(self, Vector3(0, 3, 43), Vector3(120, 6, 1))


func _lamps() -> void:
	var bulb := Build.mat(Color(1.0, 0.9, 0.6), 0.0)
	bulb.emission_enabled = true
	night_mats.append({"mat": bulb, "base": 3.0})
	for x in [-55.0, -25.0, -15.0, 15.0, 25.0, 55.0]:
		for z in [-5.5, 5.5]:
			Build.cyl(self, Vector3(x, 2.0, z), 0.08, 4.0, Color(0.2, 0.2, 0.22))
			var b := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.28
			sm.height = 0.56
			b.mesh = sm
			b.material_override = bulb
			b.position = Vector3(x, 4.1, z)
			add_child(b)
