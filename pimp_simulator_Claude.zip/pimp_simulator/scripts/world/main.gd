extends Node3D
## Ana sahne: dünyayı kurar, kamera/zaman/etkileşimi yönetir, sistemleri birbirine bağlar.

const INTERIOR_ORIGIN := Vector3(300, 0, 0)

var city: City
var interior: Interior
var business: Business
var npcs: CityNpcs
var player: Player
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var ui: GameUI
var actors_root: Node3D
var in_interior := false
var cam_yaw := PI
var cam_zoom := 19.0
var cam_focus := Vector3.ZERO
var step_accum := 0.0
var autosave_timer := 0.0
var statics: Array = []
var current_interact: Dictionary = {}


func _ready() -> void:
	_setup_input()
	_build_environment()
	city = City.new()
	add_child(city)
	city.build()
	interior = Interior.new()
	interior.position = INTERIOR_ORIGIN
	add_child(interior)
	interior.build()
	actors_root = Node3D.new()
	add_child(actors_root)
	player = Player.new()
	add_child(player)
	player.global_position = city.spawn_point
	cam = Camera3D.new()
	cam.far = 400.0
	cam.fov = 45.0
	add_child(cam)
	cam.current = true
	business = Business.new()
	add_child(business)
	business.setup(interior, actors_root)
	npcs = CityNpcs.new()
	add_child(npcs)
	npcs.setup(city, actors_root)
	ui = GameUI.new()
	add_child(ui)
	ui.setup(self, business)
	GameState.game_over.connect(func(_r): player.enabled = false)
	_register_interactables()
	GameState.reset()
	business.rebuild()
	npcs.rebuild()
	cam_focus = player.global_position
	if "--selftest" in OS.get_cmdline_user_args():
		var st = load("res://scripts/dev/selftest.gd").new()
		add_child(st)
		st.run(self)
	elif "--balance" in OS.get_cmdline_user_args():
		var bl = load("res://scripts/dev/balance.gd").new()
		add_child(bl)
		bl.run(self)
	else:
		ui.show_start_menu(SaveSystem.has_save())


# ---------------- Oyun başlatma ----------------
func begin_game(load_save: bool) -> void:
	if load_save:
		if not SaveSystem.load_game():
			GameState.notify("Kayıt yüklenemedi, yeni oyun başlatılıyor.", "bad")
			GameState.reset()
	else:
		GameState.reset()
	GameState.started = true
	step_accum = 0.0
	business.rebuild()
	npcs.rebuild()
	in_interior = false
	player.global_position = city.spawn_point
	cam_yaw = PI
	player.enabled = true
	cam_focus = player.global_position
	ui.hide_start_menu()
	if not load_save:
		GameState.notify("Hoş geldin! Şehirde dolaşıp sarı isimli potansiyel çalışanlara yaklaş ve E ile konuş. Kısa görevler için 6 tuşu.", "info")
		GameState.notify("Çalışanların su/yiyecek ihtiyacı için Envanter (8) menüsünden malzeme sipariş etmeyi unutma.", "info")
	GameState.speed_changed.emit()
	GameState.money_changed.emit()
	GameState.time_changed.emit()
	GameState.reputation_changed.emit()
	GameState.data_changed.emit()
	QuestSystem.check()


func new_game() -> void:
	begin_game(false)


func load_game() -> void:
	begin_game(true)


func save_now() -> void:
	if SaveSystem.save_game():
		GameState.notify("Oyun kaydedildi.", "good")
	else:
		GameState.notify("Kayıt başarısız oldu!", "bad")


# ---------------- Girdi ----------------
func _add_key_action(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)


func _setup_input() -> void:
	_add_key_action("move_forward", [KEY_W, KEY_UP])
	_add_key_action("move_back", [KEY_S, KEY_DOWN])
	_add_key_action("move_left", [KEY_A, KEY_LEFT])
	_add_key_action("move_right", [KEY_D, KEY_RIGHT])
	_add_key_action("run", [KEY_SHIFT])
	_add_key_action("interact", [KEY_E])
	_add_key_action("cam_left", [KEY_Q])
	_add_key_action("cam_right", [KEY_R])


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact") and not current_interact.is_empty() and not ui.blocking():
		(current_interact["cb"] as Callable).call()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			cam_zoom = clampf(cam_zoom - 1.5, 9.0, 38.0)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			cam_zoom = clampf(cam_zoom + 1.5, 9.0, 38.0)


# ---------------- Ortam / gün-gece ----------------
func _build_environment() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.55, 0.72, 0.92)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.68, 0.8)
	env.ambient_light_energy = 0.9
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)


func _update_sun() -> void:
	var t := float(GameState.minute_of_day) / 1440.0
	var elev := sin((t - 0.25) * TAU)
	var up := clampf(elev, 0.0, 1.0)
	var blend := clampf(elev * 3.0 + 0.5, 0.0, 1.0)
	sun.rotation_degrees = Vector3(-lerpf(50.0, 15.0 + 60.0 * up, blend), -35.0 + 120.0 * t, 0.0)
	sun.light_energy = lerpf(0.35, 0.85, clampf(elev * 1.5 + 0.1, 0.0, 1.0))
	var warm := Color(1.0, 0.82, 0.62).lerp(Color(1.0, 0.98, 0.94), clampf(elev * 1.5, 0.0, 1.0))
	sun.light_color = Color(0.55, 0.65, 1.0).lerp(warm, blend)
	var day_f := clampf(elev * 1.5 + 0.3, 0.0, 1.0)
	env.background_color = Color(0.03, 0.05, 0.12).lerp(Color(0.55, 0.72, 0.92), day_f)
	env.ambient_light_color = Color(0.3, 0.35, 0.55).lerp(Color(0.62, 0.68, 0.8), day_f)
	env.ambient_light_energy = lerpf(0.8, 0.75, day_f)
	if in_interior:
		env.ambient_light_color = Color(0.85, 0.78, 0.7)
		env.ambient_light_energy = 0.85
	var night := clampf(0.5 - elev * 1.5, 0.0, 1.0)
	for m in city.night_mats:
		(m["mat"] as StandardMaterial3D).emission_energy_multiplier = float(m["base"]) * night


# ---------------- Etkileşim ----------------
func _register_interactables() -> void:
	var L: Dictionary = interior.layout
	statics = [
		{"pos": city.door_business, "zone": "city", "r": 2.8, "text": "E — %s'a gir" % GameState.business_name, "cb": Callable(self, "_enter_business")},
		{"pos": city.door_market, "zone": "city", "r": 2.8, "text": "E — Market: malzeme sipariş ver", "cb": func(): ui.open_menu("inventory")},
		{"pos": L["exit_stand"], "zone": "interior", "r": 1.8, "text": "E — Dışarı çık", "cb": Callable(self, "_exit_business")},
		{"pos": L["reception_stand"], "zone": "interior", "r": 2.0, "text": "E — Resepsiyon (müşteriler)", "cb": func(): ui.open_menu("customers")},
		{"pos": L["desk_stand"], "zone": "interior", "r": 2.0, "text": "E — Yönetim masası", "cb": func(): ui.open_menu("business")},
		{"pos": L["kitchen_stand"], "zone": "interior", "r": 2.2, "text": "E — Mutfak / depo (envanter)", "cb": func(): ui.open_menu("inventory")},
	]


func _update_interact() -> void:
	current_interact = {}
	if not GameState.started:
		ui.set_prompt("")
		return
	var pp := player.global_position
	var best := 999.0
	var zone := "interior" if in_interior else "city"
	for s in statics:
		if s["zone"] != zone:
			continue
		var p: Vector3 = s["pos"]
		var d := Vector2(p.x - pp.x, p.z - pp.z).length()
		if d < float(s["r"]) and d < best:
			best = d
			current_interact = s
	if not in_interior:
		for id in npcs.cand_actors.keys():
			var a: NpcActor = npcs.cand_actors[id]
			if not is_instance_valid(a):
				continue
			var d2 := Vector2(a.global_position.x - pp.x, a.global_position.z - pp.z).length()
			if d2 < 2.6 and d2 < best:
				best = d2
				var cid: int = int(id)
				current_interact = {"text": "E — Konuş: %s" % a.name_label.text, "cb": func(): _talk(cid)}
	ui.set_prompt(String(current_interact.get("text", "")) if not ui.blocking() else "")


func _talk(cid: int) -> void:
	var cand := GameState.get_candidate(cid)
	if cand.is_empty():
		return
	if int(cand.refuse_until) > GameState.day:
		GameState.notify("%s şu an seninle görüşmek istemiyor." % cand.name, "warn")
		Sfx.play("error")
		return
	if not bool(cand.met):
		cand.met = true
		GameState.stat_add("met")
		QuestSystem.check()
	npcs.set_talking(cid, true, player.global_position)
	Sfx.play("talk")
	ui.open_hire(cand, func(): npcs.set_talking(cid, false))


func _enter_business() -> void:
	Sfx.play("door")
	in_interior = true
	player.global_position = interior.layout["spawn_in"]
	cam_focus = player.global_position
	cam_yaw = 0.0
	cam_zoom = minf(cam_zoom, 22.0)


func _exit_business() -> void:
	Sfx.play("door")
	in_interior = false
	player.global_position = city.door_business + Vector3(0, 0, -1.2)
	cam_focus = player.global_position
	cam_yaw = PI


# ---------------- Harita verisi ----------------
func get_map_data() -> Dictionary:
	var wpos: Array = []
	for a in business.worker_actors.values():
		if is_instance_valid(a) and a.visible:
			wpos.append(a.global_position)
	var cpos: Array = []
	for a in business.customer_actors.values():
		if is_instance_valid(a) and a.visible:
			cpos.append(a.global_position)
	return {"interior": in_interior, "player": player.global_position, "buildings": city.buildings,
		"candidates": npcs.candidate_positions(), "origin": INTERIOR_ORIGIN, "rooms": business.rooms,
		"workers": wpos, "customers": cpos}


# ---------------- Ana döngü ----------------
func _process(delta: float) -> void:
	var running := GameState.started and not GameState.is_game_over
	NpcActor.time_scale = GameState.speed() if running else 0.0
	if running:
		var spd := GameState.speed()
		if spd > 0.0:
			step_accum += delta * spd
			var guard := 0
			while step_accum >= Config.SECONDS_PER_GAME_MINUTE and guard < 30:
				step_accum -= Config.SECONDS_PER_GAME_MINUTE
				GameState.advance_minute()
				business.step_minute()
				QuestSystem.check()
				guard += 1
			if guard >= 30:
				step_accum = 0.0
		autosave_timer += delta
		if autosave_timer > 120.0:
			autosave_timer = 0.0
			if bool(SaveSystem.settings.get("autosave", true)):
				SaveSystem.save_game()
	player.enabled = running and not ui.blocking_movement()
	_update_camera(delta)
	_update_sun()
	_update_interact()


func _update_camera(delta: float) -> void:
	if Input.is_action_pressed("cam_left"):
		cam_yaw += 1.8 * delta
	if Input.is_action_pressed("cam_right"):
		cam_yaw -= 1.8 * delta
	player.cam_yaw = cam_yaw
	cam_focus = cam_focus.lerp(player.global_position + Vector3(0, 1.0, 0), clampf(10.0 * delta, 0.0, 1.0))
	var pitch := deg_to_rad(58.0 if in_interior else 60.0)
	var off := Vector3(0, sin(pitch) * cam_zoom, cos(pitch) * cam_zoom).rotated(Vector3.UP, cam_yaw)
	cam.global_position = cam_focus + off
	cam.look_at(cam_focus, Vector3.UP)
	city.update_occlusion(cam.global_position, player.global_position + Vector3(0, 1.0, 0), delta)
