class_name Player
extends CharacterBody3D
## Oyuncu karakteri: WASD/ok tuşları, Shift ile koşma. Hareket kameraya göredir.

const WALK_SPEED := 4.4
const RUN_SPEED := 8.0

var cam_yaw: float = 0.0
var enabled: bool = true
var figure: Dictionary = {}
var anim_t: float = 0.0


func _ready() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.38
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	add_child(cs)
	var look := {"skin": "#e3b48a", "hair": "#1c1512", "outfit": "#5b2a86", "height": 1.04, "style": "short"}
	figure = NpcActor.build_figure(self, look)
	Build.box(figure["root"], Vector3(0, 1.98, 0), Vector3(0.34, 0.07, 0.34), Color(0.12, 0.1, 0.16))
	Build.box(figure["root"], Vector3(0, 2.1, 0), Vector3(0.24, 0.18, 0.24), Color(0.12, 0.1, 0.16))
	floor_snap_length = 0.3


func _physics_process(delta: float) -> void:
	var input := Vector2.ZERO
	var running := false
	if enabled:
		input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		running = Input.is_action_pressed("run")
	var dir := Vector3(input.x, 0.0, input.y).rotated(Vector3.UP, cam_yaw)
	var spd := RUN_SPEED if running else WALK_SPEED
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 25.0 * delta
	move_and_slide()
	var legs: Array = figure["legs"]
	var arms: Array = figure["arms"]
	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), clampf(12.0 * delta, 0.0, 1.0))
		anim_t += delta * (11.0 if running else 8.0)
		var s := sin(anim_t)
		legs[0].rotation.x = s * 0.75
		legs[1].rotation.x = -s * 0.75
		arms[0].rotation.x = -s * 0.55
		arms[1].rotation.x = s * 0.55
	else:
		for l in legs:
			l.rotation.x = 0.0
		for a in arms:
			a.rotation.x = 0.0
