class_name Business
extends Node
## İşletme mantığı: çalışan ve müşteri durum makineleri, oda yönetimi, görüşme akışı.
## Oyun saati dakika dakika ilerler (step_minute); hareket NpcActor tarafından yapılır.

const ROOM_MAX := 6

var interior: Interior
var actors_root: Node3D
var worker_actors: Dictionary = {}
var customer_actors: Dictionary = {}
var wrt: Dictionary = {}       # çalışan çalışma zamanı durumu (kaydedilmez)
var rooms: Array = []
var _notice_cd: Dictionary = {}

const WORKER_STATUS := {
	"sit": "Bekliyor", "to_seat": "Bekleme alanına gidiyor", "to_kitchen": "Mutfağa gidiyor",
	"eating": "Yemek/içecek molasında", "to_lounge": "Dinlenme alanına gidiyor", "resting": "Dinleniyor",
	"off_shift": "Mesai dışı (dinleniyor)", "training": "Eğitimde", "to_room": "Odaya gidiyor", "in_session": "Görüşmede",
}
const CUSTOMER_STATUS := {
	"to_reception": "Resepsiyona yürüyor", "greeting": "Karşılanıyor", "choosing": "Eşleştirme bekliyor",
	"to_seat": "Bekleme alanına gidiyor", "waiting": "Bekliyor", "to_room": "Odaya gidiyor",
	"in_session": "Görüşmede", "leaving": "Ayrılıyor",
}


func setup(p_interior: Interior, p_root: Node3D) -> void:
	interior = p_interior
	actors_root = p_root
	GameState.worker_removed.connect(_on_worker_removed)
	GameState.upgrades_changed.connect(_on_upgrades_changed)


func rebuild() -> void:
	for a in worker_actors.values():
		if is_instance_valid(a):
			a.queue_free()
	for a in customer_actors.values():
		if is_instance_valid(a):
			a.queue_free()
	worker_actors.clear()
	customer_actors.clear()
	wrt.clear()
	rooms.clear()
	_notice_cd.clear()
	for i in ROOM_MAX:
		rooms.append({"state": "locked" if i >= GameState.rooms_unlocked() else "free", "worker": -1, "customer": -1, "timer": 0.0, "total": 0.0, "type": "standard"})
	interior.refresh_upgrades()
	for i in ROOM_MAX:
		interior.room_nodes[i]["state"] = ""
		interior.set_room(i, String(rooms[i]["state"]))
	for w in GameState.workers:
		if not w.has("slot") or int(w["slot"]) < 0:
			w["slot"] = _free_slot()
		_spawn_worker(w, false)
	var old: Array = GameState.customers.duplicate()
	GameState.customers.clear()
	for c in old:
		_restore_customer(c)


func _note(key: String, msg: String, kind: String = "info") -> void:
	var now := GameState.abs_minutes()
	if _notice_cd.has(key) and now - int(_notice_cd[key]) < 90:
		return
	_notice_cd[key] = now
	GameState.notify(msg, kind)


# ======================= ÇALIŞANLAR =======================
func _free_slot() -> int:
	var used := {}
	for w in GameState.workers:
		used[int(w.get("slot", -1))] = true
	for i in 10:
		if not used.has(i):
			return i
	return 0


func hire(cand: Dictionary, commission: float, shift: String, perks: Array) -> String:
	if GameState.get_candidate(int(cand.id)).is_empty():
		return "Aday artık burada değil."
	if GameState.workers.size() >= GameState.max_workers():
		return "Çalışan kapasitesi dolu. Oda veya dinlenme alanı geliştir."
	if int(cand.age) < Config.LEGAL_ADULT_AGE:
		return "Geçersiz aday."
	var w: Dictionary = cand.duplicate(true)
	for k in ["patience", "met", "refuse_until"]:
		w.erase(k)
	w["commission"] = clampf(commission, Config.MIN_COMMISSION, Config.MAX_COMMISSION)
	w["shift"] = shift
	w["perks"] = perks.duplicate()
	w["energy"] = 90.0
	w["hunger"] = 20.0
	w["thirst"] = 20.0
	w["satisfaction"] = 65.0
	w["buff_until"] = 0
	w["total_earned"] = 0.0
	w["revenue"] = 0.0
	w["sessions"] = 0
	w["sessions_today"] = 0
	w["hired_day"] = GameState.day
	w["low_sat_days"] = 0
	w["wants_raise"] = false
	w["slot"] = _free_slot()
	GameState.workers.append(w)
	GameState.remove_candidate(int(cand.id))
	GameState.stat_add("contracts")
	QuestSystem.check()
	_spawn_worker(w, true)
	GameState.notify("%s işletmeye katıldı! Gönüllü sözleşme imzalandı." % w.name, "good")
	Sfx.play("coin")
	GameState.data_changed.emit()
	return ""


func _spawn_worker(w: Dictionary, from_entrance: bool) -> void:
	var id := int(w.id)
	var actor := NpcActor.new()
	actors_root.add_child(actor)
	actor.setup(w.look, String(w.name), "worker", id)
	actor.speed = 2.8
	actor.arrived.connect(_on_worker_arrived.bind(id))
	worker_actors[id] = actor
	var seat: Vector3 = interior.layout["staff_seats"][int(w.slot)]
	wrt[id] = {"state": "to_seat", "timer": 0.0, "room": -1, "customer": -1, "after": "resting", "skill": "",
		"inside": false, "in_room": false, "drain": 0.0, "sit_since": GameState.abs_minutes()}
	if from_entrance:
		actor.teleport(interior.layout["entrance"])
		actor.walk_to([seat])
	else:
		actor.teleport(seat)
		actor.sit(true)
		wrt[id]["state"] = "sit"


func _on_worker_removed(id: int, _reason: String) -> void:
	if worker_actors.has(id):
		var a: NpcActor = worker_actors[id]
		if is_instance_valid(a):
			a.queue_free()
		worker_actors.erase(id)
	wrt.erase(id)


func release_worker(id: int) -> String:
	if not wrt.has(id):
		return "Çalışan bulunamadı."
	var st := String(wrt[id]["state"])
	if st in ["to_room", "in_session"]:
		return "Görüşmedeki çalışanla şu an sözleşme feshedilemez."
	GameState.remove_worker_data(id, "released")
	return ""


func give_raise(id: int) -> String:
	var w := GameState.get_worker(id)
	if w.is_empty():
		return "Çalışan bulunamadı."
	var nc := float(w.commission) - 0.05
	if nc < Config.MIN_COMMISSION - 0.0001:
		return "Komisyon zaten en alt sınırda."
	w.commission = maxf(Config.MIN_COMMISSION, nc)
	w.satisfaction = minf(100.0, float(w.satisfaction) + 8.0)
	w.wants_raise = false
	GameState.notify("%s'ın payı artırıldı. Yeni işletme komisyonu: %%%d" % [w.name, int(roundf(float(w.commission) * 100.0))], "good")
	GameState.data_changed.emit()
	return ""


func give_item(id: int, item_id: String) -> String:
	if not wrt.has(id):
		return "Çalışan bulunamadı."
	if String(wrt[id]["state"]) in ["to_room", "in_session"]:
		return "Çalışan şu an görüşmede."
	var w := GameState.get_worker(id)
	if not _use_item(w, item_id):
		return "Stokta yok veya kullanılamaz."
	GameState.data_changed.emit()
	return ""


func send_rest(id: int) -> String:
	if not wrt.has(id):
		return "Çalışan bulunamadı."
	var st := String(wrt[id]["state"])
	if st != "sit":
		return "Çalışan şu an müsait değil (%s)." % WORKER_STATUS.get(st, st)
	_send_to_lounge(GameState.get_worker(id), "resting")
	return ""


func start_training(id: int, skill: String) -> String:
	if not bool(GameState.unlocks.get("training", false)):
		return "Eğitim henüz açılmadı (görevleri tamamla)."
	if not wrt.has(id):
		return "Çalışan bulunamadı."
	var w := GameState.get_worker(id)
	var rt: Dictionary = wrt[id]
	var st := String(rt["state"])
	if not st in ["sit", "resting", "off_shift"]:
		return "Çalışan şu an eğitime alınamaz (%s)." % WORKER_STATUS.get(st, st)
	if float(w[skill]) >= 100.0:
		return "Bu yetenek zaten maksimumda."
	var cost := Economy.training_cost(w, skill)
	if not GameState.spend(cost, "training", "Eğitim: %s / %s" % [w.name, Config.SKILLS[skill]]):
		return "Yetersiz bakiye."
	rt["skill"] = skill
	rt["timer"] = Economy.training_minutes()
	if st == "sit":
		rt["after"] = "training"
		_send_to_lounge(w, "training")
	else:
		rt["state"] = "training"
	GameState.notify("%s eğitime başladı: %s" % [w.name, Config.SKILLS[skill]], "info")
	GameState.data_changed.emit()
	return ""


func _finish_training(w: Dictionary) -> void:
	var rt: Dictionary = wrt[int(w.id)]
	var skill := String(rt["skill"])
	var gain := randf_range(3.0, 6.0) * (1.0 - float(w[skill]) / 130.0)
	w[skill] = minf(100.0, float(w[skill]) + gain)
	GameState.notify("%s eğitimi tamamladı: %s +%.1f" % [w.name, Config.SKILLS[skill], gain], "good")
	_send_to_seat(w)


func toggle_open() -> void:
	GameState.business_open = not GameState.business_open
	GameState.notify("İşletme %s." % ("açıldı" if GameState.business_open else "kapatıldı (yeni müşteri kabul edilmeyecek)"), "info")
	GameState.data_changed.emit()


# ---- Hareket yardımcıları ----
func _walk_worker(id: int, target: Vector3) -> void:
	var actor: NpcActor = worker_actors[id]
	var rt: Dictionary = wrt[id]
	var pts: Array = []
	if bool(rt["inside"]):
		pts.append(interior.layout["rooms"][int(rt["room"])]["door"])
		rt["inside"] = false
		rt["room"] = -1
	pts.append(target)
	actor.visible = true
	actor.walk_to(pts)


func _send_to_seat(w: Dictionary) -> void:
	var id := int(w.id)
	wrt[id]["state"] = "to_seat"
	_walk_worker(id, interior.layout["staff_seats"][int(w.slot)])


func _send_to_lounge(w: Dictionary, after: String) -> void:
	var id := int(w.id)
	wrt[id]["state"] = "to_lounge"
	wrt[id]["after"] = after
	_walk_worker(id, interior.layout["lounge_spots"][int(w.slot)])


func _send_to_kitchen(w: Dictionary) -> void:
	var id := int(w.id)
	wrt[id]["state"] = "to_kitchen"
	_walk_worker(id, interior.layout["kitchen_stand"] + Vector3(randf_range(-0.7, 0.7), 0, randf_range(-1.2, 1.2)))


func _on_worker_arrived(id: int) -> void:
	if not wrt.has(id):
		return
	var rt: Dictionary = wrt[id]
	var actor: NpcActor = worker_actors[id]
	match String(rt["state"]):
		"to_seat":
			rt["state"] = "sit"
			rt["sit_since"] = GameState.abs_minutes()
			actor.rotation.y = 0.0
			actor.sit(true)
		"to_kitchen":
			rt["state"] = "eating"
			rt["timer"] = maxf(3.0, Config.EAT_MINUTES - 2.0 * GameState.ulevel("kitchen"))
		"to_lounge":
			rt["state"] = String(rt["after"])
			actor.rotation.y = 0.0
			actor.sit(true)
		"to_room":
			_room_arrived(id, true)


# ---- İhtiyaçlar ----
func _use_item(w: Dictionary, item_id: String) -> bool:
	var it: Dictionary = Config.ITEMS[item_id]
	if int(GameState.inventory.get(item_id, 0)) <= 0:
		return false
	if bool(it.get("needs_kitchen", false)) and GameState.ulevel("kitchen") < 1:
		return false
	GameState.inventory[item_id] = int(GameState.inventory[item_id]) - 1
	w.thirst = maxf(0.0, float(w.thirst) - float(it["thirst"]))
	w.hunger = maxf(0.0, float(w.hunger) - float(it["hunger"]))
	w.energy = minf(100.0, float(w.energy) + float(it["energy"]))
	w.satisfaction = clampf(float(w.satisfaction) + float(it["mood"]), 0.0, 100.0)
	if int(it["buff"]) > 0:
		w.buff_until = GameState.abs_minutes() + int(it["buff"])
	return true


func _consume_needs(w: Dictionary) -> void:
	if float(w.thirst) >= 40.0:
		if not _use_item(w, "water"):
			_use_item(w, "coffee")
	if float(w.hunger) >= 40.0:
		for it in ["meal", "sandwich", "fruit"]:
			if _use_item(w, it):
				break
	if float(w.energy) <= 45.0:
		for it in ["energy_drink", "coffee"]:
			if _use_item(w, it):
				break
	if float(w.thirst) >= Config.SEEK_NEED:
		w.satisfaction = maxf(0.0, float(w.satisfaction) - 3.0)
		_note("no_water", "Su stoğu tükendi! Çalışanlar susuz kalıyor (Envanter menüsünden sipariş ver).", "warn")
	if float(w.hunger) >= Config.SEEK_NEED:
		w.satisfaction = maxf(0.0, float(w.satisfaction) - 3.0)
		_note("no_food", "Yiyecek stoğu tükendi! Çalışanlar aç kalıyor.", "warn")


func _update_satisfaction(w: Dictionary) -> void:
	var target := 50.0 + 4.0 * GameState.ulevel("lounge") + 3.0 * GameState.ulevel("furniture") \
		+ 2.0 * GameState.ulevel("chairs") + 2.0 * GameState.ulevel("kitchen")
	for p in w.perks:
		target += float(Config.PERKS[p]["bonus"]) * 200.0
	var gap := Economy.required_share(w) - (1.0 - float(w.commission))
	if gap > 0.0:
		target -= gap * 250.0
	else:
		target += minf(10.0, -gap * 120.0)
	if float(w.hunger) > 70.0:
		target -= 12.0
	if float(w.thirst) > 70.0:
		target -= 12.0
	if float(w.energy) < 25.0:
		target -= 12.0
	if int(w.sessions_today) > Economy.daily_capacity(w):
		target -= 10.0
	var d := clampf(target - float(w.satisfaction), -0.12, 0.12)
	w.satisfaction = clampf(float(w.satisfaction) + d, 0.0, 100.0)


func _worker_available(w: Dictionary) -> bool:
	var id := int(w.id)
	if not wrt.has(id) or String(wrt[id]["state"]) != "sit":
		return false
	if not GameState.business_open or bool(w.get("quit_pending", false)):
		return false
	if not Economy.in_shift(String(w.shift), GameState.hour()):
		return false
	if float(w.energy) < 35.0 or float(w.hunger) > 85.0 or float(w.thirst) > 85.0:
		return false
	return int(w.sessions_today) < Economy.daily_capacity(w)


func available_workers() -> Array:
	var out: Array = []
	for w in GameState.workers:
		if _worker_available(w):
			out.append(w)
	return out


func _step_worker(w: Dictionary) -> void:
	var id := int(w.id)
	if not wrt.has(id):
		return
	var rt: Dictionary = wrt[id]
	var st := String(rt["state"])
	if bool(w.get("quit_pending", false)) and st in ["sit", "resting", "off_shift", "eating"]:
		GameState.remove_worker_data(id, "quit")
		return
	var hr := GameState.hour()
	w.hunger = minf(100.0, float(w.hunger) + Config.HUNGER_PER_HOUR / 60.0)
	w.thirst = minf(100.0, float(w.thirst) + Config.THIRST_PER_HOUR / 60.0)
	var buffed := GameState.abs_minutes() < int(w.buff_until)
	var rest_mult := (0.7 + float(w.rest_eff) / 100.0 * 0.8) * (1.0 + 0.25 * GameState.ulevel("lounge")) \
		* (1.15 if w.perks.has("rest_breaks") else 1.0)
	match st:
		"in_session":
			w.energy = maxf(0.0, float(w.energy) - float(rt["drain"]) * (0.6 if buffed else 1.0))
		"sit":
			w.energy = minf(100.0, float(w.energy) + 0.03 + 0.02 * GameState.ulevel("chairs"))
		"resting", "off_shift", "training":
			w.energy = minf(100.0, float(w.energy) + Config.REST_RECOVERY_PER_MIN * rest_mult)
		"eating":
			w.energy = minf(100.0, float(w.energy) + 0.1)
	_update_satisfaction(w)
	var on_duty := Economy.in_shift(String(w.shift), hr) and GameState.business_open
	var needy := float(w.hunger) >= Config.SEEK_NEED or float(w.thirst) >= Config.SEEK_NEED
	match st:
		"sit":
			if not on_duty:
				_send_to_lounge(w, "off_shift")
			elif needy:
				_send_to_kitchen(w)
			elif float(w.energy) <= Config.SEEK_ENERGY:
				_send_to_lounge(w, "resting")
		"eating":
			rt["timer"] = float(rt["timer"]) - 1.0
			if float(rt["timer"]) <= 0.0:
				_consume_needs(w)
				if float(w.energy) <= 45.0:
					_send_to_lounge(w, "resting")
				else:
					_send_to_seat(w)
		"resting":
			if not on_duty:
				rt["state"] = "off_shift"
			elif float(w.energy) >= Config.REST_UNTIL:
				if needy:
					_send_to_kitchen(w)
				else:
					_send_to_seat(w)
		"off_shift":
			if on_duty and float(w.energy) >= 50.0:
				_send_to_seat(w)
		"training":
			rt["timer"] = float(rt["timer"]) - 1.0
			if float(rt["timer"]) <= 0.0:
				_finish_training(w)


# ======================= MÜŞTERİLER =======================
func _make_customer_actor(c: Dictionary) -> NpcActor:
	var a := NpcActor.new()
	actors_root.add_child(a)
	a.setup(c.look, String(c.name), "customer", int(c.id))
	a.speed = 2.6
	a.arrived.connect(_on_customer_arrived.bind(int(c.id)))
	customer_actors[int(c.id)] = a
	return a


func _new_customer() -> void:
	var c := Generator.make_customer(GameState.reputation)
	GameState.stat_add("customers_arrived")
	_init_customer_runtime(c)
	c["state"] = "to_reception"
	GameState.customers.append(c)
	var a := _make_customer_actor(c)
	a.teleport(interior.layout["entrance"])
	a.walk_to([interior.layout["reception_stand"] + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.4, 0.8))])
	Sfx.play("door", 1.2)


func _init_customer_runtime(c: Dictionary) -> void:
	c["wait"] = float(c.get("wait", 0.0))
	c["worker"] = -1
	c["room"] = -1
	c["type"] = ""
	c["seat"] = -1
	c["timer"] = 0.0
	c["in_room"] = false


func _restore_customer(c: Dictionary) -> void:
	_init_customer_runtime(c)
	c["state"] = "choosing"
	GameState.customers.append(c)
	var a := _make_customer_actor(c)
	a.teleport(interior.layout["reception_stand"] + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.4, 0.8)))


func _tolerance(c: Dictionary) -> float:
	return float(c.wait_tol) * (1.0 + 0.12 * GameState.ulevel("chairs"))


func _on_customer_arrived(id: int) -> void:
	var c := GameState.get_customer(id)
	if c.is_empty():
		_drop_customer_actor(id)
		return
	var actor: NpcActor = customer_actors.get(id)
	match String(c.state):
		"to_reception":
			c.state = "greeting"
			c.timer = maxf(1.0, Config.GREET_MINUTES - GameState.ulevel("reception"))
		"to_seat":
			c.state = "waiting"
			actor.rotation.y = 0.0
			actor.sit(true)
		"to_room":
			_room_arrived(id, false)
		"leaving":
			_drop_customer_actor(id)
			GameState.remove_customer(id)
			GameState.data_changed.emit()


func _drop_customer_actor(id: int) -> void:
	if customer_actors.has(id):
		var a: NpcActor = customer_actors[id]
		if is_instance_valid(a):
			a.queue_free()
		customer_actors.erase(id)


func _step_customer(c: Dictionary) -> void:
	var st := String(c.state)
	if st in ["to_reception", "greeting", "choosing", "to_seat", "waiting"]:
		c.wait = float(c.wait) + 1.0
		if float(c.wait) > _tolerance(c):
			_customer_leave(c, true)
			return
	match st:
		"greeting":
			c.timer = float(c.timer) - 1.0
			if float(c.timer) <= 0.0:
				GameState.stat_add("greeted")
				c.state = "choosing"
				_choose(c)
		"choosing":
			_choose(c)


func _choose(c: Dictionary) -> void:
	if not _try_match(c):
		_seat_or_leave(c)


func _free_customer_seat() -> int:
	var used := {}
	for c in GameState.customers:
		if int(c.seat) >= 0 and String(c.state) in ["to_seat", "waiting"]:
			used[int(c.seat)] = true
	for i in GameState.waiting_capacity():
		if not used.has(i):
			return i
	return -1


func _seat_or_leave(c: Dictionary) -> void:
	var seat := _free_customer_seat()
	if seat < 0:
		_customer_leave(c, true, "Bekleme alanı dolu.")
		return
	c.seat = seat
	c.state = "to_seat"
	var a: NpcActor = customer_actors[int(c.id)]
	a.walk_to([interior.layout["customer_seats"][seat]])


func _customer_leave(c: Dictionary, angry: bool, why: String = "") -> void:
	var id := int(c.id)
	if angry:
		GameState.change_reputation(-Config.REP_LOSS_LEAVE)
		GameState.stat_add("customers_lost")
		GameState.stat_add("lost_full" if why != "" else "lost_timeout")
		GameState.bump_daily("lost", 1.0)
		_note("lost", "%s beklemekten vazgeçip ayrıldı. %s" % [c.name, why], "warn")
	c.state = "leaving"
	c.seat = -1
	var a: NpcActor = customer_actors.get(id)
	if a:
		a.visible = true
		a.walk_to([interior.layout["entrance"]])


func _spawn_step() -> void:
	if not GameState.business_open or GameState.workers.is_empty():
		return
	if GameState.customers.size() >= Config.MAX_CUSTOMERS_INSIDE:
		return
	var on_duty := false
	for w in GameState.workers:
		if Economy.in_shift(String(w.shift), GameState.hour()) and not bool(w.get("quit_pending", false)):
			on_duty = true
			break
	if not on_duty:
		return
	var rate := Config.BASE_ARRIVAL_PER_HOUR * float(Config.HOUR_CURVE[GameState.hour()]) \
		* (0.6 + GameState.reputation / 100.0 * 1.2) * (1.0 + 0.08 * GameState.ulevel("reception")) \
		* (0.8 + 0.1 * minf(8.0, float(GameState.workers.size())))
	if randf() < rate / 60.0:
		_new_customer()


# ======================= EŞLEŞTİRME & ODALAR =======================
func _free_room() -> int:
	for i in rooms.size():
		if String(rooms[i]["state"]) == "free":
			return i
	return -1


func free_rooms_count() -> int:
	var n := 0
	for r in rooms:
		if String(r["state"]) == "free":
			n += 1
	return n


func _try_match(c: Dictionary) -> bool:
	if not GameState.auto_match:
		return false
	var ri := _free_room()
	if ri < 0:
		return false
	var best: Dictionary = {}
	var best_score := -9999.0
	for w in GameState.workers:
		if not _worker_available(w):
			continue
		if Economy.session_price(w, "short") > float(c.budget):
			continue
		var score := Economy.pref_score(c, w) + randf_range(-8.0, 8.0)
		if score > best_score:
			best_score = score
			best = w
	if best.is_empty():
		return false
	return _pair(c, best, ri)


func _match_waiting() -> void:
	var list: Array = []
	for c in GameState.customers:
		if String(c.state) in ["waiting", "to_seat"]:
			list.append(c)
	list.sort_custom(func(a, b): return float(a.wait) > float(b.wait))
	for c in list:
		if _free_room() < 0:
			return
		_try_match(c)


func assign_manual(customer_id: int, worker_id: int) -> String:
	var c := GameState.get_customer(customer_id)
	var w := GameState.get_worker(worker_id)
	if c.is_empty() or w.is_empty():
		return "Kayıt bulunamadı."
	if not String(c.state) in ["choosing", "waiting", "to_seat"]:
		return "Müşteri şu an atanamaz."
	if not _worker_available(w):
		return "Çalışan şu an müsait değil."
	var ri := _free_room()
	if ri < 0:
		return "Boş oda yok."
	if Economy.session_price(w, "short") > float(c.budget):
		return "Müşterinin bütçesi bu çalışan için yetersiz."
	if not _pair(c, w, ri):
		return "Eşleşme yapılamadı."
	return ""


func _pair(c: Dictionary, w: Dictionary, ri: int) -> bool:
	var type_id := Economy.pick_type(c, w)
	if type_id == "":
		return false
	var wid := int(w.id)
	var cid := int(c.id)
	var room: Dictionary = rooms[ri]
	room["state"] = "reserved"
	room["worker"] = wid
	room["customer"] = cid
	room["type"] = type_id
	interior.set_room(ri, "reserved")
	c.state = "to_room"
	c.worker = wid
	c.room = ri
	c.type = type_id
	c.seat = -1
	c.in_room = false
	var rt: Dictionary = wrt[wid]
	rt["state"] = "to_room"
	rt["room"] = ri
	rt["customer"] = cid
	rt["in_room"] = false
	rt["inside"] = false
	var door: Vector3 = interior.layout["rooms"][ri]["door"]
	var inside: Vector3 = interior.layout["rooms"][ri]["inside"]
	worker_actors[wid].walk_to([door + Vector3(-0.35, 0, 0), inside + Vector3(-0.6, 0, 0)])
	customer_actors[cid].walk_to([door + Vector3(0.35, 0, 0), inside + Vector3(0.6, 0, 0)])
	return true


func _room_arrived(id: int, is_worker: bool) -> void:
	var ri := -1
	if is_worker:
		wrt[id]["in_room"] = true
		ri = int(wrt[id]["room"])
	else:
		var c := GameState.get_customer(id)
		c.in_room = true
		ri = int(c.room)
	if ri < 0 or ri >= rooms.size():
		return
	var room: Dictionary = rooms[ri]
	if String(room["state"]) != "reserved":
		return
	var wid := int(room["worker"])
	var cid := int(room["customer"])
	var c2 := GameState.get_customer(cid)
	if wrt.has(wid) and bool(wrt[wid]["in_room"]) and not c2.is_empty() and bool(c2.in_room):
		_start_session(ri)


func _start_session(ri: int) -> void:
	var room: Dictionary = rooms[ri]
	var wid := int(room["worker"])
	var cid := int(room["customer"])
	var w := GameState.get_worker(wid)
	var c := GameState.get_customer(cid)
	if w.is_empty() or c.is_empty():
		room["state"] = "free"
		interior.set_room(ri, "free")
		return
	var waiting := 0
	for cc in GameState.customers:
		if String(cc.state) in ["waiting", "to_seat", "choosing"]:
			waiting += 1
	var busy := clampf(float(waiting) / float(maxi(1, GameState.rooms_unlocked())), 0.0, 1.0)
	var dur := Economy.session_duration(w, String(room["type"]), busy)
	room["state"] = "busy"
	room["timer"] = dur
	room["total"] = dur
	var t: Dictionary = Config.SESSION_TYPES[room["type"]]
	var rt: Dictionary = wrt[wid]
	rt["state"] = "in_session"
	rt["inside"] = true
	rt["drain"] = float(t["energy"]) * (1.3 - float(w.endurance) / 100.0 * 0.6) / dur
	c.state = "in_session"
	worker_actors[wid].visible = false
	customer_actors[cid].visible = false
	interior.set_room(ri, "busy")
	interior.set_room_timer(ri, "%d dk" % int(dur))
	Sfx.play("door")


func _step_rooms() -> void:
	for i in rooms.size():
		var r: Dictionary = rooms[i]
		match String(r["state"]):
			"busy":
				r["timer"] = float(r["timer"]) - 1.0
				interior.set_room_timer(i, "%d dk" % int(maxf(0.0, ceilf(float(r["timer"])))))
				if float(r["timer"]) <= 0.0:
					_finish_session(i)
			"cleaning":
				r["timer"] = float(r["timer"]) - 1.0
				if float(r["timer"]) <= 0.0:
					r["state"] = "free"
					interior.set_room(i, "free")


func _finish_session(ri: int) -> void:
	var room: Dictionary = rooms[ri]
	var wid := int(room["worker"])
	var cid := int(room["customer"])
	var type_id := String(room["type"])
	var w := GameState.get_worker(wid)
	var c := GameState.get_customer(cid)
	room["state"] = "cleaning"
	room["timer"] = Economy.cleaning_minutes()
	room["worker"] = -1
	room["customer"] = -1
	interior.set_room(ri, "cleaning")
	Sfx.play("door", 0.9)
	if w.is_empty() or c.is_empty():
		return
	var price := Economy.session_price(w, type_id)
	var commission := roundf(price * float(w.commission))
	var worker_share := price - commission
	GameState.add_income(commission, "commission", "%s — %s (%s)" % [w.name, c.name, Config.SESSION_TYPES[type_id]["name"]])
	GameState.record_passthrough(worker_share, "Çalışan payı: %s" % w.name)
	var sat := Economy.customer_satisfaction(c, w, float(c.wait), price)
	c.satisfaction = sat
	w.total_earned = float(w.total_earned) + worker_share
	w.revenue = float(w.revenue) + commission
	w.sessions = int(w.sessions) + 1
	w.sessions_today = int(w.sessions_today) + 1
	w.experience = minf(100.0, float(w.experience) + 0.35)
	w.popularity = clampf(float(w.popularity) + (sat - 60.0) / 100.0 * 0.4, 0.0, 100.0)
	w.satisfaction = clampf(float(w.satisfaction) + (sat - 50.0) / 50.0 * 2.0, 0.0, 100.0)
	GameState.change_reputation((sat - 48.0) / 50.0 * Config.REP_PER_SESSION * (1.0 + 0.05 * GameState.ulevel("decor")))
	GameState.stat_add("sessions")
	GameState.stat_add("sat_sum", sat)
	GameState.stat_add("customers_served")
	GameState.stat_add("total_commission", commission)
	GameState.bump_daily("sessions", 1.0)
	Sfx.play("coin")
	# Aktörleri odadan çıkar
	var inside: Vector3 = interior.layout["rooms"][ri]["inside"]
	var door: Vector3 = interior.layout["rooms"][ri]["door"]
	var wa: NpcActor = worker_actors[wid]
	var ca: NpcActor = customer_actors[cid]
	wa.teleport(inside + Vector3(-0.6, 0, 0))
	ca.teleport(inside + Vector3(0.6, 0, 0))
	wa.visible = true
	ca.visible = true
	c.state = "leaving"
	c.room = -1
	ca.walk_to([door, interior.layout["entrance"]])
	var rt: Dictionary = wrt[wid]
	rt["customer"] = -1
	rt["in_room"] = false
	if float(w.energy) <= 45.0:
		_send_to_lounge(w, "resting")
	else:
		_send_to_seat(w)


func _on_upgrades_changed() -> void:
	for i in rooms.size():
		if String(rooms[i]["state"]) == "locked" and i < GameState.rooms_unlocked():
			rooms[i]["state"] = "free"
			interior.set_room(i, "free")
	interior.refresh_upgrades()


# ======================= DAKİKA ADIMI =======================
func step_minute() -> void:
	_spawn_step()
	for w in GameState.workers.duplicate():
		_step_worker(w)
	for c in GameState.customers.duplicate():
		_step_customer(c)
	_step_rooms()
	if GameState.auto_match:
		_match_waiting()
	GameState.data_changed.emit()


# ======================= ARAYÜZ SORGULARI =======================
func worker_status(id: int) -> String:
	if not wrt.has(id):
		return "—"
	var rt: Dictionary = wrt[id]
	var st := String(rt["state"])
	var txt := String(WORKER_STATUS.get(st, st))
	if st == "in_session" and int(rt["room"]) >= 0:
		txt += " (Oda %d)" % (int(rt["room"]) + 1)
	if bool(GameState.get_worker(id).get("quit_pending", false)):
		txt += " — ayrılacak"
	return txt


func waiting_minutes(id: int) -> int:
	if wrt.has(id) and String(wrt[id]["state"]) == "sit":
		return GameState.abs_minutes() - int(wrt[id]["sit_since"])
	return 0


func customer_status(c: Dictionary) -> String:
	return String(CUSTOMER_STATUS.get(String(c.state), String(c.state)))


func waiting_customer_count() -> int:
	var n := 0
	for c in GameState.customers:
		if String(c.state) in ["to_reception", "greeting", "choosing", "to_seat", "waiting"]:
			n += 1
	return n


func advice() -> Array:
	var out: Array = []
	if GameState.workers.is_empty():
		out.append("Henüz çalışanın yok. Şehirde dolaşıp potansiyel çalışanlarla konuş.")
	if int(GameState.inventory.get("water", 0)) <= 2:
		out.append("Su stoğu azalıyor. Envanter menüsünden sipariş ver.")
	if int(GameState.inventory.get("sandwich", 0)) + int(GameState.inventory.get("fruit", 0)) + int(GameState.inventory.get("meal", 0)) <= 2:
		out.append("Yiyecek stoğu azalıyor.")
	if waiting_customer_count() > 0 and _free_room() < 0:
		out.append("Müşteriler bekliyor ama boş oda yok. Yeni oda açmayı düşün.")
	for w in GameState.workers:
		if float(w.satisfaction) < 30.0:
			out.append("%s mutsuz! Payını/koşullarını iyileştir, ihtiyaçlarını karşıla." % w.name)
		if bool(w.get("wants_raise", false)):
			out.append("%s zam istiyor (yetenekleri arttı)." % w.name)
	if GameState.debt > 0.0:
		out.append("Ödenmemiş borcun var: %d$." % int(GameState.debt))
	if not GameState.business_open:
		out.append("İşletme kapalı; yeni müşteri gelmiyor.")
	return out
