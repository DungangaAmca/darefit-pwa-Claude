class_name Interior
extends Node3D
## İşletmenin iç mekânı: bekleme alanı, resepsiyon, mutfak, dinlenme alanı, 6 oda.
## `layout` sözlüğü tüm konumları dünya koordinatında verir.

var layout: Dictionary = {}
var room_nodes: Array = []
var cust_chairs: Array = []
var staff_chairs: Array = []
var lounge_sofas: Array = []
var kitchen_extra: Array = []
var decor_items: Array = []
var desk_mesh: MeshInstance3D
var counter_mesh: MeshInstance3D

const ROOM_COLORS := {
	"locked": Color(0.35, 0.35, 0.35), "free": Color(0.2, 1.0, 0.3), "reserved": Color(1.0, 0.85, 0.2),
	"busy": Color(1.0, 0.2, 0.2), "cleaning": Color(1.0, 0.55, 0.1),
}


func g(v: Vector3) -> Vector3:
	return position + v


func build() -> void:
	_shell()
	_rooms()
	_furniture()
	_lights()
	_compute_layout()
	refresh_upgrades()


func _shell() -> void:
	Build.box(self, Vector3(0, -0.25, 0), Vector3(31, 0.5, 25), Color(0.45, 0.32, 0.22), true)
	var wall := Color(0.82, 0.78, 0.72)
	Build.box(self, Vector3(0, 1.3, -12.15), Vector3(30.6, 2.6, 0.3), wall, true)
	Build.box(self, Vector3(-8.75, 1.3, 12.15), Vector3(13.5, 2.6, 0.3), wall, true)
	Build.box(self, Vector3(8.75, 1.3, 12.15), Vector3(13.5, 2.6, 0.3), wall, true)
	Build.box(self, Vector3(-15.15, 1.3, 0), Vector3(0.3, 2.6, 24.6), wall, true)
	Build.box(self, Vector3(15.15, 1.3, 0), Vector3(0.3, 2.6, 24.6), wall, true)
	Build.box(self, Vector3(0, 0.02, 11.4), Vector3(3.0, 0.04, 1.6), Color(0.5, 0.1, 0.1))
	Build.label(self, "ÇIKIŞ", Vector3(0, 2.9, 11.5), 40, Color(1, 0.6, 0.5))


func _rooms() -> void:
	for x in [-10.0, -5.0, 0.0, 5.0, 10.0]:
		Build.box(self, Vector3(x, 1.3, -9.0), Vector3(0.3, 2.6, 6.0), Color(0.72, 0.68, 0.62), true)
	for i in 6:
		var cx := -12.5 + 5.0 * i
		Build.box(self, Vector3(cx - 1.65, 1.3, -6.0), Vector3(1.7, 2.6, 0.3), Color(0.72, 0.68, 0.62), true)
		Build.box(self, Vector3(cx + 1.65, 1.3, -6.0), Vector3(1.7, 2.6, 0.3), Color(0.72, 0.68, 0.62), true)
		Build.box(self, Vector3(cx, 3.0, -6.0), Vector3(1.6, 0.8, 0.3), Color(0.72, 0.68, 0.62))
		Build.blocker(self, Vector3(cx, 1.3, -6.0), Vector3(1.6, 2.6, 0.3))
		var floor_m := Build.box(self, Vector3(cx, 0.02, -9.0), Vector3(4.6, 0.04, 5.6), Color(0.5, 0.4, 0.5))
		var bed := Build.box(self, Vector3(cx, 0.25, -10.4), Vector3(1.7, 0.5, 2.2), Color(0.6, 0.6, 0.65))
		var door := Build.box(self, Vector3(cx, 1.2, -6.0), Vector3(1.6, 2.4, 0.12), Color(0.35, 0.22, 0.12))
		var lamp_mat := Build.mat(Color(0.3, 0.3, 0.3), 1.5)
		var lamp := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.16
		sm.height = 0.32
		lamp.mesh = sm
		lamp.material_override = lamp_mat
		lamp.position = Vector3(cx, 2.65, -5.8)
		add_child(lamp)
		var title := Build.label(self, "ODA %d" % (i + 1), Vector3(cx, 3.5, -5.7), 40)
		var timer := Build.label(self, "", Vector3(cx, 3.05, -5.7), 36, Color(1, 0.9, 0.6))
		room_nodes.append({"door": door, "lamp_mat": lamp_mat, "title": title, "timer": timer, "bed": bed, "floor": floor_m,
			"closed": Vector3(cx, 1.2, -6.0), "open": Vector3(cx + 1.65, 1.2, -6.0), "state": ""})


func _chair(pos: Vector3, c: Color, wide: bool = false) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	add_child(n)
	var w := 1.3 if wide else 0.7
	Build.box(n, Vector3(0, 0.25, 0), Vector3(w, 0.5, 0.7), c)
	Build.box(n, Vector3(0, 0.65, -0.3), Vector3(w, 0.5, 0.12), c.darkened(0.2))
	return n


func _furniture() -> void:
	desk_mesh = Build.box(self, Vector3(6, 0.5, 9.6), Vector3(4, 1.0, 1.0), Color(0.4, 0.28, 0.2), true)
	Build.label(self, "RESEPSİYON", Vector3(6, 2.2, 9.6), 36, Color(1, 0.85, 0.5))
	Build.box(self, Vector3(-3, 0.4, 4.5), Vector3(2, 0.8, 1), Color(0.2, 0.2, 0.28), true)
	Build.box(self, Vector3(-3, 1.0, 4.4), Vector3(0.8, 0.5, 0.06), Color(0.3, 0.6, 0.9), false, 1.2)
	Build.label(self, "YÖNETİM MASASI", Vector3(-3, 2.0, 4.5), 32, Color(0.6, 0.85, 1))
	counter_mesh = Build.box(self, Vector3(14.3, 0.5, 5.0), Vector3(1.2, 1.0, 4.5), Color(0.55, 0.55, 0.58), true)
	Build.label(self, "MUTFAK / DEPO", Vector3(13.6, 2.2, 5.0), 32, Color(0.8, 1, 0.8))
	var fridge := Build.box(self, Vector3(14.4, 1.0, 2.4), Vector3(1.0, 2.0, 1.0), Color(0.85, 0.88, 0.9), true)
	var stove := Build.box(self, Vector3(14.4, 0.5, 7.7), Vector3(1.0, 1.0, 1.2), Color(0.2, 0.2, 0.22), true)
	var island := Build.box(self, Vector3(11.0, 0.5, 5.0), Vector3(0.9, 1.0, 3.0), Color(0.6, 0.5, 0.4), true)
	kitchen_extra = [{"node": fridge, "min": 1}, {"node": stove, "min": 2}, {"node": island, "min": 3}]
	Build.label(self, "BEKLEME ALANI", Vector3(-10, 1.6, 8.2), 32, Color(0.9, 0.9, 1))
	Build.label(self, "PERSONEL ALANI", Vector3(-8.7, 1.6, -3.9), 32, Color(0.9, 1, 0.9))
	Build.label(self, "DİNLENME", Vector3(9, 1.6, -3.9), 32, Color(1, 0.9, 0.8))
	for i in 10:
		var row := floori(i / 5.0)
		cust_chairs.append(_chair(Vector3(-14.0 + 2.0 * (i % 5), 0, 9.4 - 2.4 * row), Color(0.35, 0.3, 0.28)))
		staff_chairs.append(_chair(Vector3(-13.5 + 2.4 * (i % 5), 0, -3.0 + 2.2 * row), Color(0.3, 0.33, 0.4)))
		var lr := floori(i / 4.0)
		lounge_sofas.append(_chair(Vector3(5.5 + 2.3 * (i % 4), 0, -3.0 + 2.2 * lr), Color(0.4, 0.3, 0.45), true))
	Build.box(self, Vector3(-1.0, 0.02, 1.0), Vector3(7, 0.03, 3.5), Color(0.5, 0.2, 0.25))
	for p in [Vector3(-14, 0, 11), Vector3(14, 0, 11), Vector3(-14, 0, 1)]:
		Build.cyl(self, p + Vector3(0, 0.35, 0), 0.35, 0.7, Color(0.5, 0.3, 0.2))
		Build.sphere(self, p + Vector3(0, 1.1, 0), 0.55, Color(0.15, 0.5, 0.2))
	for i in 3:
		var art := Build.box(self, Vector3(-4.0 + i * 8.0, 1.8, 11.95), Vector3(2.0, 1.2, 0.08), [Color(0.8, 0.3, 0.3), Color(0.3, 0.5, 0.8), Color(0.9, 0.7, 0.2)][i])
		decor_items.append({"node": art, "min": i + 1})


func _lights() -> void:
	for p in [Vector3(-8, 3.5, 0), Vector3(8, 3.5, 0), Vector3(-8, 3.5, 8), Vector3(8, 3.5, 8), Vector3(0, 3.0, -9)]:
		var l := OmniLight3D.new()
		l.position = p
		l.light_color = Color(1.0, 0.88, 0.7)
		l.light_energy = 1.5
		l.omni_range = 14.0
		add_child(l)


func _compute_layout() -> void:
	var rooms: Array = []
	for i in 6:
		var cx := -12.5 + 5.0 * i
		rooms.append({"door": g(Vector3(cx, 0, -4.8)), "inside": g(Vector3(cx, 0, -9.2))})
	var cs: Array = []
	var ss: Array = []
	var ls: Array = []
	for i in 10:
		var row := floori(i / 5.0)
		cs.append(g(Vector3(-14.0 + 2.0 * (i % 5), 0, 9.4 - 2.4 * row)))
		ss.append(g(Vector3(-13.5 + 2.4 * (i % 5), 0, -3.0 + 2.2 * row)))
		var lr := floori(i / 4.0)
		ls.append(g(Vector3(5.5 + 2.3 * (i % 4), 0, -3.0 + 2.2 * lr)))
	layout = {"origin": position, "entrance": g(Vector3(0, 0, 10.6)), "spawn_in": g(Vector3(0, 0, 9.0)),
		"exit_stand": g(Vector3(0, 0, 10.6)), "reception_stand": g(Vector3(6, 0, 7.8)),
		"desk_stand": g(Vector3(-3, 0, 3.3)), "kitchen_stand": g(Vector3(12.8, 0, 5.0)),
		"customer_seats": cs, "staff_seats": ss, "lounge_spots": ls, "rooms": rooms}


func refresh_upgrades() -> void:
	var wc := GameState.waiting_capacity()
	var mw := GameState.max_workers()
	var comfy := GameState.ulevel("chairs")
	var lounge := GameState.ulevel("lounge")
	for i in cust_chairs.size():
		cust_chairs[i].visible = i < wc
	for i in staff_chairs.size():
		staff_chairs[i].visible = i < mw
		_tint(staff_chairs[i], Color(0.3, 0.33, 0.4).lerp(Color(0.2, 0.45, 0.55), comfy / 2.0))
	for i in lounge_sofas.size():
		lounge_sofas[i].visible = i < mw
		_tint(lounge_sofas[i], Color(0.4, 0.3, 0.45).lerp(Color(0.7, 0.25, 0.45), lounge / 3.0))
	for e in kitchen_extra:
		e["node"].visible = GameState.ulevel("kitchen") >= int(e["min"])
	for d in decor_items:
		d["node"].visible = GameState.ulevel("decor") >= int(d["min"])
	var fl := GameState.ulevel("furniture")
	var dc := GameState.ulevel("decor")
	var unlocked := GameState.rooms_unlocked()
	for i in room_nodes.size():
		var r: Dictionary = room_nodes[i]
		r["bed"].material_override.albedo_color = Color(0.6, 0.6, 0.65).lerp(Color(0.75, 0.2, 0.35), fl / 3.0)
		r["floor"].material_override.albedo_color = Color(0.5, 0.4, 0.5).lerp(Color(0.35, 0.2, 0.5), dc / 3.0)
		if i >= unlocked:
			r["title"].text = "ODA %d (kilitli)" % (i + 1)
		else:
			r["title"].text = "ODA %d" % (i + 1)
	_tint(desk_mesh, Color(0.4, 0.28, 0.2).lerp(Color(0.6, 0.4, 0.15), GameState.ulevel("reception") / 3.0))
	var kt := GameState.ulevel("kitchen")
	_tint(counter_mesh, Color(0.55, 0.55, 0.58).lerp(Color(0.8, 0.82, 0.85), kt / 3.0))


func _tint(n: Node, c: Color) -> void:
	if n is MeshInstance3D:
		(n as MeshInstance3D).material_override.albedo_color = c
		return
	var first := true
	for ch in n.get_children():
		if ch is MeshInstance3D:
			(ch as MeshInstance3D).material_override.albedo_color = c if first else c.darkened(0.2)
			first = false


func set_room(i: int, state: String) -> void:
	var r: Dictionary = room_nodes[i]
	if r["state"] == state:
		return
	r["state"] = state
	var closed := state == "locked" or state == "busy"
	var door: MeshInstance3D = r["door"]
	var target: Vector3 = r["closed"] if closed else r["open"]
	var tw := create_tween()
	tw.tween_property(door, "position", target, 0.3)
	var c: Color = ROOM_COLORS[state]
	var m: StandardMaterial3D = r["lamp_mat"]
	m.albedo_color = c
	m.emission = c
	if state != "busy":
		r["timer"].text = ""


func set_room_timer(i: int, text: String) -> void:
	room_nodes[i]["timer"].text = text
