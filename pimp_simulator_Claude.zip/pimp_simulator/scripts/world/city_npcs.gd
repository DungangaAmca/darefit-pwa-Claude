class_name CityNpcs
extends Node
## Şehirdeki NPC'ler: potansiyel çalışanlar ve yayalar. Durum makinesi: walk / idle / talk.

var city: City
var root: Node3D
var cand_actors: Dictionary = {}
var peds: Array = []
var brains: Dictionary = {}


func setup(c: City, r: Node3D) -> void:
	city = c
	root = r
	GameState.candidates_changed.connect(sync_candidates)


func rebuild() -> void:
	for a in cand_actors.values():
		_remove_actor(a)
	cand_actors.clear()
	for a in peds:
		_remove_actor(a)
	peds.clear()
	brains.clear()
	sync_candidates()
	for i in 8:
		var look := Generator.make_look(randf() < 0.5)
		var a := _spawn(look, "", "ped", -1)
		a.speed = randf_range(1.4, 2.0)
		peds.append(a)


func sync_candidates() -> void:
	if root == null:
		return
	for id in cand_actors.keys():
		if GameState.get_candidate(int(id)).is_empty():
			_remove_actor(cand_actors[id])
			cand_actors.erase(id)
	for c in GameState.candidates:
		if not cand_actors.has(int(c.id)):
			cand_actors[int(c.id)] = _spawn(c.look, String(c.name), "candidate", int(c.id))


func _spawn(look: Dictionary, label: String, kind: String, id: int) -> NpcActor:
	var a := NpcActor.new()
	root.add_child(a)
	a.setup(look, label, kind, id)
	a.speed = randf_range(1.5, 2.0)
	var li := randi() % city.loops.size()
	var lp: Array = city.loops[li]
	var idx := randi() % lp.size()
	var p: Vector3 = lp[idx]
	a.teleport(p + Vector3(randf_range(-0.5, 0.5), 0, randf_range(-0.5, 0.5)))
	var b := {"actor": a, "loop": li, "idx": idx, "dir": 1 if randf() < 0.5 else -1, "state": "idle", "wait": randf_range(0.2, 4.0)}
	brains[a.get_instance_id()] = b
	a.arrived.connect(_on_arrived.bind(a))
	return a


func _remove_actor(a: NpcActor) -> void:
	if is_instance_valid(a):
		brains.erase(a.get_instance_id())
		a.queue_free()


func _on_arrived(a: NpcActor) -> void:
	var b = brains.get(a.get_instance_id())
	if b == null or b["state"] == "talk":
		return
	b["state"] = "idle"
	b["wait"] = randf_range(0.3, 6.0) if randf() < 0.6 else 0.0


func _process(delta: float) -> void:
	for key in brains.keys():
		var b: Dictionary = brains[key]
		if b["state"] == "idle":
			b["wait"] = float(b["wait"]) - delta * NpcActor.time_scale
			if float(b["wait"]) <= 0.0:
				_next(b)


func _next(b: Dictionary) -> void:
	var a: NpcActor = b["actor"]
	if not is_instance_valid(a):
		return
	var lp: Array = city.loops[b["loop"]]
	b["state"] = "walk"
	if randf() < 0.22:
		var cur: Vector3 = lp[b["idx"]]
		var options: Array = []
		for li in city.loops.size():
			if li == b["loop"]:
				continue
			var l2: Array = city.loops[li]
			for ii in l2.size():
				if cur.distance_to(l2[ii]) < 14.5:
					options.append([li, ii])
		if not options.is_empty():
			var pick: Array = options.pick_random()
			b["loop"] = pick[0]
			b["idx"] = pick[1]
			var tgt: Vector3 = city.loops[pick[0]][pick[1]]
			a.walk_to([tgt])
			return
	b["idx"] = posmod(int(b["idx"]) + int(b["dir"]), lp.size())
	a.walk_to([lp[b["idx"]]])


func set_talking(id: int, on: bool, face_pos: Vector3 = Vector3.ZERO) -> void:
	var a: NpcActor = cand_actors.get(id)
	if a == null or not is_instance_valid(a):
		return
	var b = brains.get(a.get_instance_id())
	if b == null:
		return
	if on:
		b["state"] = "talk"
		a.stop()
		var d := face_pos - a.global_position
		a.rotation.y = atan2(d.x, d.z)
	else:
		b["state"] = "idle"
		b["wait"] = 1.0


func candidate_positions() -> Array:
	var out: Array = []
	for a in cand_actors.values():
		if is_instance_valid(a):
			out.append(a.global_position)
	return out
