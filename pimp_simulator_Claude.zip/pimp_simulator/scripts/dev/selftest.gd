extends Node
## Geliştirici testi: godot --headless --path . --fixed-fps 60 -- --selftest
## Oynanış döngüsünü otomatik sürer (işe alım → müşteri → görüşme → gelir → kayıt/yükleme).

var main: Node
var failures := 0


func check(cond: bool, msg: String) -> void:
	if cond:
		print("  OK    ", msg)
	else:
		print("  FAIL  ", msg)
		failures += 1


func run_minutes(n: int) -> void:
	var target := GameState.abs_minutes() + n
	var guard := 0
	while GameState.abs_minutes() < target and guard < 300000:
		await get_tree().process_frame
		guard += 1


func run(m: Node) -> void:
	main = m
	print("=== SELFTEST BAŞLADI ===")
	GameState.day_ended.connect(func(r): print("  [gün sonu] gün %d: görüşme %d, komisyon %d$, net %d$, nakit %d$, itibar %.1f" % [int(r["day"]), int(r["sessions"]), int(r["commission"]), int(r["net"]), int(r["cash"]), float(r["reputation"])]))
	GameState.day_ended.connect(func(_r): main.ui._close_popup.call_deferred())
	main.begin_game(false)
	await get_tree().process_frame
	check(GameState.money == Config.START_MONEY, "başlangıç parası 900$")
	check(GameState.candidates.size() >= 7, "şehirde aday var (%d)" % GameState.candidates.size())
	check(main.npcs.cand_actors.size() == GameState.candidates.size(), "aday aktörleri sahnede")
	for c in GameState.candidates:
		check(int(c.age) >= Config.MIN_ADULT_AGE, "aday yaşı >= 21 (%s %d)" % [c.name, int(c.age)])

	# Pazarlık
	var cand: Dictionary = GameState.candidates[0]
	var hi := Economy.negotiate_eval(cand, 0.60, String(cand.pref_shift), [])
	var counter := float(hi.counter)
	var lo := Economy.negotiate_eval(cand, counter, String(cand.pref_shift), [])
	print("  aday %s talebi: işletme payı max %%%d; yüksek teklif olasılığı %.2f; karşı teklif olasılığı %.2f" % [cand.name, int(counter * 100.0), float(hi.prob), float(lo.prob)])
	check(float(lo.prob) >= 0.99, "karşı teklif kabul edilir (olasılık 1)")
	check(float(hi.prob) <= float(lo.prob), "yüksek komisyon olasılığı düşürür")
	var err: String = main.business.hire(cand, counter, String(cand.pref_shift), ["free_meals"])
	check(err == "", "ilk çalışan işe alındı: '%s'" % err)
	check(GameState.workers.size() == 1, "çalışan listesi 1")
	check(GameState.quests_done.has("contract"), "görev: ilk sözleşme tamamlandı")

	# UI panelleri
	for m_id in ["workers", "customers", "business", "finance", "upgrades", "quests", "map", "inventory", "settings"]:
		main.ui.open_menu(m_id)
		main.ui.panels[m_id].refresh()
	main.ui.close_menu()
	check(true, "9 menü paneli hatasız açıldı")
	main.ui.open_hire(GameState.candidates[1], func(): pass)
	main.ui.hire._update_eval()
	main.ui.hire._close()
	check(true, "pazarlık ekranı hatasız açıldı")

	# İşletmeye gir/çık
	main._enter_business()
	await get_tree().process_frame
	check(main.in_interior, "işletmeye girildi")
	main._exit_business()
	check(not main.in_interior, "işletmeden çıkıldı")

	# Simülasyon: 1,5 gün
	GameState.set_speed(3)
	await run_minutes(1440 + 600)
	check(GameState.day >= 2, "oyun günü ilerliyor (gün %d)" % GameState.day)
	print("  durum: gün %d, nakit %d$, itibar %.1f, görüşme %d, kayıp müşteri %d" % [GameState.day, int(GameState.money), GameState.reputation, int(GameState.stats["sessions"]), int(GameState.stats["customers_lost"])])
	check(int(GameState.stats["greeted"]) > 0, "müşteri karşılandı")
	check(int(GameState.stats["sessions"]) > 0, "en az bir görüşme tamamlandı")
	check(float(GameState.stats["total_commission"]) > 0.0, "komisyon geliri elde edildi")
	check(GameState.quests_done.has("income"), "görev: ilk gelir")
	check(GameState.money >= 0.0, "para negatif değil")
	var w: Dictionary = GameState.workers[0] if not GameState.workers.is_empty() else {}
	check(not w.is_empty(), "çalışan hâlâ işletmede")
	if not w.is_empty():
		check(float(w.energy) >= 0.0 and float(w.energy) <= 100.0, "enerji 0-100 aralığında (%.1f)" % float(w.energy))
		check(float(w.hunger) <= 100.0 and float(w.thirst) <= 100.0, "açlık/susuzluk sınırlı")
		print("  çalışan: enerji %.0f açlık %.0f susuzluk %.0f memnuniyet %.0f toplam kazanç %d$" % [float(w.energy), float(w.hunger), float(w.thirst), float(w.satisfaction), int(w.total_earned)])
	check(GameState.transactions.size() > 0, "finans geçmişi kaydediliyor")

	# Satın alma / geliştirme / envanter / eğitim
	GameState.money += 3000.0
	GameState.reputation = 30.0
	var water_before := int(GameState.inventory.get("water", 0))
	check(Economy.buy_item("water", 10) == "", "su satın alındı")
	check(int(GameState.inventory["water"]) == water_before + 10, "envanter arttı")
	check(Economy.buy_item("meal", 1) != "", "mutfaksız yemek alınamaz")
	check(Economy.buy_upgrade("rooms") == "", "ikinci oda satın alındı")
	check(GameState.rooms_unlocked() == 2 and main.business.rooms[1]["state"] == "free", "yeni oda aktif")
	if GameState.unlocks.get("kitchen", false):
		check(Economy.buy_upgrade("kitchen") == "", "mutfak geliştirmesi")
	check(Economy.buy_upgrade("furniture") == "", "mobilya geliştirmesi")
	if not w.is_empty() and bool(GameState.unlocks.get("training", false)):
		var te: String = main.business.start_training(int(w.id), "communication")
		print("  eğitim: '%s' (durum: %s)" % [te, main.business.worker_status(int(w.id))])
		check(te == "" or te.begins_with("Çalışan şu an eğitime alınamaz"), "eğitim başlatma cevabı mantıklı")
	var cand2: Dictionary = GameState.candidates[0]
	var ev2 := Economy.negotiate_eval(cand2, 0.05, String(cand2.pref_shift), ["free_meals", "weekly_bonus"])
	check(main.business.hire(cand2, float(ev2.counter), String(cand2.pref_shift), []) == "", "ikinci çalışan işe alındı")

	await run_minutes(1440)
	print("  durum: gün %d, nakit %d$, itibar %.1f, görüşme %d, çalışan %d" % [GameState.day, int(GameState.money), GameState.reputation, int(GameState.stats["sessions"]), GameState.workers.size()])
	check(GameState.money >= 0.0, "para negatif değil (2. gün sonu)")

	# Kayıt / yükleme
	QuestSystem.check()
	var money_b := GameState.money
	var workers_b := GameState.workers.size()
	var day_b := GameState.day
	var rooms_b := GameState.rooms_unlocked()
	check(SaveSystem.save_game(), "kayıt yazıldı")
	main.begin_game(true)
	await get_tree().process_frame
	check(is_equal_approx(GameState.money, money_b), "yükleme: para aynı (%d$)" % int(GameState.money))
	check(GameState.workers.size() == workers_b, "yükleme: çalışan sayısı aynı")
	check(GameState.day == day_b and GameState.rooms_unlocked() == rooms_b, "yükleme: gün ve oda sayısı aynı")
	check(main.business.worker_actors.size() == workers_b, "yükleme: çalışan aktörleri yeniden kuruldu")
	await run_minutes(600)
	check(GameState.money >= 0.0 and GameState.workers.size() > 0, "yüklenen oyun sorunsuz devam ediyor")

	# Pazarlık ekranı akışı (reddet -> karşı teklif -> kabul)
	var hd = main.ui.hire
	var c3: Dictionary = GameState.candidates[0]
	main.ui.open_hire(c3, func(): pass)
	hd.slider.value = 60.0
	hd._on_offer()
	var hired_early := GameState.workers.size() > workers_b
	if not hired_early:
		check(hd.btn_counter.visible and hd.counter_val > 0.0, "ret sonrası karşı teklif düğmesi görünür (%%%d)" % int(hd.counter_val * 100.0))
		check(int(c3.patience) == 2, "sabır azaldı")
		hd._on_counter()
		check(GameState.workers.size() == workers_b + 1, "karşı teklif kabul edilince işe alım oldu")
	hd._close()
	var c4: Dictionary = GameState.candidates[0]
	main.ui.open_hire(c4, func(): pass)
	hd.slider.value = 60.0
	for i in 5:
		if not hd.finished:
			hd._on_offer()
	check(hd.finished or GameState.workers.size() >= GameState.max_workers(), "sabır bitince / kapasite dolunca pazarlık kilitlenir")
	hd._close()

	# Çalışan yönetimi: eşya, dinlenme, zam, fesih
	var wk: Dictionary = GameState.workers[0]
	var wid := int(wk.id)
	var before_water := int(GameState.inventory.get("water", 0))
	var e1: String = main.business.give_item(wid, "water")
	check(e1 == "" or e1.begins_with("Çalışan şu an görüşmede"), "su verme: '%s'" % e1)
	if e1 == "":
		check(int(GameState.inventory["water"]) == before_water - 1, "su stoktan düştü")
	print("  zam: '%s' · dinlenme: '%s'" % [main.business.give_raise(wid), main.business.send_rest(wid)])
	GameState.auto_match = false
	await run_minutes(240)
	var manual_done := false
	for cu in GameState.customers:
		if String(cu.state) in ["waiting", "to_seat", "choosing"]:
			var r: String = main.business.assign_manual(int(cu.id), wid)
			print("  elle atama: '%s'" % r)
			manual_done = true
			break
	print("  elle atama denendi: %s" % str(manual_done))
	GameState.auto_match = true
	await run_minutes(240)
	var rel_target := int(GameState.workers[GameState.workers.size() - 1].id)
	var rel: String = main.business.release_worker(rel_target)
	print("  fesih: '%s'" % rel)
	check(rel == "" or rel.begins_with("Görüşmedeki"), "fesih yanıtı mantıklı")
	await run_minutes(120)
	check(main.business.worker_actors.size() == GameState.workers.size(), "aktör sayısı çalışan sayısıyla eşleşiyor")
	check(GameState.money >= 0.0, "para negatif değil (uzun test sonu)")

	# Elle atama (otomatik eşleştirme kapalı)
	GameState.auto_match = false
	GameState.business_open = true
	for ww in GameState.workers:
		ww.shift = "flex"
		ww.energy = 100.0
		ww.hunger = 10.0
		ww.thirst = 10.0
		ww.sessions_today = 0
	await run_minutes(120)
	main.business._new_customer()
	var test_c: Dictionary = GameState.customers[GameState.customers.size() - 1]
	test_c.budget = 500.0
	test_c.wait_tol = 400.0
	await run_minutes(60)
	check(String(test_c.state) in ["waiting", "to_seat"], "otomatik kapalıyken müşteri bekleme alanında (%s)" % String(test_c.state))
	var avail: Array = main.business.available_workers()
	if not avail.is_empty() and String(test_c.state) in ["waiting", "to_seat"]:
		var served_b := int(GameState.stats["sessions"])
		var ra: String = main.business.assign_manual(int(test_c.id), int(avail[0].id))
		check(ra == "" or ra == "Boş oda yok.", "elle atama: '%s'" % ra)
		await run_minutes(240)
		check(int(GameState.stats["sessions"]) > served_b or ra != "", "elle atanan görüşme tamamlandı")
	GameState.auto_match = true

	# Borç / oyun sonu mantığı
	GameState.money = 0.0
	GameState.force_expense(100.0, "rent", "test")
	check(is_equal_approx(GameState.debt, 100.0) and GameState.money == 0.0, "zorunlu gider borca yazıldı")
	check(not GameState.spend(-5.0, "food", "x"), "negatif harcama reddedildi")

	print("=== SELFTEST BİTTİ: %d hata ===" % failures)
	get_tree().quit(failures)
