extends Node
## Denge testi: godot --headless --path . --fixed-fps 60 -- --balance
## Yükseltme yapmadan 2 çalışanla (1 oda!) 6 günlük akışı yazdırır.

var main: Node


func restock() -> void:
	# Dikkatli oyuncu: stok azalınca sipariş verir
	var inv := GameState.inventory
	if int(inv.get("water", 0)) < 6:
		Economy.buy_item("water", 10)
	if int(inv.get("sandwich", 0)) < 4:
		Economy.buy_item("sandwich", 6)
	if int(inv.get("fruit", 0)) < 3:
		Economy.buy_item("fruit", 4)
	if int(inv.get("coffee", 0)) < 2:
		Economy.buy_item("coffee", 4)


func run_minutes(n: int) -> void:
	var target := GameState.abs_minutes() + n
	var guard := 0
	var last_hour := -1
	while GameState.abs_minutes() < target and guard < 400000:
		await get_tree().process_frame
		guard += 1
		if GameState.hour() != last_hour:
			last_hour = GameState.hour()
			if "--restock" in OS.get_cmdline_user_args():
				restock()


func run(m: Node) -> void:
	main = m
	GameState.day_ended.connect(func(r):
		print("gün %d: gelen %d, görüşme %d, kayıp %d, komisyon %d$, net %d$, nakit %d$, itibar %.1f" % [int(r["day"]), int(GameState.stats["customers_arrived"]), int(r["sessions"]), int(r["lost"]), int(r["commission"]), int(r["net"]), int(r["cash"]), float(r["reputation"])])
		main.ui._close_popup.call_deferred())
	main.begin_game(false)
	await get_tree().process_frame
	for i in 2:
		var cand: Dictionary = GameState.candidates[i]
		var ev := Economy.negotiate_eval(cand, 0.35, "flex", [])
		var comm := float(ev.counter)
		var err: String = main.business.hire(cand, comm, "flex", [])
		print("işe alım %s: komisyon %%%d, hata '%s', std fiyat %d$" % [cand.name, int(comm * 100.0), err, int(ev.std_price)])
	GameState.set_speed(3)
	await run_minutes(12 * 1440)
	print("son: gün %d nakit %d$ itibar %.1f görüşme %d gelen %d kayıp %d" % [GameState.day, int(GameState.money), GameState.reputation, int(GameState.stats["sessions"]), int(GameState.stats["customers_arrived"]), int(GameState.stats["customers_lost"])])
	print("  ort. müşteri memnuniyeti %.1f; kayıp: zaman aşımı %d, dolu %d" % [float(GameState.stats["sat_sum"]) / maxf(1.0, float(GameState.stats["sessions"])), int(GameState.stats.get("lost_timeout", 0)), int(GameState.stats.get("lost_full", 0))])
	for w in GameState.workers:
		print("  %s: enerji %.0f memnuniyet %.0f toplam kazanç %d$ görüşme %d" % [w.name, float(w.energy), float(w.satisfaction), int(w.total_earned), int(w.sessions)])
	get_tree().quit(0)


func _dump() -> void:
	print("--- DUMP gün %d %s ---" % [GameState.day, GameState.clock_text()])
	for i in main.business.rooms.size():
		var r: Dictionary = main.business.rooms[i]
		print("  oda %d: %s worker %d customer %d timer %.0f" % [i, r["state"], int(r["worker"]), int(r["customer"]), float(r["timer"])])
	for w in GameState.workers:
		var rt: Dictionary = main.business.wrt[int(w.id)]
		print("  çalışan %s: state=%s en=%.0f hu=%.0f th=%.0f seshtoday=%d vardiya=%s room=%d inside=%s" % [w.name, rt["state"], float(w.energy), float(w.hunger), float(w.thirst), int(w.sessions_today), w.shift, int(rt["room"]), str(rt["inside"])])
	for c in GameState.customers:
		print("  müşteri %s: state=%s wait=%.0f room=%d worker=%d seat=%d in_room=%s" % [c.name, c.state, float(c.wait), int(c.room), int(c.worker), int(c.seat), str(c.in_room)])
	print("  envanter: ", GameState.inventory)
