extends Node
## Aday çalışan ve müşteri üretimi. Tüm karakterler 21+ yaşındadır.

const SKIN := ["#f1c9a5", "#e3b48a", "#c68d5f", "#a46b43", "#7a4a2b", "#5a3520"]
const HAIRS := [["Siyah", "#1c1512"], ["Kumral", "#5b3a24"], ["Koyu kahve", "#33211a"], ["Sarı", "#cfa95e"], ["Kızıl", "#9c4324"], ["Gri", "#9a9a9a"]]
const OUTFIT_F := ["#c0392b", "#8e44ad", "#2980b9", "#16a085", "#d35400", "#2c3e50", "#e84393", "#27ae60"]
const OUTFIT_M := ["#34495e", "#2c3e50", "#7f8c8d", "#6c5b45", "#3b5a3b", "#5d3b3b"]
const STYLE_NAMES := {"long": "uzun saçlı", "bun": "topuzlu", "short": "kısa saçlı"}


func make_look(female: bool) -> Dictionary:
	var h: Array = HAIRS.pick_random()
	var styles: Array = ["long", "bun", "short"] if female else ["short"]
	var outfits: Array = OUTFIT_F if female else OUTFIT_M
	return {"skin": SKIN.pick_random(), "hair": h[1], "hair_name": h[0], "outfit": outfits.pick_random(),
		"height": randf_range(0.93, 1.06), "style": styles.pick_random()}


func appearance_text(look: Dictionary) -> String:
	var hgt := float(look.get("height", 1.0))
	var boy := "Orta boylu"
	if hgt < 0.97:
		boy = "Kısa boylu"
	elif hgt > 1.03:
		boy = "Uzun boylu"
	return "%s · %s, %s" % [boy, String(look.get("hair_name", "Kumral")), String(STYLE_NAMES.get(look.get("style", "short"), "kısa saçlı"))]


func _unique_name(pool: Array) -> String:
	var taken := {}
	for list in [GameState.candidates, GameState.workers]:
		for p in list:
			taken[String(p.name)] = true
	var nm: String = pool.pick_random()
	for i in 8:
		if not taken.has(nm):
			break
		nm = pool.pick_random()
	return nm


func make_candidate(rep: float) -> Dictionary:
	var base := clampf(12.0 + rep * 0.4 + randf_range(-8.0, 22.0), 5.0, 90.0)
	var exp := clampf(base + randf_range(-15.0, 15.0), 3.0, 95.0)
	var pop := clampf(base + randf_range(-20.0, 20.0), 3.0, 95.0)
	var d := {}
	d["id"] = GameState.new_id()
	d["name"] = _unique_name(Config.FEMALE_NAMES)
	d["look"] = make_look(true)
	d["experience"] = exp
	d["popularity"] = pop
	d["communication"] = clampf(base + randf_range(-20.0, 20.0), 5.0, 95.0)
	d["quality"] = clampf(base + randf_range(-20.0, 20.0), 5.0, 95.0)
	d["endurance"] = clampf(base + randf_range(-20.0, 20.0), 5.0, 95.0)
	d["rest_eff"] = clampf(base + randf_range(-20.0, 20.0), 5.0, 95.0)
	d["expectation"] = clampf(pop * 0.6 + exp * 0.3 + randf_range(-10.0, 15.0), 5.0, 95.0)
	d["age"] = int(clampf(21.0 + exp * 0.22 + randf_range(-2.0, 8.0), Config.MIN_ADULT_AGE, Config.MAX_WORKER_AGE))
	d["personality"] = Config.PERSONALITIES.keys().pick_random()
	d["pref_shift"] = Config.SHIFT_ORDER.pick_random()
	d["trust"] = randf_range(30.0, 70.0)
	d["patience"] = 3
	d["met"] = false
	d["refuse_until"] = 0
	return d


func make_customer(rep: float) -> Dictionary:
	var female := randf() < 0.3
	var c := {}
	c["id"] = GameState.new_id()
	c["name"] = (Config.FEMALE_NAMES if female else Config.MALE_NAMES).pick_random()
	c["age"] = randi_range(21, 62)
	var rich := randf() < 0.15
	c["budget"] = roundf(randf_range(60.0, 150.0) + rep * randf_range(0.4, 1.4) + (randf_range(60.0, 200.0) if rich else 0.0))
	c["pref"] = ["popular", "experienced", "friendly", "affordable", "any", "any"].pick_random()
	c["wait_tol"] = randf_range(28.0, 70.0)
	c["spend_tend"] = randf()
	c["satisfaction"] = 50.0
	c["look"] = make_look(female)
	return c
