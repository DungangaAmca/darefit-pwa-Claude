extends Node
## Kayıt / yükleme ve kullanıcı ayarları.

var settings := {"volume": 0.8, "ambient": true, "autosave": true, "names": true}


func _ready() -> void:
	load_settings()


func has_save() -> bool:
	return FileAccess.file_exists(Config.SAVE_PATH)


func save_game() -> bool:
	var tmp := Config.SAVE_PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_error("Kayıt dosyası açılamadı: %s" % str(FileAccess.get_open_error()))
		return false
	f.store_string(JSON.stringify(GameState.to_dict()))
	f.close()
	var err := DirAccess.rename_absolute(ProjectSettings.globalize_path(tmp), ProjectSettings.globalize_path(Config.SAVE_PATH))
	if err != OK:
		push_error("Kayıt dosyası yeniden adlandırılamadı: %s" % str(err))
		return false
	return true


func load_game() -> bool:
	if not has_save():
		return false
	var f := FileAccess.open(Config.SAVE_PATH, FileAccess.READ)
	if f == null:
		push_error("Kayıt dosyası okunamadı.")
		return false
	var txt := f.get_as_text()
	f.close()
	var data = JSON.parse_string(txt)
	if typeof(data) != TYPE_DICTIONARY:
		push_error("Kayıt dosyası bozuk.")
		return false
	GameState.from_dict(data)
	return true


func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(Config.SAVE_PATH))


func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(Config.SETTINGS_PATH) == OK:
		for k in settings.keys():
			settings[k] = cf.get_value("settings", k, settings[k])
	apply_settings()


func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in settings.keys():
		cf.set_value("settings", k, settings[k])
	cf.save(Config.SETTINGS_PATH)


func apply_settings() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(float(settings["volume"]), 0.0001)))
	NpcActor.show_names = bool(settings["names"])
