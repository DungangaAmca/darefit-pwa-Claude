extends Node
## Oyunun tüm çalışma zamanı verisi ve sinyal merkezi. Kayıt/yükleme buradan geçer.

signal money_changed
signal time_changed
signal reputation_changed
signal notified(msg: String, kind: String)
signal data_changed
signal upgrades_changed
signal speed_changed
signal candidates_changed
signal day_ended(report: Dictionary)
signal quest_completed(quest: Dictionary)
signal worker_removed(id: int, reason: String)
signal game_over(reason: String)

const DAILY_KEYS := ["commission", "worker_pay", "food", "rent", "maintenance", "upgrade", "training", "perks", "reward", "sessions", "lost"]

var started := false
var is_game_over := false
var player_name := "Patron"
var business_name := "Gece Salonu"
var money := 0.0
var reputation := 10.0
var debt := 0.0
var day := 1
var minute_of_day := 540
var speed_index := 1
var xp := 0.0
var business_open := true
var auto_match := true
var next_id := 1
var workers: Array = []
var candidates: Array = []
var customers: Array = []
var inventory: Dictionary = {}
var upgrades: Dictionary = {}
var quests_done: Array = []
var unlocks: Dictionary = {}
var stats: Dictionary = {}
var transactions: Array = []
var daily_stats: Dictionary = {}


func reset() -> void:
	started = false
	is_game_over = false
	money = Config.START_MONEY
	reputation = Config.START_REPUTATION
	debt = 0.0
	day = 1
	minute_of_day = Config.START_MINUTE
	speed_index = 1
	xp = 0.0
	business_open = true
	auto_match = true
	next_id = 1
	workers = []
	candidates = []
	customers = []
	inventory = {"water": 12, "coffee": 3, "fruit": 6, "sandwich": 6}
	upgrades = {}
	quests_done = []
	unlocks = {}
	stats = _default_stats()
	transactions = []
	daily_stats = {}
	fill_candidates()


func _default_stats() -> Dictionary:
	return {"met": 0, "contracts": 0, "greeted": 0, "sessions": 0, "total_commission": 0.0,
		"customers_served": 0, "customers_lost": 0, "customers_arrived": 0, "upgrades_bought": 0, "best_day": 0.0}


# ---------------- Zaman ----------------
func hour() -> int:
	return floori(minute_of_day / 60.0)


func abs_minutes() -> int:
	return (day - 1) * Config.MINUTES_PER_DAY + minute_of_day


func clock_text() -> String:
	return "%02d:%02d" % [hour(), minute_of_day % 60]


func speed() -> float:
	return float(Config.SPEED_STEPS[speed_index])


func set_speed(i: int) -> void:
	speed_index = clampi(i, 0, Config.SPEED_STEPS.size() - 1)
	speed_changed.emit()


func advance_minute() -> void:
	minute_of_day += 1
	if minute_of_day >= Config.MINUTES_PER_DAY:
		Economy.end_of_day(day)
		minute_of_day = 0
		day += 1
		Economy.start_of_day()
	time_changed.emit()


# ---------------- Para ----------------
func daily(d: int) -> Dictionary:
	var key := str(d)
	if not daily_stats.has(key):
		var s := {}
		for k in DAILY_KEYS:
			s[k] = 0.0
		daily_stats[key] = s
		if daily_stats.size() > 90:
			var oldest := str(d - 90)
			daily_stats.erase(oldest)
	return daily_stats[key]


func bump_daily(key: String, amount: float) -> void:
	var s := daily(day)
	s[key] = float(s.get(key, 0.0)) + amount


func _record(cat: String, amt: float, desc: String, cash: bool) -> void:
	transactions.append({"day": day, "min": minute_of_day, "cat": cat, "amt": amt, "desc": desc, "cash": cash})
	if transactions.size() > 600:
		transactions = transactions.slice(100)


func add_income(amount: float, cat: String, desc: String) -> void:
	if not is_finite(amount) or amount <= 0.0:
		return
	money += amount
	bump_daily(cat, amount)
	_record(cat, amount, desc, true)
	money_changed.emit()


func spend(amount: float, cat: String, desc: String) -> bool:
	if not is_finite(amount) or amount < 0.0:
		push_error("Geçersiz harcama tutarı: %s" % str(amount))
		return false
	if amount > money + 0.001:
		return false
	money = maxf(0.0, money - amount)
	bump_daily(cat, amount)
	_record(cat, -amount, desc, true)
	money_changed.emit()
	return true


## Zorunlu gider: ödenebilen kısmı nakitten, kalanı borç olarak yazılır.
func force_expense(amount: float, cat: String, desc: String) -> void:
	if not is_finite(amount) or amount <= 0.0:
		return
	var pay := minf(amount, maxf(money, 0.0))
	money -= pay
	var rest := amount - pay
	if rest > 0.001:
		debt += rest
	bump_daily(cat, amount)
	_record(cat, -amount, desc + (" (borca yazıldı: %d$)" % int(rest) if rest > 0.001 else ""), true)
	money_changed.emit()


func record_passthrough(amount: float, desc: String) -> void:
	if amount <= 0.0:
		return
	bump_daily("worker_pay", amount)
	_record("worker_pay", amount, desc, false)


func change_reputation(delta: float) -> void:
	if delta > 0.0:
		delta *= (1.0 - reputation / 130.0)
	reputation = clampf(reputation + delta, 0.0, 100.0)
	reputation_changed.emit()


func notify(msg: String, kind: String = "info") -> void:
	notified.emit(msg, kind)


func stat_add(key: String, amount: float = 1.0) -> void:
	stats[key] = float(stats.get(key, 0.0)) + amount


# ---------------- Yardımcılar ----------------
func new_id() -> int:
	next_id += 1
	return next_id


func ulevel(id: String) -> int:
	return int(upgrades.get(id, 0))


func rooms_unlocked() -> int:
	return Config.START_ROOMS + ulevel("rooms")


func max_workers() -> int:
	return 1 + rooms_unlocked() + ulevel("lounge")


func waiting_capacity() -> int:
	return 3 + 2 * ulevel("waiting")


func storage_capacity() -> int:
	return 40 + 40 * ulevel("kitchen")


func inventory_total() -> int:
	var n := 0
	for k in inventory:
		n += int(inventory[k])
	return n


func total_upgrade_levels() -> int:
	var n := 0
	for k in upgrades:
		if k != "rooms":
			n += int(upgrades[k])
	return n


func player_level() -> int:
	return 1 + int(sqrt(xp / 40.0))


func get_worker(id: int) -> Dictionary:
	for w in workers:
		if int(w.id) == id:
			return w
	return {}


func get_customer(id: int) -> Dictionary:
	for c in customers:
		if int(c.id) == id:
			return c
	return {}


func get_candidate(id: int) -> Dictionary:
	for c in candidates:
		if int(c.id) == id:
			return c
	return {}


func remove_candidate(id: int) -> void:
	for i in candidates.size():
		if int(candidates[i].id) == id:
			candidates.remove_at(i)
			break
	candidates_changed.emit()


func remove_customer(id: int) -> void:
	for i in customers.size():
		if int(customers[i].id) == id:
			customers.remove_at(i)
			break


func remove_worker_data(id: int, reason: String) -> void:
	for i in workers.size():
		if int(workers[i].id) == id:
			var nm := String(workers[i].name)
			workers.remove_at(i)
			worker_removed.emit(id, reason)
			if reason == "quit":
				notify("%s sözleşmesini sonlandırıp işten ayrıldı." % nm, "warn")
			else:
				notify("%s ile sözleşme sona erdi." % nm, "info")
			data_changed.emit()
			return


func fill_candidates() -> void:
	var target := Config.CANDIDATE_POOL + int(reputation / 35.0)
	while candidates.size() < target:
		candidates.append(Generator.make_candidate(reputation))
	candidates_changed.emit()


func rotate_candidates() -> void:
	for n in 2:
		if candidates.size() > 3:
			candidates.remove_at(randi() % candidates.size())
	fill_candidates()


func trigger_game_over(reason: String) -> void:
	if is_game_over:
		return
	is_game_over = true
	game_over.emit(reason)


# ---------------- Kayıt ----------------
func to_dict() -> Dictionary:
	return {"version": 1, "player_name": player_name, "business_name": business_name, "money": money,
		"reputation": reputation, "debt": debt, "day": day, "minute_of_day": minute_of_day,
		"speed_index": speed_index, "xp": xp, "business_open": business_open, "auto_match": auto_match,
		"next_id": next_id, "workers": workers, "candidates": candidates, "customers": customers,
		"inventory": inventory, "upgrades": upgrades, "quests_done": quests_done, "unlocks": unlocks,
		"stats": stats, "transactions": transactions, "daily_stats": daily_stats}


func from_dict(d: Dictionary) -> void:
	reset()
	player_name = String(d.get("player_name", "Patron"))
	business_name = String(d.get("business_name", "Gece Salonu"))
	money = maxf(0.0, float(d.get("money", Config.START_MONEY)))
	reputation = clampf(float(d.get("reputation", 10.0)), 0.0, 100.0)
	debt = maxf(0.0, float(d.get("debt", 0.0)))
	day = maxi(1, int(d.get("day", 1)))
	minute_of_day = clampi(int(d.get("minute_of_day", Config.START_MINUTE)), 0, Config.MINUTES_PER_DAY - 1)
	speed_index = clampi(int(d.get("speed_index", 1)), 0, Config.SPEED_STEPS.size() - 1)
	xp = maxf(0.0, float(d.get("xp", 0.0)))
	business_open = bool(d.get("business_open", true))
	auto_match = bool(d.get("auto_match", true))
	next_id = int(d.get("next_id", 1))
	workers = _fix_people(d.get("workers", []))
	candidates = _fix_people(d.get("candidates", []))
	customers = _fix_people(d.get("customers", []))
	inventory = {}
	var inv: Dictionary = d.get("inventory", {})
	for k in inv:
		inventory[String(k)] = maxi(0, int(inv[k]))
	upgrades = {}
	var up: Dictionary = d.get("upgrades", {})
	for k in up:
		upgrades[String(k)] = maxi(0, int(up[k]))
	quests_done = Array(d.get("quests_done", []))
	unlocks = Dictionary(d.get("unlocks", {}))
	var st := _default_stats()
	var saved_stats: Dictionary = d.get("stats", {})
	for k in saved_stats:
		st[String(k)] = saved_stats[k]
	stats = st
	transactions = Array(d.get("transactions", []))
	daily_stats = Dictionary(d.get("daily_stats", {}))
	if candidates.is_empty():
		fill_candidates()


func _fix_people(arr: Array) -> Array:
	var out: Array = []
	for p in arr:
		if typeof(p) != TYPE_DICTIONARY:
			continue
		var q: Dictionary = p
		for k in ["id", "age", "slot", "sessions", "sessions_today", "hired_day", "low_sat_days", "patience", "refuse_until", "seat", "room", "worker", "buff_until"]:
			if q.has(k):
				q[k] = int(q[k])
		if int(q.get("age", 21)) < Config.LEGAL_ADULT_AGE:
			continue
		out.append(q)
	return out
