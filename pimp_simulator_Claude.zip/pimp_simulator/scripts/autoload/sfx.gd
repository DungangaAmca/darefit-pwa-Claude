extends Node
## Prosedürel ses efektleri (harici ses dosyası gerekmez).

const RATE := 22050
var streams: Dictionary = {}
var players: Array = []
var ambient: AudioStreamPlayer


func _ready() -> void:
	streams["click"] = _tone([[900.0, 700.0, 0.05]], 0.3)
	streams["coin"] = _tone([[880.0, 880.0, 0.07], [1320.0, 1320.0, 0.12]], 0.35)
	streams["notify"] = _tone([[660.0, 660.0, 0.08], [880.0, 880.0, 0.1]], 0.3)
	streams["error"] = _tone([[180.0, 140.0, 0.18]], 0.4)
	streams["quest"] = _tone([[660.0, 660.0, 0.08], [880.0, 880.0, 0.08], [1180.0, 1180.0, 0.18]], 0.35)
	streams["talk"] = _tone([[420.0, 520.0, 0.06], [500.0, 380.0, 0.08]], 0.25)
	streams["door"] = _noise(0.22, 0.45)
	for i in 4:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	ambient = AudioStreamPlayer.new()
	ambient.stream = _hum()
	ambient.volume_db = -22.0
	add_child(ambient)
	if bool(SaveSystem.settings.get("ambient", true)):
		ambient.play()


func set_ambient(on: bool) -> void:
	if on and not ambient.playing:
		ambient.play()
	elif not on:
		ambient.stop()


func play(sound: String, pitch: float = 1.0) -> void:
	if not streams.has(sound):
		return
	for p in players:
		if not p.playing:
			p.stream = streams[sound]
			p.pitch_scale = pitch
			p.play()
			return
	players[0].stream = streams[sound]
	players[0].pitch_scale = pitch
	players[0].play()


func _make(data: PackedByteArray, looped: bool = false) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	if looped:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = data.size() / 2
	return w


func _tone(parts: Array, vol: float) -> AudioStreamWAV:
	var total := 0
	for p in parts:
		total += int(float(p[2]) * RATE)
	var data := PackedByteArray()
	data.resize(total * 2)
	var idx := 0
	var phase := 0.0
	for p in parts:
		var n := int(float(p[2]) * RATE)
		for i in n:
			var t := float(i) / float(n)
			var f := lerpf(float(p[0]), float(p[1]), t)
			phase += TAU * f / RATE
			var env := minf(1.0, float(i) / 120.0) * pow(1.0 - t, 1.4)
			data.encode_s16(idx * 2, int(sin(phase) * env * vol * 32000.0))
			idx += 1
	return _make(data)


func _noise(dur: float, vol: float) -> AudioStreamWAV:
	var n := int(dur * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var prev := 0.0
	for i in n:
		var t := float(i) / float(n)
		prev = prev * 0.8 + (randf() * 2.0 - 1.0) * 0.2
		data.encode_s16(i * 2, int(prev * pow(1.0 - t, 2.0) * vol * 32000.0))
	return _make(data)


func _hum() -> AudioStreamWAV:
	var n := RATE * 3
	var data := PackedByteArray()
	data.resize(n * 2)
	var prev := 0.0
	for i in n:
		prev = prev * 0.985 + (randf() * 2.0 - 1.0) * 0.015
		data.encode_s16(i * 2, int(prev * 9000.0))
	return _make(data, true)
