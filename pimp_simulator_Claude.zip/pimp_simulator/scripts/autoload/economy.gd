extends Node
## Fiyat, komisyon, pazarlık ve gün sonu hesapları. Tüm formüller burada, tek yerde.


func in_shift(shift: String, hr: int) -> bool:
	if shift == "flex":
		return true
	var s: Dictionary = Config.SHIFTS.get(shift, Config.SHIFTS["flex"])
	var a: int = s["from"]
	var b: int = s["to"]
	if a < b:
		return hr >= a and hr < b
	return hr >= a or hr < b


# ---------------- Fiyatlar ----------------
func upgrade_price_mult() -> float:
	return 1.0 + 0.04 * GameState.ulevel("furniture") + 0.03 * GameState.ulevel("decor")


func base_price(w: Dictionary) -> float:
	return Config.BASE_SESSION_PRICE * (0.75 + float(w.popularity) / 100.0 * 0.7 + float(w.experience) / 100.0 * 0.4 + float(w.quality) / 100.0 * 0.25)


func session_price(w: Dictionary, type_id: String) -> float:
	var t: Dictionary = Config.SESSION_TYPES[type_id]
	return roundf(base_price(w) * float(t["price_mult"]) * upgrade_price_mult())


func daily_capacity(w: Dictionary) -> int:
	var cap := int(3.0 + float(w.endurance) / 20.0)
	if w.get("perks", []).has("rest_breaks"):
		cap -= 1
	return maxi(2, cap)


func cleaning_minutes() -> float:
	return maxf(5.0, Config.CLEAN_MINUTES * (1.0 - 0.25 * GameState.ulevel("cleaning")))


# ---------------- Pazarlık ----------------
func required_share(w: Dictionary) -> float:
	var e := float(w.experience) / 100.0
	var p := float(w.popularity) / 100.0
	var x := float(w.expectation) / 100.0
	var pm: float = Config.PERSONALITIES.get(String(w.personality), 0.0)
	return clampf(0.52 + 0.14 * e + 0.10 * p + 0.10 * (x - 0.5) + pm, 0.50, 0.88)


func perk_bonus(perks: Array) -> float:
	var b := 0.0
	for p in perks:
		b += float(Config.PERKS[p]["bonus"])
	return b


func facility_bonus() -> float:
	var lv := GameState.ulevel("furniture") + GameState.ulevel("decor") + GameState.ulevel("chairs") \
		+ GameState.ulevel("lounge") + GameState.ulevel("kitchen") + GameState.ulevel("cleaning")
	return minf(0.07, GameState.reputation / 100.0 * 0.03 + 0.008 * lv)


func shift_modifier(w: Dictionary, shift: String) -> float:
	var pref := String(w.get("pref_shift", "flex"))
	if shift == pref or pref == "flex":
		return 0.0
	if shift == "flex":
		return -0.02
	return -0.03


func charisma_bonus() -> float:
	return minf(0.04, 0.005 * (GameState.player_level() - 1))


## Çalışanın teklifi değerlendirmesi. commission = işletmenin payı (0..1)
func negotiate_eval(w: Dictionary, commission: float, shift: String, perks: Array) -> Dictionary:
	var req := required_share(w)
	var offered := 1.0 - commission
	var bonus := perk_bonus(perks) + facility_bonus() + shift_modifier(w, shift) + charisma_bonus() \
		+ (float(w.get("trust", 50.0)) - 50.0) / 100.0 * 0.05
	var eff := offered + bonus
	var gap := req - eff
	var prob := 1.0 if gap <= 0.0005 else clampf(1.0 - gap / 0.08, 0.0, 1.0)
	var counter := clampf(floorf((1.0 - (req - bonus)) * 100.0) / 100.0, Config.MIN_COMMISSION, Config.MAX_COMMISSION)
	var std_price := session_price(w, "standard")
	var est_sessions := clampf(float(daily_capacity(w)) * 0.6, 1.0, 5.0)
	return {"req_share": req, "effective": eff, "gap": gap, "prob": prob, "counter": counter,
		"std_price": std_price,
		"worker_per_session": std_price * (1.0 - commission), "business_per_session": std_price * commission,
		"worker_daily": std_price * (1.0 - commission) * est_sessions, "business_daily": std_price * commission * est_sessions}


# ---------------- Görüşme hesapları ----------------
func session_duration(w: Dictionary, type_id: String, busy: float) -> float:
	var t: Dictionary = Config.SESSION_TYPES[type_id]
	var f := 1.25 - float(w.experience) / 100.0 * 0.35
	var en := float(w.energy)
	if en < 50.0:
		f *= 1.0 + (50.0 - en) / 100.0 * 0.4
	f *= 1.1 - float(w.satisfaction) / 100.0 * 0.2
	f *= 1.0 + clampf((float(w.age) - 30.0) / 100.0, -0.08, 0.15)
	f *= 1.0 + busy * 0.15
	f *= randf_range(0.9, 1.1)
	return maxf(10.0, roundf(float(t["minutes"]) * f))


func pref_score(c: Dictionary, w: Dictionary) -> float:
	match String(c.pref):
		"popular":
			return float(w.popularity)
		"experienced":
			return float(w.experience)
		"friendly":
			return float(w.communication)
		"affordable":
			return 100.0 - clampf((session_price(w, "standard") - 40.0) / 1.2, 0.0, 100.0)
	return (float(w.popularity) + float(w.experience) + float(w.communication)) / 3.0


func pick_type(c: Dictionary, w: Dictionary) -> String:
	var ok: Array = []
	for id in Config.SESSION_ORDER:
		if session_price(w, id) <= float(c.budget):
			ok.append(id)
	if ok.is_empty():
		return ""
	var idx := int(roundf(float(ok.size() - 1) * clampf(float(c.spend_tend) + randf_range(-0.25, 0.25), 0.0, 1.0)))
	return ok[idx]


func customer_satisfaction(c: Dictionary, w: Dictionary, wait_min: float, price: float) -> float:
	var s := 62.0 + (pref_score(c, w) - 50.0) * 0.4 + float(w.quality) * 0.15 + float(w.communication) * 0.05
	s -= minf(20.0, wait_min / maxf(1.0, float(c.wait_tol)) * 15.0)
	s += GameState.ulevel("furniture") * 2.0 + GameState.ulevel("decor") * 2.5 + GameState.ulevel("cleaning") * 1.5
	if price > float(c.budget) * 0.9:
		s -= 4.0
	if float(w.energy) < 25.0:
		s -= 6.0
	s += randf_range(-8.0, 8.0)
	return clampf(s, 0.0, 100.0)


# ---------------- Giderler ----------------
func rent_today() -> float:
	return Config.DAILY_RENT + Config.RENT_PER_EXTRA_ROOM * (GameState.rooms_unlocked() - 1)


func maintenance_today() -> float:
	return Config.MAINT_BASE + Config.MAINT_PER_ROOM * GameState.rooms_unlocked() + Config.MAINT_PER_UPGRADE * GameState.total_upgrade_levels()


func training_cost(w: Dictionary, skill: String) -> float:
	return roundf(40.0 + float(w[skill]) * 1.6)


func training_minutes() -> float:
	return 180.0


# ---------------- Gün döngüsü ----------------
func end_of_day(d: int) -> void:
	if GameState.debt > 0.0 and GameState.money > 0.0:
		var pay := minf(GameState.debt, GameState.money)
		GameState.money -= pay
		GameState.debt -= pay
	GameState.force_expense(rent_today(), "rent", "Günlük kira")
	GameState.force_expense(maintenance_today(), "maintenance", "Bakım gideri")
	var perk_cost := 0.0
	for w in GameState.workers:
		for p in w.perks:
			perk_cost += float(Config.PERKS[p]["daily"])
			if d % 7 == 0:
				perk_cost += float(Config.PERKS[p]["weekly"])
	if perk_cost > 0.0:
		GameState.force_expense(perk_cost, "perks", "Çalışan yan hakları")
	var quit_names: Array = []
	var sat_sum := 0.0
	for w in GameState.workers:
		sat_sum += float(w.satisfaction)
		w.low_sat_days = (int(w.low_sat_days) + 1) if float(w.satisfaction) < 25.0 else 0
		w.wants_raise = required_share(w) - (1.0 - float(w.commission)) > 0.03
		if int(w.low_sat_days) >= 2 or float(w.satisfaction) < 8.0:
			w["quit_pending"] = true
			quit_names.append(String(w.name))
	if not GameState.workers.is_empty():
		GameState.change_reputation((sat_sum / GameState.workers.size() - 50.0) / 50.0 * 0.6)
	if GameState.debt > 0.0:
		GameState.change_reputation(-2.0)
		GameState.notify("Ödenmemiş borcun var: %d$. İtibarın düşüyor!" % int(GameState.debt), "bad")
	var st := GameState.daily(d)
	var expenses := float(st.food) + float(st.rent) + float(st.maintenance) + float(st.upgrade) + float(st.training) + float(st.perks)
	GameState.stats["best_day"] = maxf(float(GameState.stats.get("best_day", 0.0)), float(st.commission))
	var report := {"day": d, "commission": float(st.commission), "worker_pay": float(st.worker_pay),
		"rent": float(st.rent), "maintenance": float(st.maintenance), "food": float(st.food),
		"upgrade": float(st.upgrade), "training": float(st.training), "perks": float(st.perks),
		"sessions": int(st.sessions), "lost": int(st.lost), "net": float(st.commission) - expenses,
		"cash": GameState.money, "debt": GameState.debt, "reputation": GameState.reputation,
		"quits": quit_names}
	GameState.day_ended.emit(report)
	if GameState.debt > Config.MAX_DEBT:
		GameState.trigger_game_over("Borcun %d$ sınırını aştı. Mekânı kaybettin." % int(Config.MAX_DEBT))


func start_of_day() -> void:
	for w in GameState.workers:
		w["sessions_today"] = 0
	GameState.rotate_candidates()
	if bool(SaveSystem.settings.get("autosave", true)) and not GameState.is_game_over:
		SaveSystem.save_game()
	GameState.data_changed.emit()


# ---------------- Satın alma ----------------
func upgrade_status(id: String) -> Dictionary:
	var u: Dictionary = Config.UPGRADES[id]
	var costs: Array = u["costs"]
	var lvl := GameState.ulevel(id)
	var s := {"level": lvl, "max": costs.size(), "cost": 0.0, "rep_req": 0, "can": false, "reason": ""}
	if lvl >= costs.size():
		s.reason = "Maksimum seviye"
		return s
	s.cost = float(costs[lvl])
	s.rep_req = int(u["rep"][lvl])
	var need := String(u["unlock"])
	if need != "" and not bool(GameState.unlocks.get(need, false)):
		s.reason = "Görevle açılır"
	elif GameState.reputation < float(s.rep_req):
		s.reason = "İtibar %d gerekli" % int(s.rep_req)
	elif GameState.money < float(s.cost):
		s.reason = "Yetersiz bakiye"
	else:
		s.can = true
	return s


func buy_upgrade(id: String) -> String:
	var s := upgrade_status(id)
	if not bool(s.can):
		return String(s.reason)
	var u: Dictionary = Config.UPGRADES[id]
	if not GameState.spend(float(s.cost), "upgrade", "Geliştirme: %s" % u["name"]):
		return "Yetersiz bakiye"
	GameState.upgrades[id] = GameState.ulevel(id) + 1
	GameState.stat_add("upgrades_bought")
	GameState.upgrades_changed.emit()
	GameState.data_changed.emit()
	GameState.notify("Geliştirme satın alındı: %s (seviye %d)" % [u["name"], GameState.ulevel(id)], "good")
	Sfx.play("coin")
	return ""


func buy_item(id: String, n: int) -> String:
	var it: Dictionary = Config.ITEMS[id]
	if bool(it.get("needs_kitchen", false)) and GameState.ulevel("kitchen") < 1:
		return "Bu ürün için Mutfak geliştirmesi gerekli."
	var room_left := GameState.storage_capacity() - GameState.inventory_total()
	if room_left <= 0:
		return "Depo dolu."
	n = mini(n, room_left)
	var cost := float(it["price"]) * n
	if not GameState.spend(cost, "food", "Satın alma: %d× %s" % [n, it["name"]]):
		return "Yetersiz bakiye."
	GameState.inventory[id] = int(GameState.inventory.get(id, 0)) + n
	GameState.data_changed.emit()
	Sfx.play("coin")
	return ""
