extends Node
## Görev ilerlemesi: istatistiklere bakarak tamamlananları ödüllendirir.


func value_of(stat_key: String) -> float:
	match stat_key:
		"rep":
			return GameState.reputation
		"rooms":
			return float(GameState.rooms_unlocked())
		"capacity":
			return float(GameState.max_workers())
	return float(GameState.stats.get(stat_key, 0.0))


func check() -> void:
	for q in Config.QUESTS:
		if GameState.quests_done.has(q["id"]):
			continue
		if value_of(String(q["stat"])) >= float(q["target"]):
			_complete(q)


func _complete(q: Dictionary) -> void:
	GameState.quests_done.append(q["id"])
	GameState.add_income(float(q["money"]), "reward", "Görev ödülü: %s" % q["title"])
	GameState.xp += float(q["xp"])
	var unlock := String(q["unlock"])
	var extra := ""
	if unlock != "":
		GameState.unlocks[unlock] = true
		extra = " Yeni özellik: %s" % Config.UNLOCK_NAMES.get(unlock, unlock)
	GameState.notify("Görev tamamlandı: %s (+%d$, +%d XP).%s" % [q["title"], int(q["money"]), int(q["xp"]), extra], "good")
	Sfx.play("quest")
	GameState.quest_completed.emit(q)
	GameState.data_changed.emit()
