extends Node
## Merkezi ayarlar ve denge tabloları. Oyunun tüm sabit değerleri burada tutulur.

const VERSION := "0.1.0 MVP"
const SAVE_PATH := "user://pimp_sim_save.json"
const SETTINGS_PATH := "user://pimp_sim_settings.cfg"

# --- Yetişkin güvenliği: üretilen tüm karakterler yasal sınırın (18) üzerindedir ---
const LEGAL_ADULT_AGE := 18
const MIN_ADULT_AGE := 21
const MAX_WORKER_AGE := 45

# --- Zaman ---
const SECONDS_PER_GAME_MINUTE := 0.4   # 1 oyun saati = 24 sn, 1 gün = 9,6 dk
const MINUTES_PER_DAY := 1440
const START_MINUTE := 540              # 09:00
const SPEED_STEPS := [0.0, 1.0, 2.0, 4.0]
const SPEED_LABELS := ["II", "1x", "2x", "4x"]

# --- Başlangıç ---
const START_MONEY := 900.0
const START_REPUTATION := 10.0
const START_ROOMS := 1
const MAX_ROOMS := 6
const MAX_DEBT := 600.0

# --- Ekonomi ---
const BASE_SESSION_PRICE := 80.0
const DAILY_RENT := 50.0
const RENT_PER_EXTRA_ROOM := 15.0
const MAINT_BASE := 10.0
const MAINT_PER_ROOM := 5.0
const MAINT_PER_UPGRADE := 4.0
const MIN_COMMISSION := 0.05
const MAX_COMMISSION := 0.60

# --- Müşteri akışı ---
const BASE_ARRIVAL_PER_HOUR := 0.50
const HOUR_CURVE := [1.2, 0.9, 0.6, 0.3, 0.15, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7,
	0.8, 0.8, 0.8, 0.9, 1.0, 1.2, 1.5, 1.7, 1.8, 1.7, 1.6, 1.4]
const MAX_CUSTOMERS_INSIDE := 12
const GREET_MINUTES := 5.0
const CLEAN_MINUTES := 15.0
const REP_PER_SESSION := 1.2
const REP_LOSS_LEAVE := 0.25
const CANDIDATE_POOL := 7

# --- Çalışan ihtiyaçları ---
const HUNGER_PER_HOUR := 4.5
const THIRST_PER_HOUR := 6.0
const SEEK_NEED := 60.0
const SEEK_ENERGY := 30.0
const REST_UNTIL := 80.0
const REST_RECOVERY_PER_MIN := 0.35
const EAT_MINUTES := 8.0

const ITEMS := {
	"water": {"name": "Su", "price": 2.0, "thirst": 50.0, "hunger": 0.0, "energy": 0.0, "mood": 0.0, "buff": 0, "desc": "Susuzluğu giderir"},
	"coffee": {"name": "Kahve", "price": 4.0, "thirst": 10.0, "hunger": 0.0, "energy": 15.0, "mood": 0.0, "buff": 120, "desc": "Enerjiyi geçici artırır (2 saat yorgunluk azalır)"},
	"fruit": {"name": "Meyve", "price": 3.0, "thirst": 5.0, "hunger": 25.0, "energy": 0.0, "mood": 0.0, "buff": 0, "desc": "Açlığı azaltır"},
	"sandwich": {"name": "Sandviç", "price": 7.0, "thirst": 0.0, "hunger": 50.0, "energy": 0.0, "mood": 0.0, "buff": 0, "desc": "Açlığı önemli ölçüde azaltır"},
	"energy_drink": {"name": "Enerji içeceği", "price": 6.0, "thirst": 5.0, "hunger": 0.0, "energy": 25.0, "mood": 0.0, "buff": 180, "desc": "Enerjiyi geçici artırır (3 saat yorgunluk azalır)"},
	"meal": {"name": "Yemek", "price": 14.0, "thirst": 0.0, "hunger": 70.0, "energy": 0.0, "mood": 10.0, "buff": 0, "desc": "Genel memnuniyeti artırır (Mutfak gerekir)", "needs_kitchen": true},
}
const ITEM_ORDER := ["water", "coffee", "fruit", "sandwich", "energy_drink", "meal"]

const SESSION_TYPES := {
	"short": {"name": "Kısa görüşme", "minutes": 30, "price_mult": 0.6, "energy": 8.0},
	"standard": {"name": "Standart görüşme", "minutes": 60, "price_mult": 1.0, "energy": 15.0},
	"long": {"name": "Uzun görüşme", "minutes": 110, "price_mult": 1.8, "energy": 26.0},
}
const SESSION_ORDER := ["short", "standard", "long"]

const SHIFTS := {
	"day": {"name": "Gündüz (08–18)", "from": 8, "to": 18},
	"evening": {"name": "Akşam (16–02)", "from": 16, "to": 2},
	"night": {"name": "Gece (22–08)", "from": 22, "to": 8},
	"flex": {"name": "Esnek (her saat)", "from": 0, "to": 24},
}
const SHIFT_ORDER := ["day", "evening", "night", "flex"]

const PERKS := {
	"free_meals": {"name": "Ücretsiz yemek-içecek", "daily": 6.0, "weekly": 0.0, "bonus": 0.025},
	"rest_breaks": {"name": "Garantili dinlenme molaları", "daily": 0.0, "weekly": 0.0, "bonus": 0.025},
	"weekly_bonus": {"name": "Haftalık performans primi", "daily": 0.0, "weekly": 35.0, "bonus": 0.03},
}
const PERK_ORDER := ["free_meals", "rest_breaks", "weekly_bonus"]

const SKILLS := {
	"communication": "İletişim",
	"popularity": "Popülerlik",
	"experience": "Deneyim",
	"quality": "Müşteri memnuniyeti",
	"endurance": "Dayanıklılık",
	"rest_eff": "Dinlenme verimliliği",
}
const SKILL_ORDER := ["communication", "popularity", "experience", "quality", "endurance", "rest_eff"]

# Kişilik -> pay talebine etki
const PERSONALITIES := {"Utangaç": -0.03, "Sakin": -0.01, "Neşeli": 0.0, "Cesur": 0.01, "Hırslı": 0.04, "Düşünceli": 0.0}

const LINES := {
	"Utangaç": {"hi": "Ö-merhaba... Benimle konuşmak mı istiyorsun? Dinliyorum.", "no": "Şey... bu teklif bana biraz az geliyor.", "yes": "Tamam... deneyelim. Umarım iyi geçer."},
	"Sakin": {"hi": "Merhaba. Acelem yok, teklifini dinleyeyim.", "no": "Bunu kabul edemem, biraz daha adil bir pay lazım.", "yes": "Makul görünüyor. Anlaştık."},
	"Neşeli": {"hi": "Heey, selam! Yeni bir iş fırsatı mı var?", "no": "Hmm, hiç hoş değil bu oran! Biraz daha iyi olmalı.", "yes": "Harika! Hadi başlayalım!"},
	"Cesur": {"hi": "Selam. Doğrudan konuşalım, ne öneriyorsun?", "no": "Hayır. Değerimi biliyorum, bu pay yetmez.", "yes": "Güzel pazarlıktı. Kabul."},
	"Hırslı": {"hi": "Merhaba. Kazancım benim için çok önemli, rakamlara bakalım.", "no": "Bu oranla vakit kaybediyorum. Daha iyisini getir.", "yes": "Bu oran işime gelir. Anlaştık."},
	"Düşünceli": {"hi": "Merhaba... Önce koşulları iyice düşünmem lazım. Anlat bakalım.", "no": "Hesapladım, bu teklif bana uymuyor.", "yes": "Dengeli bir teklif. Kabul ediyorum."},
}

const PREF_NAMES := {"popular": "Popüler birini", "experienced": "Deneyimli birini", "friendly": "Sohbeti iyi birini", "affordable": "Uygun fiyatı", "any": "Fark etmez"}

# --- İşletme geliştirmeleri ---
const UPGRADES := {
	"rooms": {"name": "Yeni Oda", "desc": "Bir hizmet odası daha açar: aynı anda daha fazla müşteriye hizmet verilir, çalışan kapasitesi +1.", "costs": [450, 800, 1300, 2000, 3000], "rep": [5, 15, 25, 40, 55], "unlock": ""},
	"furniture": {"name": "Kaliteli Mobilya", "desc": "Çalışan ve müşteri memnuniyeti artar, seans fiyatı +%4 / seviye.", "costs": [250, 500, 900], "rep": [0, 15, 30], "unlock": ""},
	"decor": {"name": "Oda Dekorasyonu", "desc": "Müşteri memnuniyeti ve itibar kazanımı artar, seans fiyatı +%3 / seviye.", "costs": [200, 450, 800], "rep": [0, 12, 28], "unlock": ""},
	"waiting": {"name": "Bekleme Alanını Genişlet", "desc": "Müşteri bekleme kapasitesi +2 koltuk / seviye.", "costs": [250, 500, 900], "rep": [0, 15, 30], "unlock": ""},
	"chairs": {"name": "Konforlu Koltuklar", "desc": "Bekleyen çalışanlar daha iyi dinlenir, müşteri sabrı +%12 / seviye.", "costs": [150, 350], "rep": [0, 10], "unlock": ""},
	"kitchen": {"name": "Mutfak", "desc": "Depo kapasitesi +40, yemek-içecek molası kısalır, 'Yemek' ürünü kullanılabilir.", "costs": [300, 600, 1000], "rep": [0, 15, 30], "unlock": "kitchen"},
	"reception": {"name": "Resepsiyon Geliştirme", "desc": "Karşılama süresi kısalır, müşteri akışı +%8 / seviye.", "costs": [300, 650, 1100], "rep": [0, 18, 32], "unlock": ""},
	"lounge": {"name": "Personel Dinlenme Alanı", "desc": "Dinlenme hızı +%25 / seviye, çalışan kapasitesi +1.", "costs": [350, 700, 1200], "rep": [0, 18, 35], "unlock": ""},
	"cleaning": {"name": "Temizlik ve Bakım", "desc": "Oda temizliği hızlanır, müşteri memnuniyeti +1,5 / seviye.", "costs": [200, 450, 800], "rep": [0, 12, 28], "unlock": ""},
}
const UPGRADE_ORDER := ["rooms", "furniture", "decor", "waiting", "chairs", "kitchen", "reception", "lounge", "cleaning"]

const UNLOCK_NAMES := {"training": "Çalışan eğitimi", "kitchen": "Mutfak geliştirmesi"}

# --- Görevler ---
const QUESTS := [
	{"id": "meet", "title": "İlk çalışanla tanış", "desc": "Şehirde dolaş ve bir potansiyel çalışanla konuş (E).", "stat": "met", "target": 1, "money": 50, "xp": 20, "unlock": ""},
	{"id": "contract", "title": "İlk gönüllü sözleşmeyi yap", "desc": "Pazarlık yap ve bir çalışanla anlaş.", "stat": "contracts", "target": 1, "money": 100, "xp": 40, "unlock": ""},
	{"id": "customer", "title": "İlk müşteriyi karşıla", "desc": "Bir müşteri resepsiyonda karşılansın.", "stat": "greeted", "target": 1, "money": 50, "xp": 30, "unlock": "training"},
	{"id": "income", "title": "İlk gelirini elde et", "desc": "Bir görüşmeyi tamamla ve komisyon kazan.", "stat": "sessions", "target": 1, "money": 100, "xp": 40, "unlock": ""},
	{"id": "second", "title": "İkinci çalışanı işe al", "desc": "İşletmede toplam iki gönüllü sözleşme yap.", "stat": "contracts", "target": 2, "money": 150, "xp": 60, "unlock": "kitchen"},
	{"id": "room2", "title": "İlk yeni odanı aç", "desc": "Geliştirmeler menüsünden ikinci odayı satın al.", "stat": "rooms", "target": 2, "money": 150, "xp": 60, "unlock": ""},
	{"id": "rep50", "title": "İtibarı 50'ye yükselt", "desc": "Müşterileri ve çalışanları memnun et.", "stat": "rep", "target": 50, "money": 400, "xp": 120, "unlock": ""},
	{"id": "cap5", "title": "Beş çalışan kapasitesine ulaş", "desc": "Oda ve dinlenme alanı geliştirmeleriyle kapasiteyi 5'e çıkar.", "stat": "capacity", "target": 5, "money": 300, "xp": 100, "unlock": ""},
	{"id": "upg3", "title": "İşletmeni geliştir", "desc": "Toplam 3 geliştirme satın al.", "stat": "upgrades_bought", "target": 3, "money": 200, "xp": 80, "unlock": ""},
	{"id": "daily300", "title": "Günlük 300$ komisyon", "desc": "Tek bir günde 300$ komisyon geliri elde et.", "stat": "best_day", "target": 300, "money": 500, "xp": 150, "unlock": ""},
]

const FEMALE_NAMES := ["Elif", "Deniz", "Selin", "Melis", "Aylin", "Zeynep", "Defne", "Ece", "Nehir", "Sude", "Ceren", "Buse", "Derya", "Gizem", "İpek", "Pelin", "Sibel", "Tuğba", "Yasemin", "Burcu", "Merve", "Naz", "Lara", "Irmak", "Aslı", "Duygu", "Sevgi", "Nilay", "Esra", "Leyla"]
const MALE_NAMES := ["Ahmet", "Mehmet", "Can", "Emre", "Burak", "Kerem", "Mert", "Onur", "Cem", "Serkan", "Tolga", "Volkan", "Barış", "Kaan", "Oğuz", "Alper", "Hakan", "Murat", "Selim", "Yiğit", "Arda", "Berk", "Cenk", "Doruk", "Efe", "Fatih", "Gökhan", "Hasan", "İlker", "Koray"]

static func shift_name(id: String) -> String:
	return String(SHIFTS.get(id, SHIFTS["flex"])["name"])

static func period_name(hour: int) -> String:
	if hour >= 5 and hour < 11:
		return "Sabah"
	if hour >= 11 and hour < 17:
		return "Öğle"
	if hour >= 17 and hour < 22:
		return "Akşam"
	return "Gece"
