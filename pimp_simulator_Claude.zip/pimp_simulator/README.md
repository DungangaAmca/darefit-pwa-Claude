# PIMP SIMULATOR — MVP (v0.1.0)

Godot 4.x (GDScript) ile yazılmış, 3D işletme-yönetim simülasyonu. Küçük bir mekânla başlar; yetişkin (21+) NPC'lerle **gönüllü sözleşme** ve **komisyon pazarlığı** yapar, müşterileri yönetir, mekânı büyütürsün. Oyunda cinsel içerik veya çıplaklık **yoktur**: görüşmeler kapalı oda + zamanlayıcı ile temsil edilir.

## Çalıştırma
1. Godot 4.3 veya üstünü indir (kurulum gerektirmez, tek .exe — yönetici izni istemez): https://godotengine.org/download
2. Godot'u aç → **Import** → bu klasördeki `project.godot` → **Import & Edit** → **F5**.
   (İlk açılışta Godot sınıf önbelleğini oluşturur; bir kez içe aktarmak şart.)
3. Render: "GL Compatibility" (zayıf/ofis bilgisayarlarında da çalışması için).

## Kontroller
| Tuş | İşlev |
|---|---|
| WASD / Ok | Yürü · **Shift** koş |
| **E** | Etkileşim (konuş, kapı, resepsiyon, mutfak, market) |
| Q / R | Kamerayı döndür · Fare tekerleği: yakınlaş |
| 1–9 | Menüler (Çalışanlar, Müşteriler, İşletme, Finans, Geliştirmeler, Görevler, Harita, Envanter, Ayarlar) |
| Boşluk | Duraklat/devam · **Esc** menü kapat · F5/F9 hızlı kayıt/yükleme |

## Oynanış döngüsü
1. Şehirde dolaş, **sarı isimli** potansiyel çalışanlara yaklaşıp **E** ile konuş.
2. Pazarlık ekranında komisyon, vardiya ve ek hakları belirle; anlaşma olasılığı canlı görünür. Reddedilirsen karşı teklif gelir (3 hakkın var).
3. Evindeki **Gece Salonu**'na gir (kapıda E). Çalışanlar bekleme alanında oturur, müşteriler resepsiyona gelir, eşleşme olunca oda kapanır, süre dolunca ödeme komisyon/pay olarak bölünür.
4. Çalışanların açlık/susuzluk/enerjisini **Envanter** (8) ile yönet; **Geliştirmeler** (5) ile oda, mobilya, mutfak vb. satın al; çalışanları eğit.
5. Mutsuz çalışan sözleşmesini sonlandırıp ayrılır. Borç sınırı aşılırsa oyun biter.

## Mimari
```
project.godot
scenes/main.tscn                 → tek düğümlü ana sahne (her şey kodla kurulur)
scripts/autoload/                → tekil servisler (merkezi veri)
  config.gd        tüm sabitler, denge tabloları, görev/geliştirme tanımları
  game_state.gd    oyun verisi, sinyaller, para/kayıt (to_dict/from_dict)
  economy.gd       fiyat, komisyon, pazarlık olasılığı, süre, gün sonu, satın alma
  generator.gd     aday çalışan / müşteri üretimi
  quest_system.gd  görev ilerlemesi ve ödüller
  save_system.gd   JSON kayıt/yükleme + ayarlar
  sfx.gd           prosedürel ses efektleri
scripts/world/
  main.gd          dünya kurulumu, kamera, zaman döngüsü, etkileşim
  city.gd          şehir (yollar, binalar, kaldırım rotaları, bina saydamlaşması)
  interior.gd      işletme iç mekânı, 6 oda, kapı/lamba görselleri
  business.gd      ÇALIŞAN ve MÜŞTERİ DURUM MAKİNELERİ, oda akışı, eşleştirme
  city_npcs.gd     şehir NPC'leri (walk / idle / talk durum makinesi)
  npc_actor.gd     insansı karakter, yürüme/oturma animasyonu
  player.gd, build_util.gd
scripts/ui/        HUD, 9 menü paneli, pazarlık ekranı
scripts/dev/       selftest.gd, balance.gd (geliştirici testleri)
```
Genişletme noktaları: yeni geliştirme = `Config.UPGRADES`; yeni ürün = `Config.ITEMS`; yeni görev = `Config.QUESTS`; yeni vardiya/ek hak = `Config.SHIFTS` / `Config.PERKS`.

## Testler (başsız çalıştırma)
```
godot --headless --path . --import
godot --headless --path . --fixed-fps 60 -- --selftest     # 60+ otomatik kontrol
godot --headless --path . --fixed-fps 60 -- --balance --restock   # 12 günlük ekonomi akışı
```

## Bilinen sınırlar / sonraki aşamalar
- Yalnızca **Gece Salonu** girilebilir; Market, kapısında envanter/sipariş menüsünü açar. Diğer binalar dış cephe.
- Yeni bölgeler (itibarla açılan semtler), rakipler, reklam, rastgele olaylar henüz yok (Aşama 6–7).
- Görseller primitif şekillerden üretilmiş geçici modellerdir; sesler prosedürel basit efektlerdir.
- Kayıtta müşteriler resepsiyondan yeniden başlar (görüşme ortasındaki müşteri sıraya döner).
